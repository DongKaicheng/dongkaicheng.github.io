# Project bindings

This public distribution has no preconfigured website or hosting account.

Resolve the project from the current user request and its actual source repository. If the user supplies a URL, verify its identity and hosting configuration before editing. Record the project name, canonical URL, source checkout and hosting identifier in the project’s own configuration. Keep credentials outside the skill and all public bundles.

A remembered URL or project name is a navigation aid, not evidence of the current deployment or permission to modify a different website. Preserve the site’s existing audience and permanent result identifiers. Use the actual hosting provider’s supported source and deployment workflow, and reuse authorization already provided in the current task.

Keep project-specific language, authorship, layout, feedback and publication preferences scoped to that project. For existing feedback systems, inspect their live schemas and retain version and conflict guards. Public read access does not grant editorial write access.
