# Research websites: mathematics and reading order

Use a short overview to help readers choose a mathematical question, and separate paper pages to let them check the argument. Simplify presentation by moving detail, not by discarding results or proofs.

## 1. Establish a project-level publication contract

Recover the current site, selected research corpus, latest source snapshot and user preferences. Record the full project title, public language, signed/unsigned paper policy, audience, and approved routes. An instruction for a separate site overrides an older umbrella-site binding. Keep current IDs and historical editions.

Use full mathematical names in the main title when requested. Abbreviations defined inside a paper need not be banned. Use ordinary mathematical English in navigation and established names for constructions and statements. A title should let a researcher predict the objects and conclusion. Avoid internal round numbers, coined framework names and process labels as public mathematical headings. Verify terminology against the actual statement; do not rename a narrow construction as a more general theorem.

## 2. Recover all relevant progress before reducing the page

Ask the maintainer for a derived, source-bound coverage view of the task's corpus. Include established and partly established cases, conditional constructions, alternative arguments and unresolved sources. Record which cases are nested as consequences so they do not disappear during consolidation. Give an absent source an explicit import/recovery status; a chat summary is not its missing proof.

For a height-pairing construction, the view identifies the actual variety/field, both cycle groups and complementary codimensions, relevant equivalence relation, assumptions, properties established, proof destination and remaining step. Distinguish constructing a number on representatives from a bilinear pairing on a quotient, a pairing on a subgroup from a full-domain pairing, and existence from comparison, functoriality, positivity or finiteness. Apply the analogous distinctions for other subjects.

Reconcile the old and new views by permanent identity. Every recovered case must remain visible, be nested with a working anchor, or have an explicit withdrawal/supersession reason and retained history. Describe completeness relative to inspected sources; do not claim access to all chats or archives merely from a memory summary. A missing source need not stop independent layout improvements, but it prevents claiming its proof has been recovered.

## 3. Organize by mathematical implication

Use the maintainer's exact applications, hypotheses and typed relations. Organize the page around the principal constructions and conjectures. Put a genuine consequence or specialization under its strongest appropriate parent and give its short deduction or proof link there. If A together with H yields B, display H at the link: do not publish A ⇒ B. A proposed implication remains proposed until its argument is supplied and assessed.

Keep all premises of a joint deduction together. Retain cross-links when a consequence has multiple parents, and distinguish alternative sufficient proofs from jointly required inputs. Reading order is a view of the dependency graph, not a replacement for it. Do not turn all task dependencies, analogies or shared terminology into mathematical arrows. A compact implication table can help; omit decorative graphs that add no mathematical information.

## 4. Separate the three reading levels

| Page | Mathematical purpose | Main link |
| --- | --- | --- |
| Home | State the motivation, central question/conjecture and intended mathematical object in a few concise paragraphs | Conjecture and formal programme |
| Conjectures / Progress / Plan | Explain the principal assertions, supported implications, available cases and decisive open steps | Exact paper section or proof |
| Formal paper | Give the actual definitions, numbered statements, proofs or research problems, conditional deductions and references | Standalone PDF of this exact edition |

Keep the homepage focused; do not repeat the result register, revision history, all cases or all caveats. Use clear headings rather than many badges or cards. Retain necessary restrictions and mathematical content on the linked pages. Preserve useful existing feedback/about links without letting them obscure the research question.

Use `math-writing-editor` for each full paper. Reuse authoritative source and shared content when possible so HTML and PDF do not evolve independently. A formal page must stand on its own as a mathematical article, not display a summary, a source-file list, or a bare PDF iframe in place of the requested HTML paper. Include the full available proof; isolate a genuinely incomplete argument and state its exact missing step. Keep review/audit metadata outside the mathematical body, while retaining substantive open problems inside a programme.

When unsigned papers are requested, remove the byline and generated author metadata from those paper outputs and source templates. Keep bibliography authors, provenance and the private review trail. Do not fabricate “Anonymous” or an AI author credit, or silently anonymize unrelated signed manuscripts.

## 5. Make the Plan a mathematical programme

Begin with the exact target and ambient conventions. Organize intermediate problems by what their conclusions enable, with explicit prerequisites, proposed mechanism and core obstruction. Link each overview item to its numbered formal problem or proposition in a separate programme article.

Distinguish a proved reduction from its open premises. When a conditional deduction is part of the programme, state its assumptions and give its argument. Do not manufacture a new proof to make a dependency chart look complete. Treat genuinely separate routes separately and show the point where each would supply the next construction.

When an advertised implication fails, preserve a meaningful intended target as a separate open objective. If a counterexample refutes the target itself, record the refutation and distinguish any proposed corrected target; do not silently drop the objective or label a false formulation merely open.

For the Beilinson–Bloch project, verify local Green-form existence and descent, construction of the global Chow pairing, correspondence/classical comparisons, positivity and integral/bounded-degree finiteness as different mathematical obligations. A direct strong-G route and an obstruction-vanishing route are not interchangeable without a comparison. Positivity alone does not supply a discrete lattice or a Northcott theorem. Preserve the exact test class, support complement, field and degree normalization in the authoritative sources.

These are subject-specific audit questions, not a fixed six-step template for every programme. Do not transfer a conditional theorem or unsolved prerequisite from this project into another as established mathematics.

## 6. Make mathematical entry points easy to use

Style the formal-paper link as a clear primary action. Make proof links and expandable construction details conspicuous using size, weight, spacing and a coherent contrasting colour, not colour alone. Preserve the user's chosen palette; do not impose one project's blue or green elsewhere. Use descriptive labels such as “Read the proof” or the named construction rather than unexplained internal codes.

Use real anchors for navigation and accessible buttons or `details/summary` for disclosure. Provide visible keyboard focus, keyboard activation and comfortable touch targets (normally about 44 px for these actions). Check desktop and narrow layouts, wrapping of long mathematical titles, readable contrast and the open/closed state of details. A stylesheet change is not evidence that the correct element visibly changed.

Link each paper to a real standalone PDF, built from the same source edition. A browser print dialog, a screenshot PDF or a PDF of the whole website is not a replacement. Check the downloaded bytes, equations, page breaks, references, title and author policy. Keep a source download when already supported; do not expose private source directories or review notes.

## 7. Accept an edition with evidence

Use [publication checks](publication-checks.md) for the read-only artifact checker and the human/agent checks it cannot perform. Compare coverage, dependencies, paper text, sources and links before and after the edit. Correct broken or stale output before declaring it done; report a specific unavailable source or access limitation. Editing and publication do not promote a mathematical claim's review status.
