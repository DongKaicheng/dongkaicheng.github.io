#!/usr/bin/env python3
"""Inspect research files and validate versioned publication bundles; no TeX execution."""
import argparse
import hashlib
import json
import math
import os
import re
import sys
from collections import defaultdict, deque
from datetime import datetime
from pathlib import Path, PurePosixPath
from urllib.parse import urlsplit

EXTENSIONS = {'.tex', '.md', '.json', '.bib', '.pdf'}
EXCLUDED = {'.git', '.hg', '.svn', '.venv', 'venv', 'node_modules', '__pycache__',
            '.cache', '.next', '.wrangler', '.sites-runtime', 'dist', 'build'}
KINDS = {'conjecture', 'result', 'definition', 'question', 'note'}
STATUSES = {'open', 'draft', 'conditional', 'proved', 'reviewed', 'withdrawn'}
ID_RE = re.compile(r'[A-Z][A-Z0-9-]{2,63}\Z')
SLUG_RE = re.compile(r'[a-z][a-z0-9]*(?:-[a-z0-9]+)*\Z')
SHA_RE = re.compile(r'[a-f0-9]{64}\Z')
TEXT_FIELDS = ('id', 'kind', 'title', 'summary', 'statement', 'proof', 'motivation', 'approach')


def sha_file(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def entry_payload(entry):
    payload = {key: entry.get(key, '') for key in TEXT_FIELDS}
    payload.update(dependencies=entry.get('dependencies', []),
                   references=entry.get('references', []), source=entry.get('source'))
    return payload


def canonical_hash(payload):
    raw = json.dumps(payload, ensure_ascii=False, sort_keys=True,
                     separators=(',', ':'), allow_nan=False).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()


def entry_hash(entry):
    return canonical_hash(entry_payload(entry))


def support_payload(bundle, entry_id, content_hashes=None):
    """Bind every transitive declared premise, after rejecting missing/cyclic support."""
    by_id = {}
    for entry in bundle.get('entries', []):
        if not isinstance(entry, dict) or not isinstance(entry.get('id'), str):
            raise ValueError('support calculation requires entries with string IDs')
        if entry['id'] in by_id:
            raise ValueError('duplicate entry ID in support calculation: ' + entry['id'])
        by_id[entry['id']] = entry
    if entry_id not in by_id:
        raise ValueError('unknown support target: ' + entry_id)
    def child_ids(identifier):
        deps = by_id[identifier].get('dependencies', [])
        if not isinstance(deps, list) or any(not isinstance(dep, str) for dep in deps):
            raise ValueError('invalid dependencies for ' + identifier)
        return iter(deps)
    state, stack = {entry_id: 1}, [(entry_id, child_ids(entry_id))]
    while stack:
        identifier, children = stack[-1]
        dependency = next(children, None)
        if dependency is None:
            state[identifier] = 2
            stack.pop()
            continue
        if dependency not in by_id:
            raise ValueError(identifier + ': unknown dependency ' + dependency)
        if state.get(dependency) == 1:
            raise ValueError('cycle in support relation through ' + dependency)
        if dependency not in state:
            state[dependency] = 1
            stack.append((dependency, child_ids(dependency)))
    hashes = content_hashes if content_hashes is not None else {}
    dependencies = []
    for identifier in sorted(set(state) - {entry_id}):
        entry = by_id[identifier]
        if not isinstance(entry.get('status'), str) or entry['status'] not in STATUSES:
            raise ValueError('unsupported dependency status for ' + identifier)
        if identifier not in hashes:
            hashes[identifier] = entry_hash(entry)
        dependencies.append({'id': identifier, 'contentHash': hashes[identifier], 'status': entry['status']})
    return {'dependencies': dependencies}


def support_hash(bundle, entry_id, content_hashes=None):
    return canonical_hash(support_payload(bundle, entry_id, content_hashes))


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError('duplicate JSON key: ' + key)
        result[key] = value
    return result


def load_json(filename):
    path = Path(filename)
    if path.stat().st_size > 10 * 1024 * 1024:
        raise ValueError('bundle exceeds 10 MiB')
    def reject_constant(value):
        raise ValueError('non-finite JSON constant: ' + value)
    def finite_float(value):
        number = float(value)
        if not math.isfinite(number):
            raise ValueError('non-finite JSON number: ' + value)
        return number
    return json.loads(path.read_text(encoding='utf-8'), object_pairs_hook=no_duplicate_keys,
                      parse_constant=reject_constant, parse_float=finite_float)


def inventory(directory):
    root = Path(directory).resolve(strict=True)
    if not root.is_dir():
        raise ValueError('source root must be a directory')
    files, skipped = [], []
    def reject_walk_error(error):
        raise error
    for current, dirs, names in os.walk(root, followlinks=False, onerror=reject_walk_error):
        kept = []
        for name in sorted(dirs):
            if name in EXCLUDED:
                continue
            path = Path(current) / name
            if path.is_symlink():
                resolved = path.resolve(strict=True)
                if not resolved.is_relative_to(root):
                    raise ValueError('symlink escapes source root: ' + str(path.relative_to(root)))
                skipped.append(str(path.relative_to(root)) + '/ (directory symlink)')
            else:
                kept.append(name)
        dirs[:] = kept
        for name in sorted(names):
            path = Path(current) / name
            if path.suffix.lower() not in EXTENSIONS:
                continue
            resolved = path.resolve(strict=True)
            if not resolved.is_relative_to(root):
                raise ValueError('symlink escapes source root: ' + str(path.relative_to(root)))
            if not resolved.is_file():
                raise ValueError('source is not a regular file: ' + str(path.relative_to(root)))
            files.append({'file': path.relative_to(root).as_posix(),
                          'bytes': path.stat().st_size, 'sha256': sha_file(path)})
    return {'schemaVersion': 1, 'files': sorted(files, key=lambda item: item['file']),
            'skipped': sorted(skipped)}


def validate(bundle, source_root=None):
    errors, warnings = [], []
    def text(obj, key, where, required=True):
        value = obj.get(key)
        if key not in obj and not required:
            return
        if not isinstance(value, str) or (required and not value.strip()):
            errors.append(f'{where}.{key}: expected ' + ('nonempty ' if required else '') + 'string')
    def strings(obj, key, where):
        value = obj.get(key)
        if not isinstance(value, list) or any(not isinstance(v, str) or not v.strip() for v in value):
            errors.append(f'{where}.{key}: expected array of nonempty strings')
            return []
        if len(set(value)) != len(value):
            errors.append(f'{where}.{key}: duplicate values')
        return value
    def date(value, where):
        try:
            if not isinstance(value, str):
                raise ValueError()
            datetime.fromisoformat(value.replace('Z', '+00:00'))
        except ValueError:
            errors.append(where + ': expected ISO date or timestamp')
    if not isinstance(bundle, dict):
        return {'valid': False, 'errors': ['bundle must be an object'], 'warnings': []}
    if type(bundle.get('schemaVersion')) is not int or bundle['schemaVersion'] != 1:
        errors.append('schemaVersion: expected integer 1')
    project = bundle.get('project')
    if not isinstance(project, dict):
        errors.append('project: expected object')
    else:
        for key in ('id', 'title', 'summary'):
            text(project, key, 'project')
        for key in ('motivation', 'programme', 'subtitle'):
            text(project, key, 'project', required=False)
        for key in ('motivation', 'programme'):
            if key not in project:
                errors.append(f'project.{key}: expected string')
        if not isinstance(project.get('id'), str) or not SLUG_RE.fullmatch(project['id']):
            errors.append('project.id: invalid lowercase slug')
        strings(project, 'authors', 'project')
        strings(project, 'keywords', 'project')
        if 'category' in project and project['category'] not in ('foundations', 'research'):
            errors.append('project.category: expected foundations or research')
        if 'updatedAt' in project:
            date(project['updatedAt'], 'project.updatedAt')
    entries = bundle.get('entries')
    if not isinstance(entries, list) or len(entries) > 5000:
        return {'valid': False, 'errors': errors + ['entries: expected array of at most 5000 entries'], 'warnings': warnings}
    by_id, dependencies = {}, {}
    root = Path(source_root).resolve(strict=True) if source_root else None
    for index, entry in enumerate(entries):
        where = f'entries[{index}]'
        if not isinstance(entry, dict):
            errors.append(where + ': expected object')
            continue
        for key in ('id', 'title', 'summary', 'statement'):
            text(entry, key, where)
        for key in ('proof', 'motivation', 'approach'):
            text(entry, key, where, required=False)
        identifier = entry.get('id')
        if not isinstance(identifier, str) or not ID_RE.fullmatch(identifier):
            errors.append(where + '.id: invalid permanent ID')
        elif identifier in by_id:
            errors.append(where + '.id: duplicate ' + identifier)
        else:
            by_id[identifier] = entry
        if not isinstance(entry.get('kind'), str) or entry['kind'] not in KINDS:
            errors.append(where + '.kind: unsupported kind')
        if not isinstance(entry.get('status'), str) or entry['status'] not in STATUSES:
            errors.append(where + '.status: unsupported status')
        deps = strings(entry, 'dependencies', where)
        if isinstance(identifier, str):
            dependencies[identifier] = deps
        refs = entry.get('references')
        if not isinstance(refs, list):
            errors.append(where + '.references: expected array')
        else:
            for j, ref in enumerate(refs):
                rwhere = f'{where}.references[{j}]'
                if not isinstance(ref, dict):
                    errors.append(rwhere + ': expected object')
                    continue
                text(ref, 'label', rwhere)
                text(ref, 'locator', rwhere, required=False)
                try:
                    url = urlsplit(ref.get('url', ''))
                    safe = url.scheme in {'http', 'https'} and bool(url.hostname) and not url.username and not url.password
                except (ValueError, TypeError, AttributeError):
                    safe = False
                if not safe:
                    errors.append(rwhere + '.url: expected HTTP(S) URL without credentials')
        source = entry.get('source')
        if source is not None:
            if not isinstance(source, dict):
                errors.append(where + '.source: expected object')
            else:
                filename, sha = source.get('file'), source.get('sha256')
                safe = isinstance(filename, str) and bool(filename) and '\\' not in filename and '\x00' not in filename
                safe = safe and not PurePosixPath(filename).is_absolute() and '..' not in PurePosixPath(filename).parts
                if not safe:
                    errors.append(where + '.source.file: expected relative path inside source root')
                if not isinstance(sha, str) or not SHA_RE.fullmatch(sha):
                    errors.append(where + '.source.sha256: expected lowercase SHA-256')
                text(source, 'locator', where + '.source', required=False)
                if root and safe:
                    try:
                        path = (root / filename).resolve(strict=True)
                        if not path.is_relative_to(root) or not path.is_file():
                            raise ValueError('path outside source root or not a file')
                        if sha_file(path) != sha:
                            errors.append(where + '.source.sha256: source bytes do not match')
                    except (OSError, ValueError) as exc:
                        errors.append(where + '.source.file: ' + str(exc))
        status = entry.get('status')
        if isinstance(status, str) and status in {'proved', 'reviewed'}:
            text(entry, 'proof', where)
            if entry.get('kind') in {'conjecture', 'question'}:
                errors.append(where + ': conjectures/questions cannot have proved/reviewed status')
        if status == 'reviewed':
            if not isinstance(source, dict):
                errors.append(where + ': reviewed entry requires source binding')
            review = entry.get('review')
            if not isinstance(review, dict):
                errors.append(where + ': reviewed entry requires review record')
            else:
                for key in ('reviewer', 'scope'):
                    text(review, key, where + '.review')
                date(review.get('date'), where + '.review.date')
                if review.get('contentHash') != entry_hash(entry):
                    errors.append(where + '.review.contentHash: missing or stale review binding')
    indegree, reverse = {key: 0 for key in by_id}, defaultdict(set)
    for identifier, deps in dependencies.items():
        for dep in deps:
            if dep not in by_id:
                errors.append(identifier + ': unknown dependency ' + dep)
            elif identifier in by_id:
                indegree[identifier] += 1
                reverse[dep].add(identifier)
    queue = deque(key for key, degree in indegree.items() if degree == 0)
    while queue:
        for dependent in reverse[queue.popleft()]:
            indegree[dependent] -= 1
            if indegree[dependent] == 0:
                queue.append(dependent)
    if any(degree > 0 for degree in indegree.values()):
        errors.append('selected dependency relation contains a cycle: ' + ', '.join(sorted(key for key, degree in indegree.items() if degree > 0)))
    content_hashes = {}
    for identifier, entry in by_id.items():
        review = entry.get('review')
        if entry.get('status') != 'reviewed' or not isinstance(review, dict):
            continue
        if entry.get('dependencies') or 'supportHash' in review:
            try:
                expected = support_hash(bundle, identifier, content_hashes)
                if review.get('supportHash') != expected:
                    errors.append(identifier + '.review.supportHash: missing or stale support binding; expected ' + expected)
            except ValueError as exc:
                errors.append(identifier + '.review.supportHash: ' + str(exc))
    if not root and any(isinstance(e, dict) and e.get('source') for e in entries):
        warnings.append('source bytes were not checked; use --source-root for exact source verification')
    return {'valid': not errors, 'errors': errors, 'warnings': warnings,
            'entryCount': len(entries), 'proofCorrectnessVerified': False}


def diff(old, new):
    for name, bundle in [('old', old), ('new', new)]:
        outcome = validate(bundle)
        if not outcome['valid']:
            raise ValueError(name + ' bundle invalid: ' + '; '.join(outcome['errors']))
    if old['project']['id'] != new['project']['id']:
        raise ValueError('cannot compare updates for different project IDs')
    before = {e['id']: e for e in old['entries']}
    after = {e['id']: e for e in new['entries']}
    added, removed = set(after) - set(before), set(before) - set(after)
    changed = {key for key in set(before) & set(after) if entry_hash(before[key]) != entry_hash(after[key])}
    old_hashes, new_hashes, support_changes = {}, {}, []
    for key in sorted(set(before) & set(after)):
        old_support = support_hash(old, key, old_hashes)
        new_support = support_hash(new, key, new_hashes)
        if old_support != new_support:
            support_changes.append({'id': key, 'from': old_support, 'to': new_support})
    reverse = defaultdict(set)
    for entry in old['entries'] + new['entries']:
        for dep in entry['dependencies']:
            reverse[dep].add(entry['id'])
    seeds = changed | removed | {change['id'] for change in support_changes}
    affected, queue = set(seeds), deque(seeds)
    while queue:
        for dependent in reverse[queue.popleft()]:
            if dependent not in affected:
                affected.add(dependent)
                queue.append(dependent)
    return {'added': sorted(added), 'removed': sorted(removed), 'changedContent': sorted(changed),
            'affectedEntries': sorted(affected),
            'supportChanges': support_changes,
            'reviewRecheckRequired': sorted(key for key in affected if key in after and after[key]['status'] == 'reviewed'),
            'statusChanges': [{'id': key, 'from': before[key]['status'], 'to': after[key]['status']}
                              for key in sorted(set(before) & set(after)) if before[key]['status'] != after[key]['status']],
            'projectChanged': old['project'] != new['project'],
            'warnings': ['Preserve published IDs with withdrawn entries rather than silent removal.'] if removed else []}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='command', required=True)
    commands.add_parser('inventory').add_argument('root')
    template = commands.add_parser('template')
    template.add_argument('--id', default='research-project')
    template.add_argument('--title', default='Research project')
    template.add_argument('--category', choices=('foundations', 'research'), default='research')
    validation = commands.add_parser('validate')
    validation.add_argument('bundle')
    validation.add_argument('--source-root')
    comparison = commands.add_parser('diff')
    comparison.add_argument('old')
    comparison.add_argument('new')
    for command in ('entry-hash', 'support-hash'):
        hashing = commands.add_parser(command)
        hashing.add_argument('bundle')
        hashing.add_argument('entry_id')
    args = parser.parse_args()
    try:
        if args.command == 'inventory':
            result = inventory(args.root)
        elif args.command == 'template':
            if not SLUG_RE.fullmatch(args.id):
                raise ValueError('invalid project slug')
            result = {'schemaVersion': 1, 'project': {'id': args.id, 'title': args.title, 'category': args.category,
                      'summary': 'Replace with the project overview from the source materials.',
                      'authors': [], 'keywords': [], 'motivation': '', 'programme': ''}, 'entries': []}
        elif args.command == 'validate':
            result = validate(load_json(args.bundle), args.source_root)
        elif args.command == 'diff':
            result = diff(load_json(args.old), load_json(args.new))
        elif args.command == 'support-hash':
            bundle = load_json(args.bundle)
            payload = support_payload(bundle, args.entry_id)
            result = {'id': args.entry_id, 'supportHash': canonical_hash(payload), **payload}
        else:
            bundle = load_json(args.bundle)
            entries = [entry for entry in bundle.get('entries', []) if isinstance(entry, dict) and entry.get('id') == args.entry_id]
            if len(entries) != 1:
                raise ValueError('entry ID must identify exactly one entry')
            result = {'id': args.entry_id, 'contentHash': entry_hash(entries[0])}
        print(json.dumps(result, ensure_ascii=False, indent=2, allow_nan=False))
        return 0 if result.get('valid', True) else 1
    except (OSError, ValueError, TypeError, KeyError, AttributeError) as exc:
        print(json.dumps({'error': str(exc)}, ensure_ascii=False), file=sys.stderr)
        return 2


if __name__ == '__main__':
    sys.exit(main())
