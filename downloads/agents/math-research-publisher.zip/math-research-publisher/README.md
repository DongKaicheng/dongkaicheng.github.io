# Math Research Publisher

Organize mathematical research into clear, versioned websites with linked papers, proof status and reader feedback.

## Use the bundle

Download and extract the ZIP. Keep the `math-research-publisher` folder intact so its instructions can find the bundled references, scripts and examples. In an assistant that supports skill import, import this folder or upload the ZIP and ask it to install `math-research-publisher`. You can also give a file-aware assistant the folder and ask it to read `SKILL.md` before working on your project.

Example request: “Use math-research-publisher for the project files I have supplied.”

The publication tools use Python 3. Start with `python3 scripts/publish_math.py --help`. Website deployment requires your own hosting access. Install Math Project Maintainer and Math Writing Editor as companion skills for their respective tasks. `references/site-binding.md` contains generic setup guidance.

## Contents and release

This public source bundle is dated 2026-11-18. It contains the skill instructions and their supporting resources. It can be downloaded and used in your own mathematical workflow. Configure the workflow for your own project and review mathematical outputs using the supplied sources.

Personal hosting bindings and generated caches are excluded. Research manuscripts, hosted accounts and credentials are not part of the bundle.
