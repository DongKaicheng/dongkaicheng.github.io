# Math Project Maintainer

Build and maintain large mathematical projects with stable result identifiers, explicit proof dependencies, review records and read-only search.

## Use the bundle

Download and extract the ZIP. Keep the `math-project-maintainer` folder intact so its instructions can find the bundled references, scripts and examples. In an assistant that supports skill import, import this folder or upload the ZIP and ask it to install `math-project-maintainer`. You can also give a file-aware assistant the folder and ask it to read `SKILL.md` before working on your project.

Example request: “Use math-project-maintainer for the project files I have supplied.”

The Python tools require Python 3.10 or newer and use the standard library. Project writes require a POSIX environment (Linux, macOS, or WSL). The optional read-only web/API service uses Node.js. Start with `python3 scripts/math_project.py --help`.

## Contents and release

This public source bundle is dated 2026-11-18. It contains the skill instructions and their supporting resources. It can be downloaded and used in your own mathematical workflow. Configure the workflow for your own project and review mathematical outputs using the supplied sources.

Personal hosting bindings and generated caches are excluded. Research manuscripts, hosted accounts and credentials are not part of the bundle.
