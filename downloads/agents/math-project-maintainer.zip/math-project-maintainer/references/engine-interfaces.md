# Engine interfaces

This file defines implementation interfaces, not mathematical certification.

## LaTeX reader

`mathproj.latex.parse_project(root: Path, entrypoints: list[str] | None = None,
source_roots: list[str] | None = None) -> dict`

Return JSON-compatible data with keys `items`, `files`, `diagnostics`, and `source_layout`.

- `files`: list of `{path, sha256, text, bibliographic_references}`; project-relative POSIX paths. The citation inventory retains unowned occurrences and marks indexed owners, so mirrored file and item entries must not be counted twice.
- `items`: list of `{key, label, kind, title, statement, proofs, references,
  source, explicit_id, section}`. `key` is `path::label`; labels are local to a
  source file. Missing labels generate a diagnostic and a provisional key.
  `source` is `{path, start_line, end_line}`; document/fragment/citation spans additionally provide zero-based Unicode `start_char` and exclusive `end_char`. `explicit_id` is optional metadata
  read from `% mpm:id=ID` inside the result environment; do not modify sources.
  `section` is a list of section titles, useful for navigation, not inferred
  hypotheses. `statement` retains original TeX but omits label/id commands.
- `proofs`: on each item, a list of `{text, source, references}` plus `bibliographic_references` when present.
- Each reference is `{label, target_key, command, line, role}`. `target_key`
  may be null if unresolved. Roles distinguish statement, proof, and mention.
  Resolve local labels first, then unique global labels and unambiguous
  filename-prefixed Stacks-style references. Report ambiguity.
- `diagnostics`: list of `{code, severity, message, path, line}`. Severity is
  error/warning/info. Preserve unknown TeX as text; report unsupported
  structural constructs and never execute TeX. Ignore comments and verbatim
  when scanning commands. Resolve only literal includes within the root.

Bibliography occurrence rows preserve key, command, optional notes, source span, and role. The registry adds a stable slot ID within the statement or proof. Citation evidence names those exact slot IDs; source-key equality alone never checks an occurrence. `nocite` is a bibliography listing.

`mathproj.latex.source_layout(root, *, entrypoints=None, source_roots=None, lookups=None)` recomputes filesystem discovery and literal include-resolution decisions without reading TeX bytes. Pass the previous layout lookup specifications. The caller must also validate source hashes; layout equality alone is insufficient.

## Dependency algorithms

`mathproj.graph.solve_support(nodes, proofs, roots=None) -> dict`

- `nodes`: iterable of string IDs or mapping with ID keys.
- `proofs`: list `{id, conclusion, dependencies: list[str], eligible: bool}`.
- `roots`: iterable of IDs explicitly admitted as foundation inputs. Empty
  dependency lists on eligible proofs are allowed. All other nodes start
  ungrounded. Do not derive eligibility from prose or votes.
- Return `grounded` (sorted IDs), `selected_proofs` (conclusion -> proof ID),
  `order` (foundation-before-consumer IDs), `blocked`, `cycles`, `diagnostics`.
- Different proofs are OR choices; all dependencies of one proof are AND.
  Select a well-founded support plan; do not demand that the union of all
  alternative proofs be acyclic. Return useful unresolved/cycle diagnostics.
- `reverse_impact(edges, seeds)`: edges are `{consumer, dependency, kind}`;
  return `{affected, paths, diagnostics}` including seeds. `paths[id]` is a
  compact witness `{seed, predecessor, distance, kind}`; predecessor is null
  at a seed. `impact_path(result, id)` materializes a seed-to-consumer path.
  Use deterministic shortest witnesses; diagnose empty or absent seeds.
  The caller selects relevant edge kinds. No mathematical falsity is inferred.

## Extending the engine

Use the standard library and unittest. Keep tests under `scripts/tests`. Preserve event/snapshot compatibility and the public CLI; extend data validation together with state, review, task, and publication bindings. An added renderer or proof-assistant adapter must retain the distinction between structural evidence, named prose review, and actual formal proof checking.
