# Elementary maintenance demo

`assets/demo/main.tex` includes three original source files containing 28 labeled objects:
2 conventions, 6 definitions, 18 lemmas, and 2 remarks. The lemmas have 19
proofs because `lem-subalgebra-seminorm` has two alternatives. There are no
copied Stacks Project passages or imported claims from ongoing user research.

The algebra section treats annihilators, a nilpotent-ideal module argument,
and quotient maps. Its nilpotent-ideal result intentionally needs no finite
generation. The topology section records ambient spaces in closure and support
notation and gives the precise compact-support hypothesis for zero extension.
The seminorm section works over a specified non-Archimedean absolute value,
without finite-dimensionality or completeness, and treats restriction,
quotient well-definedness, and simultaneous renormalization of scalar and vector
seminorms.

`demo.json` records the entrypoint and descriptive metadata.
`contexts.proposed.json` makes the intended contextual associations explicit as
an integration proposal. It is not a command specification or a claim that the
metadata has already been imported by a particular version of the toolkit.

For development, work on a copy of the source tree. Import it, inspect the
stable identifiers and the two separate proof records, attach the explicit
contexts, and make a small revision. Compare the review obligations and the
impact witnesses. An imported object starts as unreviewed; these examples do
not authorize automatic acceptance of proofs or axioms.

The source uses standard `article`, `amsmath`, `amssymb`, `amsthm`, `geometry`,
and `hyperref` packages. Compile `main.tex` twice with a working XeLaTeX or
pdfLaTeX installation; an additional pass can be necessary after the table of
contents changes page breaks. TeX outputs belong in a separate build directory.
Compilation verifies syntax and references, not mathematical correctness.
