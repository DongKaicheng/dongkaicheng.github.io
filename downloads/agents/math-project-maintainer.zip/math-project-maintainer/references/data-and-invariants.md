# Data model, invariants, and supported inputs

## Authoritative data

`mathproject.json` chooses the namespace, language, source roots, entrypoints, and review policy. Keep it under the project's ordinary version control. `mpm/events.jsonl` is an append-only, hash-linked sequence of state changes. `mpm/snapshots/<hash>.json` contains immutable imported source and item data. `mpm/releases/<hash>.json` contains immutable reviewed-release data. These files and the source tree belong together.

The event log is the authority for identities, aliases, contexts, applications, reviews, issues, foundations, proposals, tasks and their checkpoints. The state cache and SQLite search indexes are disposable. Losing the search cache must not lose accepted work. Hash chains detect corruption; they are not external signatures or a defense against an actor who can deliberately rewrite every authoritative file.

Each import also records a compact source basis in the event log: source byte hashes, discovered files and include-resolution choices, manifest/context hashes, the reader fingerprint, diagnostics, and the exact snapshot archive byte hash. A clean freshness check validates the archive bytes and this basis without decoding every statement again. Changed source, changed resolution, or a reader upgrade triggers structural parsing; legacy snapshots retain the full validation path. UTF-8 BOMs and CRLFs are preserved in archived text, whose reconstructed bytes must match its declared source hash.

New snapshots declare exact UTF-8 preservation and are always written strictly. Early format-1 archives predating reader/layout metadata omitted a leading UTF-8 BOM while recording the raw hash. Reading those archives may reconstruct that one BOM only when the resulting bytes exactly match the recorded hash. It never normalizes line endings, repairs other content, or rewrites the archive or its identity. Current-format mismatches still fail.

The reader fingerprint covers both the LaTeX scanner and registry normalization, since either can change reference ownership or revision semantics. It is not a claim to fingerprint every tool or runtime dependency. An engine upgrade should always be followed by an explicit import and inspection of changes before new review decisions.

Writers share a POSIX advisory lock. A transaction appends and fsyncs its event before updating the state cache. An incomplete final event can be preserved and removed by `recover`; a complete corrupt event is not silently repaired. Missing or empty authoritative logs are errors. Restoring only a cache is not a substitute for restoring the event log and snapshots.

Source proposals use a separate pending journal around multi-file writes. Recovery distinguishes a source change committed in the event log from an uncommitted partial write. It restores only bytes matching the known old or proposed version; an unrelated intervening edit requires explicit reconciliation. Imports and decision recording are blocked while recovery is pending.

## Identity and revision

An ID such as `NA-000042` is stable. The display label, file path, theorem number, current statement and proof are separate data. An exact citation also identifies a snapshot or release.

The importer retains an ID for an existing source key. A move is recognized automatically only when the old source key disappears and there is one matching label with the exact same statement hash. For more substantial moves, use the registered `% mpm:id=NA-000042` annotation in the result. Unknown or multiply claimed explicit IDs are errors. Deleted source objects become `missing` records; they are not removed from history or declared false.

The declaration revision covers the exact statement, kind, title and applicable contexts. Proof revisions cover their text, declaration and resolved references. An item's aggregate revision also records its alternatives and statement references. An application binds the target declaration, so editing the target's proof does not automatically invalidate a correct application of its unchanged statement. Its support still depends on an eligible proof of that target.

A review binding includes the selected proof, declaration, contexts, application records, cited source evidence and relevant blocking-issue history. These inputs determine validity, rather than a review timestamp or a mutable status bit. An old acceptance cannot become current merely because an objection was closed later or a clock moved backward.

## Distinct graph meanings

| Edge or relation | Meaning |
| --- | --- |
| source/section membership | Navigation and document structure. |
| candidate reference | A literal source reference awaiting application analysis. |
| uses | An identified theorem/definition application with recorded premises. |
| mention | Related or historical discussion with no premise role in this argument. |
| internal | A clause or construction within the same mathematical item. |
| explicit context | A scoped ambient assumption or convention. |
| task dependency | A work-order prerequisite; it does not establish mathematical truth. |

Research reading views additionally distinguish implications, conditional
implications, specializations, alternative routes, and analogies. These are
derived presentation records described in [research programmes](research-programmes.md),
not new values of the application enum. A single navigation parent does not
erase the other inputs of a proof or prove a stronger implication.

The support solver computes a least fixed point from admitted roots and eligible proofs. All dependencies of one proof are required; alternative proofs are choices. It chooses a well-founded plan of minimum derivation height with deterministic ID tie breaking. Residual cycles describe ungrounded eligible alternatives, and may coexist with missing-input obstacles. They do not disprove a result or invalidate a grounded alternative.

Reverse impact is conservative and may include unreviewed references. It returns compact shortest witnesses rather than all paths. Reconstruct a requested path when explaining why a result needs review. Changing a context or removing an upstream item creates recheck tasks.

## Supported LaTeX subset

The reader parses UTF-8 source without executing TeX. It recognizes common theorem-like environments, custom `newtheorem` declarations, definitions, conventions, notation, assumptions, examples, remarks, proof environments, labeled sections and display equations. It associates adjacent proofs or explicit proof headers with their results and preserves alternative proofs. Nested clause/equation labels can resolve to their containing item with a clause target. [Engine interfaces](engine-interfaces.md) describes the programmatic contracts.

Literal `input` and `include` paths are followed inside the project root. Discovery can instead scan declared source roots. The reader handles ordinary comments, verbatim-like environments and inline literal spans, balanced arguments, common reference commands, and unambiguous Stacks-style filename-prefixed references. Reference ambiguity, duplicate identities, missing includes, include cycles, malformed structures and unsupported structural macros produce diagnostics.

A document-front literal `phantomsection` immediately followed by a label is captured as a navigation object when its syntactic position is unambiguous. A directly labeled outer list item outside a declared mathematical environment can be retained as an untyped `fragment`, with its enclosing list and preceding-section spans. Capturing a fragment neither declares it a theorem nor supplies a proof. Fragments cannot receive implicit or named proof attachments. An inspected legacy definition can be explicitly admitted with its precise meaning; unresolved fragments otherwise remain unsupported. Document, fragment, and citation spans additionally use zero-based Unicode character offsets with an exclusive end; ordinary item spans retain their line locations.

Common literal bibliography commands preserve each occurrence's key, optional locator notes, and ownership. Checked source/citation evidence must name the exact `reference_ids` of the current statement or proof; one bibliography key does not cover every use of that source. Evidence also freezes a normalized slot signature so a changed interpretation cannot reuse an old record silently. `nocite` is recorded as a listing, and navigation/unowned occurrences remain inspectable without becoming theorem premises. No BibTeX execution, source fetching, or bibliographic correctness is inferred from this extraction.

The only conditional exception is a literal pre-document `IfFileExists` whose two branches each contain only a `documentclass` command and whitespace/comments. This preserves presentation setup without selecting or executing a branch. General mathematical conditionals remain unsupported. Filesystem layout validation also checks literal include resolution again, so a new extensionless or root-relative file cannot silently shadow the imported target.

It does not expand arbitrary macros, evaluate TeX conditionals, execute shell commands, or implement the full TeX language. A result/proof split across files, nested mathematical results with local assumptions, or context inherited implicitly across include boundaries needs an adapter or explicit restructuring. Section headings are navigation, not automatically inferred hypotheses. Review diagnostics before accepting an import with `--allow-incomplete`; such a snapshot cannot bypass freshness/structural checks for a reviewed release.

## Retrieval and publication

Search is lexical. Ordinary terms are treated as literals, with case-preserving tokens for TeX commands. Exact mode handles formula punctuation and case-sensitive substrings. It does not establish symbolic equivalence, mathematical applicability, or conceptual completeness. Every hit points to an exact snapshot, item/proof revision and source span.

Context packets state their text budget, included items, dependencies, truncation and omissions. They are bounded working material. Reading only a truncated packet does not establish review completeness. Historical packets use the historical snapshot and do not borrow current review judgments.

Local HTML exports contain stable item destinations, source navigation, references and backlinks. Review/status data stays separate from mathematical text. The initial exporter presents original TeX as readable source; it does not claim to be a full TeX-to-HTML mathematical renderer. A reviewed export uses its frozen release, including the selected support plan and admissions. A preview remains a preview even when some items have current reviews.

## Operational limits

Mathematical maintenance remains a local, host-driven toolkit. A separate [read-only API](read-only-api.md) can serve a whitelisted frozen release without owner project access. It has no unattended research daemon, hosted multi-user editor, authenticated reviewer identity service, or general semantic proof kernel. It supports concurrent local writers through the common lock, not distributed consensus. Host agents perform research, mathematical development and review using their available tools. Advanced formalization and a fully rendered publication frontend can be added without replacing the source/event/snapshot model.
