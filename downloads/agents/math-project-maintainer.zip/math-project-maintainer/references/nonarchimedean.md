# Non-Archimedean project checks

Apply these checks where the argument uses the relevant structure. They are not boilerplate for every theorem and do not authorize weakening the intended target.

## Ambient data and normalization

Identify the ground field, chosen absolute value or valuation, value group, completeness assumptions actually used, and whether the valuation may be trivial. State which normalization is fixed and how measures, lengths, tropical weights, or slopes depend on it. If replacing an absolute value by a positive power, track the change through every downstream construction instead of assuming numerical invariants are unchanged.

Keep algebraic, analytic, formal, adic and tropical objects typed. A point, residue field, completed residue field, model, skeleton, and tropicalization are different inputs. When a result passes between categories, inspect the exact comparison theorem and its hypotheses.

## Generality and dimension

Preserve the full target dimension and class of objects. A useful curve argument may be a component of a higher-dimensional proof, but does not establish that proof by analogy. Track where normality, smoothness, properness, compactness, strictness, finite presentation, or a chosen model is used. Add an assumption only when the mathematics requires it and record the effect on the original target.

For norms and seminorms, distinguish the ultrametric inequality, scalar homogeneity, submultiplicativity and multiplicativity. The zero seminorm and nontrivial kernels may matter. For quotient seminorms, verify representative independence, the infimum argument and any additional condition needed for a norm or a complete quotient; an infimum need not be attained. Restriction to a subalgebra need not require finite-dimensionality or completeness when the proof only uses the defining inequalities.

## Support, measures, convergence and tests

Record the ambient space in which support is closed. Compact support in a subspace, compactness of its closure in another space, and zero extension are distinct assertions. Check the actual separation assumptions used to promote compact sets to closed sets.

Distinguish equality on a specified class of test functions from equality of measures. Verify the uniqueness principle and hypotheses connecting that test class to the intended measure category. Track positivity, local finiteness, tightness or regularity only where invoked. A proof for atomic measures does not automatically cover arbitrary measures. A statement about weak convergence must retain its exact topology and test class.

When passing limits through integrals, pushforwards, intersections or tropical operations, identify the relevant convergence or continuity theorem. Do not silently change tests from compactly supported continuous functions to another class.

## Base extension and descent

A construction or solution after extending the valued ground field is not automatically a construction over the original field. State the descent data or the precise faithful-flatness, representability, invariance or uniqueness argument that supplies descent. Conversely, do not reject a valid descent argument merely because some nonlinear descent problems fail: finite linear systems and other specific constructions may descend for concrete algebraic reasons.

Track normalization and multiplicity under extension, not just existence of geometric points. For model changes and subdivisions, prove independence or compatibility where it is claimed, and identify the maps inducing the comparison.

## Tropicalization and skeleta

Keep the chosen model, chart, lattice, orientation and weighting convention identifiable. For multiplicities and pushforwards, compare the correct lattice indices, residue or degree factors, and dimensions. A set-theoretic image does not by itself identify a weighted cycle. A skeleton defined using one model requires a compatibility argument before being treated as model independent.

Preserve these details in statement/application records and the places in the proof where they operate. Keep workflow commentary outside the mathematical body. A useful final account explains the construction and decisive argument, rather than enumerating hypothetical failures unrelated to the result.
