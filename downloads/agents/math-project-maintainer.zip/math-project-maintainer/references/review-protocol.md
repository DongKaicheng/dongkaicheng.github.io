# Mathematical review protocol

Review the exact claim and its actual proof. The toolkit records the judgment and checks that its inputs are still current. Its completeness checks cannot decide whether the reviewer has correctly understood the mathematics.

## Reconstruct the assertion

Write a compact private representation of the statement before judging the proof:

- Which objects are given, and in which category or ambient space?
- Which objects are asserted to exist, and under which quantifiers?
- Is a choice unique, canonical, well defined, or independent of a representative?
- Which constants depend on which objects? Which variables range uniformly?
- Which topology, support, normalization, convergence, or test class is used?
- Which conventions are inherited, and which are explicit in the statement?

This is an audit representation, not a template to insert mechanically into the mathematical text. Preserve the user's target when developing a repair. If only a weaker result is established, record the original target as open and explain the exact difference.

## Check each nontrivial inference

Read the cited theorem itself, including nearby definitions and hypotheses needed to interpret it. A similar title or a remembered slogan is insufficient. Distinguish an exact application, an immediate corollary, a combination of results with nontrivial interfaces, and a new argument.

An application record includes the target ID and clause, substitution, every required hypothesis and its discharge, and the conclusion obtained. Use `no_hypotheses=true` only for a result with no nontrivial premises in the applicable context, with a reason. It is not a way to skip inspecting hypotheses. Externally cited results need an exact locator and versioned evidence; their admission as foundations is a separate decision.

Check whether a limit commutes with an operation, an infimum is attained when used as a minimum, a representative gives a well-defined quotient construction, a local conclusion has the gluing needed globally, or a scalar extension supplies the descent data actually required. Follow the proof's mathematics instead of mechanically demanding every conceivable regularity condition.

## Distinguish three judgments

1. The statement is true under its actual hypotheses.
2. The supplied proof establishes that statement.
3. The corpus contains an eligible support plan under its admitted inputs.

A true statement can have an invalid proof. A valid proof can depend on an as-yet unaccepted prerequisite. A cyclic support plan can become grounded through a different proof. Do not collapse these judgments into a single confidence score.

Use counterexamples or boundary cases to test a suspected defect, not as a replacement for reading the proof. A finite-dimensional example cannot establish an arbitrary-dimensional theorem. Conversely, do not add finite-dimensionality, compactness, smoothness, or completeness merely because it makes an argument familiar; check whether the proof works generally.

## Independent review

An independent reviewer did not author the changed argument. A fresh worker should receive the exact source, applicable contexts, dependencies, and review task, without an instruction to approve it. It may inspect verified primary references. Record whether the reviewer is an agent or a human. Same-model independent review is useful but remains fallible; agreement is not a proof kernel.

The five report categories are:

| Category | Required mathematical reasoning |
| --- | --- |
| hypotheses | Every invoked theorem's hypotheses and variable assignments match. |
| inference | The actual deductions establish the full conclusion. |
| scope | Quantifiers, object categories, fields, ambient spaces and inherited conventions agree. |
| constructions | Existence, well-definedness, independence and functoriality are established where used. |
| citations | Exact references, clauses and versions support the claimed uses. |

Use `not_applicable` only with a concrete reason. Acceptance requires positive reasoning for hypotheses, inference, and scope. Avoid repeated generic affirmations; name the decisive arguments and any delicate interfaces.

## Findings and resolutions

Each finding contains `severity`, `scope`, `title`, `reason`, and `required_action`. Severity is `blocker`, `error`, `warning`, or `note`. Scope is `statement` or `proof`; a proof finding must name the selected proof through its review packet. The program supplies issue IDs and provenance; the finding must not override them.

Use a statement finding for a counterexample, missing hypothesis, incorrect object type, or normalization error in the assertion. Use a proof finding for an unjustified step when another proof could establish the unchanged statement. Warning and note findings remain nonblocking. A mathematical error must not be downgraded to a stylistic warning to pass a gate.

Resolve an issue as `fixed`, `invalid`, or `superseded`, explaining the actual mathematical reason and recording the reviewer. A changed file alone is not evidence that the objection was addressed. Resolution changes the review input history; obtain a new accepting review on the current packet before restoring support. Historical acceptances remain visible but cannot silently become current again.

## Editing and proof status

The `math-writing-editor` preserves content while improving exposition. Read its current skill and relevant references when using it. If editing exposes a mathematical gap, keep the gap in the maintenance record and repair it through this review workflow. Do not ask a writing pass to manufacture a proof or remove a necessary restriction.

Compilation checks syntax, document construction and cross-references. The dependency solver checks a conditional support graph. Neither establishes semantic truth. Formalization, when separately provided, needs the exact formal declaration, tool and library versions, and a checked correspondence between the formal and written statements.
