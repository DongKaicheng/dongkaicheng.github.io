# Stacks Tag lookup

The Stacks Tag adapter connects an external four-character Tag to an existing
local item in a selected immutable snapshot. It does not allocate IDs, change
labels, import sources, fetch a website, or record a mathematical review. The
local permanent ID and the external Tag remain different identifiers.

Supply a local copy of the Stacks Project's `tags/tags` registry as an absolute
file path. Keep that registry with the source checkout or other provenance
evidence for the project; it is not bundled into this skill.

```bash
python3 <skill-dir>/scripts/math_project.py --project <project-root> \
  stacks-tag 00DV 00DW 07RC --registry /absolute/path/to/tags/tags

python3 <skill-dir>/scripts/math_project.py --project <project-root> \
  stacks-tag 00DV --registry /absolute/path/to/tags/tags --snapshot <snapshot-hash>

python3 <skill-dir>/scripts/math_project.py --project <project-root> \
  stacks-tag --registry /absolute/path/to/tags/tags --audit
```

Omitting `--snapshot`, or selecting `current`, uses the current **recorded
snapshot**. Unimported working-source changes are not included. A supplied
snapshot must have its complete 64-character SHA-256 identity and belong to the
project's recorded history. The event chain, snapshot digest, and archived
source-byte hashes are checked before mapping. A broken or incomplete ledger
fails without repair; recover it through the normal project workflow.

## Exact mapping and its limits

Each registry record has the form `TAG,full_label`. The full label is the source
filename without its extension, followed by `-` and the literal LaTeX label. For
example, the primary label `lemma-NAK` in `content/algebra.tex` matches
`algebra-lemma-NAK`. The adapter builds exact matches from each selected snapshot
item's `source.path`, `label`, and `label_aliases`.

The adapter does not guess a chapter by splitting on the first or last hyphen,
strip an arbitrary label suffix, perform a text search, or use historical
source-key aliases after an item has moved. Duplicate basenames and other
prefix/label collisions can produce multiple exact candidates. Such a lookup
returns `status: "ambiguous"`, the candidate count, and bounded candidate
details; it does not select one of them.

For a unique match, the result includes:

| Field | Meaning |
|---|---|
| `tag` | External Stacks Tag, preserved exactly. |
| `official_url` | `https://stacks.math.columbia.edu/tag/TAG`; the adapter does not visit it. |
| `full_label` | Exact label spelling in the supplied registry. |
| `item_id`, `item_revision` | Existing permanent local identity and exact selected revision. |
| `source_key`, `kind`, `primary_label` | The owning item's archived identity context and type. |
| `matched_label` | The actual primary label or label alias that matched. |
| `target_clause` | The exact nonprimary alias, or `null` for a primary label. |
| `source`, `source_sha256` | The owning item's archived source span and its file's exact byte hash. |
| `source_scope` | `item` for a primary label, `owning_item` for a label alias. |
| `snapshot`, `registry_sha256` | Exact snapshot identity and SHA-256 of the registry bytes read for this lookup. |

The existing parser stores nested labels and proof anchors as aliases of their
owning item. A matched alias therefore retains `target_clause` and
`target_scope: "label_alias"`. It also reports
`clause_span_available: false`: the archived owner span is not a separately
extracted span or text for that clause. The field name `target_clause` follows
the project's reference convention; it does not assert that every alias is a
logical theorem clause. Proof anchors and navigation aliases can also use it.

For the usual Stacks registry, Tag `00DV` maps to `algebra-lemma-NAK`, while
`00DW` maps to `algebra-item-nakayama`. Both can have the same permanent local
item ID. The latter must retain `target_clause: "item-nakayama"`; it must never
be presented as an unqualified lookup of the whole lemma. Tag `07RC` maps to
the section label `algebra-section-nakayama` and retains the local `section`
kind. Primary section and document anchors have `target_scope: "navigation"`.
Standalone indexed list entries retain their `fragment` kind.

An unmapped result has no top-level item target. Its reason is
`tag_not_in_registry` when the requested Tag is absent from the supplied file,
or `label_not_indexed_in_snapshot` when that file's full label has no exact
match in the selected snapshot. The latter can mean missing source, a different
source version, an unsupported source construct, or an unindexed label. The
adapter does not infer which explanation is true from absence alone.

Two additional cases fail conservatively. `source_has_parse_errors` means a
relevant source path has an archived parser error other than `orphan_proof`; for example, an incomplete
import may contain duplicate nested labels that its alias list cannot
distinguish. The adapter does not treat that list as proof of uniqueness.
`alias_source_not_recorded` means an item's parsed proofs include another
source file and the archived alias list does not record which file contains
each alias. Potential filename prefixes stay unresolved in that case; the
primary item label can still map. Exact lookup of those aliases requires a
future parser extension that records individual alias source locations.

The sole parser-error exception is `orphan_proof`: a detached proof does not
itself make an already indexed source label ambiguous. Such a label can map,
and its result exposes the source's archived errors in `source_diagnostics`
(code, severity, path, and line; at most 20 summaries, with an omitted count).
The audit also counts mapped tags carrying these diagnostics in
`mapped_with_source_diagnostics` and `mapped_by_source_diagnostic_code`.
Mapping can therefore succeed in a structurally incomplete snapshot. It
neither resolves the parser error nor authorizes review or acceptance.

## Registry validation and resource bounds

Tags must contain exactly four uppercase ASCII letters or digits. Requested
tags are neither case-folded nor trimmed. The registry accepts UTF-8 text, an
optional UTF-8 BOM, blank lines, and lines whose first non-space character is
`#`. Each data line must be a two-field CSV record with a literal
filename-prefixed label. Ordinary punctuation such as the `+` in
`curves-lemma-degree-at-least-2g+1` is preserved.

The entire registry is validated on every call, even when only one Tag is
requested. A malformed record, one Tag assigned two different full labels, or
one full label assigned two different Tags fails the call. Repeated identical
records are accepted and counted in `registry.duplicate_record_count`; they do
not create extra mappings. The registry checksum covers the original file
bytes, including comments, line endings, and any identical repeated records.
There is no registry cache that can silently reuse old mappings after a file
changes.

Ordinary lookup accepts 1–256 tags and preserves request order, including
repeats. Registry input is bounded to 16 MiB and 250,000 data records. Ambiguous
results contain at most 20 candidate details and report any omitted count.
The all-registry audit counts every unique Tag in the validated file and
returns at most 100 unresolved examples by default. Its Python API accepts a
`diagnostic_limit` from 0 to 1,000. Audit totals are complete even when diagnostic
examples are truncated. No source statements, proofs, or corpus excerpts are
included in lookup or audit reports.

## Provenance and review boundary

The returned registry hash identifies the exact file supplied by the caller.
The snapshot identifies the exact local archived source and item revisions.
Those two hashes alone do **not** establish that the registry and the snapshot
originated from the same upstream Stacks commit. The report explicitly sets
`same_upstream_revision_verified: false`. Independently record the upstream
checkout commit and acquisition evidence when that relationship matters.

A successful mapping is navigation evidence. It does not verify that the
local theorem agrees mathematically with the website, that a nested clause is
applicable, or that any proof has been reviewed. The report explicitly sets
`mathematical_review_performed: false`. Open the selected local item and its
context, inspect the exact external material when needed, and use the normal
application and review workflow for mathematical reliance.

## Python API

Both functions are defined in `scripts/mathproj/stacks_tags.py` and accept an
existing `ProjectStore`:

```python
lookup_tags(store, registry, tags, *, snapshot=None)
audit_tags(store, registry, *, snapshot=None, diagnostic_limit=100)
```

`registry` is an absolute `str` or `Path`. `tags` is one Tag string or an
iterable of Tag strings. Validation failures raise `ProjectError`; missing or
ambiguous mappings are ordinary explicit result rows. The adapter reads the
authoritative ledger without creating a lock, rebuilding a cache, changing
`state.json`, or writing any project metadata. A caller may save the returned
report separately through the CLI's normal protected output mechanism.
