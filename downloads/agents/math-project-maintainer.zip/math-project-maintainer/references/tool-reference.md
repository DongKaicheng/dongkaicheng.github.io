# Tool reference

Run `doctor` without an initialized project to inspect Python, POSIX locking,
SQLite FTS5, atomic local export support, and detectable LaTeX formats. A compiler
executable can be present while its format is unavailable; the report keeps those
facts separate. The check installs nothing and never compiles project source.

Run `python3 <skill-dir>/scripts/math_project.py --project <root> <command>`. Replace both paths with the actual skill and project directories. The global `--project` and `--output` options precede the command. Operational commands return JSON to stdout; operational validation failures return JSON to stderr and exit with code 2. Argument syntax/type errors instead print ordinary usage text with exit code 2; help and version also use text. `--debug` exposes a traceback for development diagnostics. `--output report.json` also saves the returned JSON, and cannot target mathematical sources or metadata.

Relative `--output`, `--file`, and `*-file` paths resolve from the shell's current working directory, independently of `--project`. Use absolute paths when these differ. Source selectors, proposal edit paths, task artifacts, and relative export destinations refer to the project root.

Use actual IDs and revisions returned by the program. Do not invent hashes or fill reports with generic approvals. Record text in UTF-8 JSON files through the available file tools; pass their paths to `--file`. This avoids shell quoting problems in mathematical text.

## Initialize and inspect

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> init --name Foundations --namespace NA --source-root content --entrypoint main.tex
python3 <skill-dir>/scripts/math_project.py --project <root> ingest
python3 <skill-dir>/scripts/math_project.py --project <root> status
python3 <skill-dir>/scripts/math_project.py --project <root> items --kind lemma
python3 <skill-dir>/scripts/math_project.py --project <root> show lemma-restriction
python3 <skill-dir>/scripts/math_project.py --project <root> history NA-000042
```

`init` preserves source files and refuses existing metadata. Without entrypoints, source roots are scanned; default root is `content`. Repeat `--source-root` or `--entrypoint` when needed. `demo` creates the original bundled corpus in an empty destination and imports it. Inspect `contexts.proposed.json` in that demo before explicitly registering conventions.

Prefer dedicated source directories such as `content` when local HTML export is needed. The initial export path policy protects each entire declared source root, even in entrypoint mode. Therefore `--source-root .` permits import but leaves no valid project-contained export destination. This version does not automatically move an existing flat manuscript tree.

`ingest --allow-incomplete` preserves a structurally problematic import for investigation. It does not waive decision or release checks. `items --include-missing` and `show <ID> --snapshot <hash>` expose historical identities. Plain `history --limit 20` shows event provenance. `recover` verifies events and snapshots, rebuilds the state cache, and recovers an interrupted source proposal when possible.

## Explicit contexts

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> context set valued-field --text-file convention.txt --path 'content/seminorms.tex'
python3 <skill-dir>/scripts/math_project.py --project <root> ingest
```

Choose `--global`, repeated `--path` globs, or repeated `--label` selectors. Matching uses an OR of the supplied scopes. `--text` may replace `--text-file`. A context update takes effect in imported item revisions at the next import. It is not automatically inferred from every TeX paragraph or section heading.

## Retrieval and context packets

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> search 'quotient seminorm'
python3 <skill-dir>/scripts/math_project.py --project <root> search '\Gamma' --kind lemma
python3 <skill-dir>/scripts/math_project.py --project <root> search 'p(x+y)' --exact
python3 <skill-dir>/scripts/math_project.py --project <root> packet NA-000042 --max-items 30 --max-chars 24000
```

Search accepts `--snapshot`, `--path` glob, `--kind`, and `--limit`. Ordinary terms are literal lexical terms, not FTS query syntax. Exact mode is a case-sensitive substring. Every result retains its snapshot, source span and item/proof revision. `reindex` rebuilds the disposable SQLite cache. Deleting that cache loses no mathematical records.

`packet` accepts item IDs, source labels, and supported proof references. It includes requested statements, proof text, bound contexts and direct candidate prerequisites. Its budget is text characters; metadata and omission records are additional. Read truncation/omission fields before using the packet as review context. Select historical input with `--snapshot`.

For imported Stacks sources, use `stacks-tag 00DV 00DW --registry /absolute/path/to/tags/tags` to map external Tags into a recorded snapshot. Add `--snapshot <hash>` for historical lookup, or use `stacks-tag --registry /absolute/path/to/tags/tags --audit` without individual Tags for a registry census. This adapter is read-only, retains nested clause labels, and reports missing or ambiguous mappings. It does not establish the registry's origin, a common upstream revision, or mathematical acceptance. Read [Stacks Tag adapter](stacks-tag-adapter.md) for provenance and span limits.

## Applications

Get the current reference records:

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> --output applications.json application template NA-000042:proof:1
```

For statement references use `NA-000042:statement`. The output contains a `records` list, with actual keys and revisions. Fill each record, keeping its binding fields unchanged:

```json
{
  "application_key": "copy from the template",
  "proof_id": "NA-000042:proof:1",
  "proof_revision": "copy from the template",
  "target_id": "NA-000017",
  "target_revision": "copy from the template",
  "target_clause": null,
  "relation": "uses",
  "substitution": "Describe the actual objects substituted into the cited lemma.",
  "hypotheses": [
    {"required": "The hypothesis as used", "discharge": "The argument or exact input establishing it"}
  ],
  "conclusion": "What this application supplies to the current proof",
  "justification": "Why the application matches this source and clause",
  "reviewer": "the actual inspecting reviewer"
}
```

These descriptive strings illustrate the schema; they are not acceptable substitute reasoning. `relation` can be `uses`, `mention`, or `internal`. Mentions/internal references still require a reason and reviewer. An internal reference points to the same item. A result cannot use itself as an established external premise. For an assumption-free use, explicitly set `no_hypotheses=true` and justify it.

Save a JSON list or an object with `records`, then run `application record --file applications.json`. The whole batch is one transaction. To record an implicit prerequisite absent from literal TeX references, supply `manual=true`, omit `application_key`, and use the actual proof/target revisions; the program computes a stable key. A manual application's target clause can be explicitly supplied.

## Reviews and findings

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> --output packet.json review prepare NA-000042 --proof NA-000042:proof:1
```

When there is exactly one proof it is selected automatically; alternatives require a specific proof ID. The packet contains the exact item, proof, dependencies, applications, source evidence, open issues, freshness, and a `template`. Save the filled template itself as the submission file, not the entire packet.

The report has `binding`, `reviewer`, `verdict`, `summary`, `checks`, and `findings`. Reviewer fields are `id`, `kind` (`agent` or `human`), `independent` (boolean), and `author_of_change` (boolean). Do not mark an author as independent. Verdict is `accept`, `changes_required`, or `reject`. Every named check appears exactly once, with `status` (`pass`, `issue`, or `not_applicable`) and concrete `reason`.

The checks are `hypotheses`, `inference`, `scope`, `constructions`, and `citations`. Acceptance requires positive reasoning for the first three, current applications/evidence, and no relevant open mathematical error. A non-accepting report supplies at least one concrete finding:

```json
{
  "severity": "error",
  "scope": "proof",
  "title": "The stated source lemma has an unmet premise",
  "reason": "Identify the exact premise and why it is unavailable here.",
  "required_action": "Give a sufficient repair while preserving the intended target."
}
```

Use `scope=statement` for an objection applying to every proof of the claim. See the mathematical review protocol for the distinction. Record with `review record --file review.json`. `review list --item <ID>` and `issue list --item <ID>` show records.

Resolve a concrete issue with:

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> issue resolve <issue-ID> --reviewer <name> --disposition fixed --reason-file resolution.txt
```

Dispositions are `fixed`, `invalid`, and `superseded`. Resolution requires an actual mathematical reason. Prepare a new review packet afterward: relevant issue history is part of its binding. A packet prepared before the objection was addressed is stale.

## Sources and external results

`source add <key> --file source.json` records metadata. Required fields are `title` and `uri`. Status defaults to `candidate`; a checked source also needs an exact `version` or `content_sha256`, a named `checked_by`, and `accessed_at` as an ISO date or timestamp. Optional fields include authors, year, publisher and notes. Updates need the exact `previous_revision`; identical submissions are idempotent. The tool does not fetch the URI or certify the contents.

`source cite <item> <source-key> --file citation.json` attaches evidence. Use a stable `citation_key`, the current `source_revision` and `declaration_revision`, and optionally a selected `proof_id`/`proof_revision`. A checked citation requires:

- `status: "checked"`, an exact `locator` object such as theorem/page/section/tag;
- `supporting_statement`, `substitution`, `conclusion`, and `justification`;
- `assumptions` as required/discharge records, or justified `no_assumptions: true`;
- actual `inspected_text` or an attested `evidence_sha256`;
- named `checked_by` and actual `accessed_at`.

For a literal bibliography occurrence, add `reference_ids` containing its exact slot IDs from `review prepare`'s `bibliographic_references` inventory. The keys, optional locator notes, and source span are visible there. Statement slots use a citation with no `proof_id`; proof slots require that exact proof ID. A checked record can cover multiple occurrences only when every listed occurrence has actually been checked against the recorded evidence. The tool derives internal slot signatures; callers cannot provide or override them. Older citations without `reference_ids` continue to record external evidence but do not silently cover newly extracted occurrences.

Use concise inspected evidence and respect the source's license and quotation limits. Candidate, uncovered, retired, and stale citations are visible obstacles to acceptance for the subject using them. An unused candidate source is not a dependency. `source audit` reports indexed textual slots and evidence coverage. Add `--include-unowned` to read the archived file inventory and include citations outside indexed objects; this requires loading the source snapshot and can be slower on a large corpus. Arbitrary custom citation macros and implicit references still require mathematical inspection.

`source retire <citation-ID> --expected-revision <hash> --reviewer <name> --reason-file reason.txt` explicitly retires an obsolete use while preserving history. Retired citation IDs are terminal; renewed use receives a new citation key. Retirement remains in the review binding so an older acceptance cannot silently return.

Admit a result only as an explicit input when the project intends to rely on it:

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> foundation add NA-000017 --kind external_theorem --reason-file admission.txt
```

External theorem admission requires current checked item-level citation evidence. Other categories are `axiom`, `definition`, and `assumption`, each with an explicit reason. These are visible conditional roots, not automatic verification. `foundation revoke <ID> --reason-file reason.txt` removes an admission. `foundation list` retains its history through the event log.

## Support and revision impact

`support <IDs...>` computes the conditional support plan, eligibility reasons, selected alternatives, admitted inputs, blocked results and residual cycles. With no IDs it reports all active mathematical items. Inspect freshness before treating the report as current. The solver's answer is conditional on the recorded judgments and foundations.

`impact <IDs...>` follows reverse dependencies, conservatively including candidates. `--confirmed-only` narrows that graph. `--path-to <ID>` reconstructs one shortest witness. The result identifies review work, not falsity.

## Source-change proposals

Prepare JSON with `title`, `rationale`, `author`, exact `base_snapshot`, optional target IDs and intent, and a nonempty `edits` list. Each edit names a project-relative `.tex` path, exact `before_sha256` (null only for a new file), and either `operation: "write"` with complete UTF-8 `content`, or `operation: "delete"`.

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> change prepare --file proposal.json
python3 <skill-dir>/scripts/math_project.py --project <root> change show <change-ID>
python3 <skill-dir>/scripts/math_project.py --project <root> change apply <change-ID>
```

Preparation saves a diff and structural analysis without changing sources. Application checks the exact baseline, rejects structural errors, writes through a recovery journal and imports the result. `--no-import` leaves import as a separate action. Only declared source roots/entrypoints can be edited. Unreachable added files must be connected through the entrypoint or source configuration. Pending or inconsistent journals are handled by `change recover`; preserve unresolved versions when recovery detects an unrelated edit.

## Durable tasks

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> task add --title 'Repair the quotient construction' --target NA-000042 --acceptance-file acceptance.txt
python3 <skill-dir>/scripts/math_project.py --project <root> task claim <task-ID> --assignee author-1
python3 <skill-dir>/scripts/math_project.py --project <root> task checkpoint <task-ID> --assignee author-1 --file checkpoint.json
python3 <skill-dir>/scripts/math_project.py --project <root> task show <task-ID>
```

Checkpoint JSON contains `summary`, `evidence` (objects with kind/summary and relevant data), `artifacts` (project-relative regular files), and a concrete `next_step`. Evidence is substantive work, not elapsed time. To finish, the latest checkpoint needs `{ "kind": "acceptance", "outcome": "satisfied", "summary": "actual reason" }` plus supporting analysis/test/review evidence or a current hashed artifact.

Use `task transition <ID> done --assignee <name>` to finish after satisfying prerequisites and freshness. Other states are `ready`, `running`, `blocked`, `review`, and `cancelled`; permitted transitions are enforced. `task resume` reports changed inputs and restores active ownership where allowed. `--expected-revision <integer>` supports optimistic concurrency. Requeue with a concrete reason before changing owners.

Create dependencies with repeated `--depends-on` on `task add`, or edit them with `task dependencies <ID> --depends-on <other-ID>`. Missing and cyclic dependencies are rejected. `task list --all` includes closed work. `--acknowledge-change <item-ID>` plus a concrete reason can acknowledge changed checkpoint inputs, but never replaces the required evidence or mathematical review.

## Releases and local export

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> export --destination exports/draft-01
python3 <skill-dir>/scripts/math_project.py --project <root> release create v1 --target NA-000042
python3 <skill-dir>/scripts/math_project.py --project <root> export --destination exports/v1 --mode reviewed --release v1
```

A release freezes the complete selected prerequisite closure, exact snapshot, chosen proofs, reviews, applications, sources, contexts, and admissions. Names cannot be reused. `release list` shows the registered manifests. A reviewed export requires a frozen release; a preview cannot be relabeled as reviewed. Historical exports do not borrow current review judgments.

Destinations must be new project-contained directories outside source and metadata roots. Existing directories are not overwritten. The current exporter uses Linux atomic no-replace promotion and fails safely if unavailable. HTML displays readable original TeX with stable links and separate provenance; full mathematical typesetting remains the LaTeX build's role. Nothing is uploaded or published externally.

## Read-only search for other AIs

```bash
python3 <skill-dir>/scripts/math_project.py --project <root> api export --release v1 --destination <new-absolute-directory>
```

This owner operation creates a separate public corpus and portable REST/MCP reader; see [read-only API](read-only-api.md). It accepts a registered reviewed release, optional public `--title`, and explicit `--demo` labeling. Unlike local atlas export, its new destination may be outside the project, supporting flat source roots. The server reads only the filtered projection and exposes no maintenance operations. Do not host the original release or atlas as the public API: those internal exports may contain source material beyond the selected results.
