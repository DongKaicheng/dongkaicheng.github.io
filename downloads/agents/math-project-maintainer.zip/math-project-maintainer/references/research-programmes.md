# Results, implications, and research programmes

Use this workflow to organize an original research project or synthesize its progress. Keep the existing sources, permanent IDs, snapshots, applications, and review records authoritative. An outline is a derived reading view, not a replacement theorem database.

## Recover the complete requested scope

Inventory the sources actually selected by the user and the latest accessible versions. Record unavailable archives or chat-only summaries explicitly; do not imply that all conversations or proofs were recovered. Continue with available material and name the precise missing import. Reconcile repeated results by mathematical content and source version, not merely similar titles. Preserve aliases and historical corrections.

Account for every recovered established or partly established case in that scope, including results with unfinished analytic inputs, restricted domains, and failed or superseded arguments when they explain an active obstacle. Do not equate a compact homepage with a smaller mathematical inventory. A result may be nested as a consequence without disappearing from the coverage ledger.

For each case recover:

- exact statement and source locator/version;
- objects, domain, codimensions or degrees, hypotheses, normalization, and the properties asserted;
- complete available proof, partial proof, or proof not recovered;
- the established argument, its actual premises, and the first unresolved inference;
- separate review evidence and whether the intended conclusion remains conditional;
- its relation to broader results and the precise gap to the long-term target.

For a height pairing, specify both factors and the target, the equivalence relation on cycles, the ground field and local normalizations, and which of existence, choice independence, rational-equivalence descent, bilinearity, symmetry, functoriality, and comparison have been established. Include only properties relevant to the selected construction. A complete geometric deduction conditional on an analytic statement is useful progress; label the conditional premise at its point of use. A missing proof is a recovery gap, not evidence that the statement is false.

## Separate relation types

Record directions explicitly. The following are reading-view relations; they do **not** extend the engine's application enum (`uses`, `mention`, `internal`). Map actual theorem uses into that existing workflow.

| Relation | Required meaning and evidence |
| --- | --- |
| Implication | All displayed premises imply the conclusion; give the deduction or exact application. |
| Conditional implication | The conclusion follows after the stated additional hypotheses; preserve those hypotheses in every summary of the arrow. |
| Special case | Identify the substitution or restriction of the parent statement and check every assumption. |
| Proof dependency | This proof uses the input; other inputs may also be needed. It is not automatically an implication from that one input. |
| Alternative route | Another proposed or established proof strategy for the same target; do not require both alternatives. |
| Analogy | A comparison suggesting a method, with no deduction asserted. |
| Navigation | Reading hierarchy or topic membership, with no mathematical support inferred. |
| Work order | A scheduling prerequisite, distinct from theorem support. |

If a result or conjecture B follows from A in the intended scope, place B under A as a consequence or specialization and retain B's permanent link. Choose a useful primary parent for reading, but retain all other premises and backlinks. In particular, an argument using A and H gives `(A and H) => B`, not `A => B`; nesting B under A must still display H. Do not conceal extra hypotheses in a distant audit note. If the relationship is only proposed, mark it as proposed and identify the needed deduction.

Collapse only duplicate presentations, not distinct statements, alternative proofs, or unresolved cases. Do not flatten a dependency-sensitive family into chronological research rounds. Do not turn the entire support DAG into a single-parent tree: reading order and mathematical support have different jobs. A reciprocal pair of established implications can be an equivalence; a navigation cycle is still unsuitable, and a cycle of unproved prerequisites is not a proof.

## Formulate the programme mathematically

Start with exact ambient data and the final target, including quantifiers, object types and required properties. Use conventional mathematical names for constructions and problems. Put ordinary explanations on an overview page and full definitions, statements, deductions and references in the formal programme manuscript through `math-writing-editor`.

For each proposed stage state, in mathematical prose:

1. The precise problem or conjecture and the current inputs.
2. The mechanism to try: a construction, reduction, estimate, vanishing, comparison, or descent argument.
3. The exact output and the downstream problem for which it supplies an input.
4. The core obstruction and what would establish that the stage is complete.

Distinguish proved reductions from conjectural bridges. Write and prove a conditional assembly proposition when the supplied deductions warrant one; otherwise state an open assembly problem. A list of task names or arrows is not a research programme. Give alternative approaches as alternatives to a named obligation and explain their different unresolved interfaces.

If a proposed arrow fails, retain a still-meaningful downstream objective as a separate problem. If the target itself has a counterexample, mark the formulation as refuted and distinguish a proposed repair from the original target; “open” is not an appropriate label for a false statement.

For local-to-global height programmes, keep local existence, canonical choices, global summation and Chow descent, comparison with established pairings, positivity, and finiteness separate until the requisite deductions are available. Local Green-form existence alone does not supply all global height axioms. Positive definiteness alone does not imply a Northcott statement; specify the arithmetic set, discreteness or lattice hypotheses, and any finite-generation input actually used.

Preserve project-specific targets from the source. For the strong zero-curvature Green programme this includes the prescribed support complement, the full actual test class, the fixed original valued field, the category of Green forms, and normalized finite descent when required. These are not interchangeable with currents, fewer tests, enlarged supports, or a solution after an unspecified extension. Do not impose these particular conditions on unrelated projects.

## Check the derived view

Use the optional read-only helper when a machine-readable outline is useful:

```bash
python3 <skill-dir>/scripts/research_outline.py outline.json
```

It checks the structural contract below, not the truth of assertions, completeness of the source search, validity of locators, freshness against `mpm`, or quality of prose. Compare its input to the actual snapshot and application records before publication. It never writes to the project or promotes a theorem status.

| Field | Contract |
| --- | --- |
| `schema`, `snapshot`, `scope` | Integer `1`, exact recorded snapshot/release identifier, and task-selected scope description. |
| `sources` | Objects with `id`, `locator`, and `availability`: `available`, `summary_only`, or `missing`. |
| `required_ids` | All recovered result/problem IDs within this scope; each must have a record. Preserve existing IDs. |
| `records` | Objects with `id`, `source_ids`, `statement_ref`, `domain`, `hypotheses`, `proof_state`, `proof_refs`, and `open_obligations`. References point to existing content, not copied proofs. |
| `proof_state` | `complete`, `partial`, `not_recovered`, or `not_applicable`. This describes recovered proof text, not independent acceptance. Complete and partial proofs require references; partial/missing proof records require a concrete open obligation. A summary-only source cannot establish recovered proof completeness. |
| `relations` | Objects with `id`, `kind`, `premises`, `conclusion`, `extra_hypotheses`, `state` (`established` or `proposed`), and `justification_ref` when established. All premises are jointly needed for this relation; alternatives are separate relations. |
| `placements` | One per displayed record: `id`, `parent` (ID or null), `relation` (ID or null). Consequence nesting cites an implication/conditional implication/special-case relation containing the parent among its premises. Render that relation's full premises and extra hypotheses. Topic grouping uses navigation rather than pretending to be a consequence. |
| `steps` | Objects with `id`, `target`, `inputs`, `problem_ref`, `output_ref`, `mechanism`, `obstruction`, and `acceptance`. References identify formal mathematical problems and outputs. |

Keep empty lists explicit. `statement_ref` may be null only for a `not_recovered` record; retain its provenance and recovery obligation. `proof_refs` must be empty for `not_recovered` or `not_applicable`. References and domains are inspected text, not authority inferred from a nonempty string. Missing sources remain warnings because useful partial work can continue; report them rather than calling the whole source corpus recovered.
