#!/usr/bin/env node
// Owner-side packaging only. The resulting Worker contains no filesystem access.
import { readFile, mkdir, writeFile } from 'node:fs/promises';
import { createHash } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, resolve, join } from 'node:path';

const base = dirname(fileURLToPath(import.meta.url));
function canonical(value) {
  if (Array.isArray(value)) return '[' + value.map(canonical).join(',') + ']';
  if (value && typeof value === 'object') return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + canonical(value[k])).join(',') + '}';
  return JSON.stringify(value);
}
export function verifyCorpus(corpus) {
  if (corpus?.schema_version !== 1 || corpus.format !== 'math-project-public-corpus' || corpus.release?.kind !== 'reviewed_release') throw new Error('Expected a public corpus from api export, not an internal release or preview.');
  const { corpus_id, ...payload } = corpus;
  const actual = createHash('sha256').update(canonical(payload)).digest('hex');
  if (corpus_id !== actual) throw new Error('Public corpus hash does not match its contents. Re-export the intended reviewed release.');
  return corpus;
}
export async function readCorpus(path = join(base, 'public-corpus.json')) {
  return verifyCorpus(JSON.parse(await readFile(path, 'utf8')));
}
async function main() {
  const args = process.argv.slice(2);
  if (args.length && args[0] === '--help') {
    console.log('node build.mjs [--output NEW_WORKER_FILE]\nBuild a standalone Cloudflare Worker from this exported public corpus. No owner project is needed.');
    return;
  }
  if (args.length && (args.length !== 2 || args[0] !== '--output')) throw new Error('Usage: node build.mjs [--output NEW_WORKER_FILE]');
  const output = args.length ? resolve(args[1]) : join(base, 'dist/server/index.js');
  if (['public-corpus.json','runtime.mjs','index.html','serve.mjs','build.mjs'].some(n => output === join(base, n))) throw new Error('Build output must not replace its input files.');
  const corpus = await readCorpus();
  const { createReadonlyAPI } = await import('./runtime.mjs');
  const checked = await createReadonlyAPI(corpus).fetch(new Request('https://validation.invalid/api/v1/project'));
  if (!checked.ok) throw new Error('Public reader validation failed before packaging.');
  const [runtime, html] = await Promise.all([readFile(join(base,'runtime.mjs'),'utf8'),readFile(join(base,'index.html'),'utf8')]);
  if (!runtime.includes('export function createReadonlyAPI')) throw new Error('Unsupported runtime entry point.');
  const code = runtime.replace('export function createReadonlyAPI','function createReadonlyAPI') + '\nconst PUBLIC_CORPUS = ' + JSON.stringify(corpus) + ';\nconst READER_HTML = ' + JSON.stringify(html) + ';\nexport default createReadonlyAPI(PUBLIC_CORPUS, {html: READER_HTML});\n';
  await mkdir(dirname(output), { recursive: true });
  // Refuse an existing output. Publishing a new version is an explicit owner operation.
  await writeFile(output, code, { encoding:'utf8', flag:'wx' });
  console.log(JSON.stringify({output,corpus_id:corpus.corpus_id,release_id:corpus.release.id,items:Object.keys(corpus.items).length,bytes:Buffer.byteLength(code)}));
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) main().catch(error => {console.error(error.message);process.exitCode=1;});
