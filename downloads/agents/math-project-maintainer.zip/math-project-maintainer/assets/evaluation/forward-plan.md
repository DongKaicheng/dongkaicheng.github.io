# Forward evaluation plan

This plan separates development tests from a fresh mathematical review of raw
inputs. It is an evaluator document. A case reviewer receives the selected case
directory, the installed skill, and a neutral request; the reviewer does not
receive this plan, answer keys, development commentary, or previous reviews.

## 1. Freeze what is being evaluated

Before the first fresh review, record the skill's Git revision or a hash manifest
of its current files, the case source hashes, and the exact request. The source
hashes from the initial syntax check are in `validation.json`; regenerate the
manifest if a fixture changes. Save the answer keys before collecting reviews.
Do not alter an expected verdict to make an observed response pass. If a reviewer
finds an error in an answer key, record and justify that correction separately.

The fixture author has seen all answers and cannot serve as a blind reviewer.
Use a newly spawned context with no inherited conversation, or an equivalently
isolated new session. Supplying only a new user message in an existing context
does not remove earlier knowledge. Give each reviewer access to the installed
skill's instructions and necessary references, plus only its selected input
directory. A reviewer may inspect the implementation to use it correctly.

## 2. Evaluate mathematical review on all twelve raw cases

For each entry in `manifest.json`, supply `task.json` and the listed input files.
Use the task's wording without adding a hint about the intended error or verdict.
The case directories are self-contained. Counterexamples or alternative proofs
different from those in an answer key are acceptable when they are correct and
address the same claim.

Prefer a separate fresh context for each case. If resource limits require a
batch, keep the C005/C006 pair and the C008/C009 pair in different contexts, and
record which cases shared context. Save the complete review before opening its
answer key. A neutral request is:

> Use the installed math-project-maintainer skill to complete the task described
> in this case's task.json. Work from the supplied mathematical sources. Record
> your review, its exact inputs, and any material uncertainty. Use an isolated
> temporary project when executing the toolkit. Read only this case directory
> among the evaluation assets; do not read answer keys or prior case reviews.

The reviewer should determine the status of the assertion and the supplied
argument, justify material findings, and distinguish a repaired theorem from
the original target. A dependency plan is conditional on the given judgments and
foundations. A successful parse or graph computation does not replace the
mathematical review.

## 3. Evaluate actual maintenance behavior

In fresh temporary project copies, execute the finished skill's documented
operations for the integration scenarios in `scenarios.json`. Read the actual
installed help and references for the supported interface; these fixtures do
not prescribe an invented command.

The important observations are retained identity after a justified move,
revision-bound reviews and applications, changed effective contexts, explicit
impact witnesses, alternative proof selection, and source freshness before a
decision. Capture the initial and revised snapshot IDs, affected item IDs,
review/application records, recheck tasks, support report, and exact operations
executed. Compare the stored source bytes with the intended snapshots.

For contextual changes, make the association explicit through the supported
context mechanism. If a convention is maintained as a separate declared context,
update that declaration as well as the source text, and report that dependency.
Do not imply that a parser inferred an unstated contextual association. If the
skill cannot carry out a required operation, record the limitation instead of
substituting a mock operation.

For issue handling, exercise both a defect in one proof and a defect in a
statement. The first should leave an independently accepted alternative
available; the second should block every alternative until the statement issue
is resolved and the relevant judgment is reconsidered. A review packet prepared
before a material issue change must not become a current acceptance merely by
being submitted later. Nonblocking editorial notes should remain nonblocking.

## 4. Score explanations and behavior separately

After saving a review, compare it with its answer key. For each criterion record
`pass`, `partial`, `fail`, or `not_applicable`, together with a short quotation
or exact output location supporting the score. Do not score by keyword matching.

| Criterion | Evidence to inspect |
| --- | --- |
| Mathematical status | Truth of the assertion and adequacy of the supplied proof are distinguished correctly. |
| Critical reasoning | A valid witness, argument, or support-plan obstruction establishes the material finding. |
| Exact scope | Hypotheses, ambient spaces, domains, normalization, and quantifiers match the actual source. |
| Valid controls | Correct statements, proofs, and legitimate alternatives are accepted without unnecessary assumptions. |
| Repair | The suggested change is mathematically sufficient and any change of target is explicit. |
| Provenance | Sources, assumptions, admissions, and reviewer judgments remain identifiable and revision-bound. |
| Executed workflow | Required operations actually ran, with records that demonstrate their claimed behavior. |

A missed blocking mathematical error, a false rejection of a valid control, or a
claim of formal verification from parsing is a material failure. Classify the
failure by kind so that one scalar score does not hide which capability failed.
Report the numerator and denominator for each applicable criterion, not merely
an overall percentage. Keep mathematical-review outcomes separate from passing
software tests and successful compilation.

## 5. Report coverage and limits

These examples cover elementary algebra, general topology, non-Archimedean
seminorms, and maintenance semantics. They do not establish reliable discovery
of new proofs, correctness of advanced research arguments, or the ability to
automatically verify an entire Stacks-sized corpus. Include scale and real-source
import observations separately when available. State which cases were freshly
reviewed, which operations were actually executed, and which assessments remain
an evaluator's mathematical judgment.

Preserve failed reviews and their first observed outputs. Fixes may be followed
by a new run against the same frozen case, but label it as a rerun; do not count
the improved result as an independent first attempt.
