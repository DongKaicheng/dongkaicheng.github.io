# Pairings in a synthetic project

This is an original fixture, not a claim about Beilinson--Bloch heights. The selected source set is this file plus the unrecovered archive identified below. The long-term target is a canonical continuous pairing on completed quotients of the given normed vector spaces.

## A — Quotient pairings

Let V,W be rational vector spaces, N a subspace of V, M a subspace of W, and b:V×W→R a Q-bilinear map. Assume b(N,W)=0 and b(V,M)=0. Then there exists a unique Q-bilinear map bbar:(V/N)×(W/M)→R satisfying bbar(v+N,w+M)=b(v,w).

Proof. Replacing v,w by v+n,w+m changes the value by b(n,w)+b(v,m)+b(n,m), which is zero by the two assumptions. The map is consequently well defined and bilinear. Surjectivity of the quotient maps gives uniqueness.

## B — A restricted pairing

Let S⊂V and T⊂W be subspaces satisfying b(S∩N,T)=0 and b(S,T∩M)=0. Applying A to b restricted to S×T gives a pairing (S/(S∩N))×(T/(T∩M))→R. These weaker assumptions do not require b(N,W)=0 or b(V,M)=0 on all of V,W. This deduction has been supplied, but no independent review is recorded.

## C — Completion

Suppose that the spaces in A carry norms and that the descended map satisfies |bbar(x,y)|≤C||x||||y||. A draft attempts to extend it to the completions by bbarhat(x,y)=lim bbar(x_j,y_j). The draft only says that the limit is independent of approximating sequences; no Cauchy estimate or independence argument is present. The intended statement includes existence, continuity and uniqueness on both completions. This is currently a partial construction.

## D — Claimed weaker estimate

An earlier archive called `uniform-estimate.zip` reportedly replaces the joint bound in C by separate boundedness. Only this description is available. Its hypotheses, proof, version and review have not been recovered.

## Draft navigation

The proposed Progress page lists A and C only. It labels C “completion established”. It puts B under A with the sentence “The pairing in B is the restriction of the pairing on V/N and W/M”, and the plan says “A therefore proves the completed-quotient target”.
