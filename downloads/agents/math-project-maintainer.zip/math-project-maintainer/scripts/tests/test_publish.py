"""Publication scope, provenance, HTML safety, and immutable release tests."""
from copy import deepcopy
import hashlib
from html.parser import HTMLParser
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from urllib.parse import unquote, urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj import publish
from mathproj.project import ingest, resolve_item, set_foundation
from mathproj.publish import create_release, export_project
from mathproj.store import ProjectError, ProjectStore, digest
from mathproj.sources import cite_source, register_source
from mathproj.workflow import application_templates, prepare_review, record_applications, record_review, resolve_issue


SOURCE = r"""\section{Foundations and applications}\label{sec-foundations}
\begin{lemma}[Admitted premise]\label{base}
The explicitly admitted premise holds.
\end{lemma}
\begin{proof}
A source proof is retained without being used for its admission.
\end{proof}
\begin{lemma}[Principal result]\label{main}
The principal conclusion holds.
\end{lemma}
\begin{proof}
Apply \ref{base} to obtain the principal conclusion.
\end{proof}
\begin{proof}
A draft alternative uses \ref{draft}.
\end{proof}
\begin{lemma}[Unreviewed auxiliary claim]\label{draft}
This auxiliary claim has not been reviewed.
\end{lemma}
\begin{proof}
An unfinished justification.
\end{proof}
"""


class InspectHTML(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.tags, self.ids, self.hrefs, self.attributes = [], set(), [], []

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        self.attributes.extend(attrs)
        values = dict(attrs)
        if "id" in values:
            self.ids.add(values["id"])
        if "href" in values:
            self.hrefs.append(values["href"])


class PublishTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, 'Atlas <&> "test"', namespace="ATLAS")
        self.source = self.root / "content" / "main.tex"
        self.source.write_text(SOURCE, encoding="utf-8")
        ingest(self.store)
        state = self.store.state()
        self.base, self.main, self.draft = [resolve_item(state, label) for label in ("base", "main", "draft")]
        self.proofs = state["items"][self.main]["proof_ids"]
        self.assertEqual(len(self.proofs), 2)

    def tearDown(self):
        self.temp.cleanup()

    def accept(self, item_id, proof_id=None):
        if proof_id:
            records = application_templates(self.store, proof_id)["records"]
            for record in records:
                record.update(substitution="Use the objects in the displayed statement.", hypotheses=[], no_hypotheses=True,
                              conclusion="The cited conclusion gives this fixture's next step.",
                              justification="This fixture has an explicitly unconditional premise.", reviewer="fixture-reviewer")
            if records:
                record_applications(self.store, records)
        report = prepare_review(self.store, item_id, proof_id)["template"]
        report.update(reviewer={"id": "fixture-reviewer", "kind": "human", "independent": True, "author_of_change": False},
                      verdict="accept", summary="Checked the explicit fixture assumptions, inference, and scope.")
        for check in report["checks"]:
            check.update(status="pass", reason="Examined the corresponding displayed fixture data.")
        return record_review(self.store, report)["review"]

    def ready_release(self, name="v1"):
        set_foundation(self.store, self.base, "An explicit assumption for this publication fixture.", kind="assumption")
        self.accept(self.main, self.proofs[0])
        return create_release(self.store, name, [self.main])

    def register_reference(self, key="fixture", *, version="fixture-v1", previous_revision=None, status="checked"):
        record = {"title": "Supplied publication fixture", "uri": "https://example.invalid/publication-fixture",
                  "version": version, "status": status, "checked_by": "fixture-reviewer", "accessed_at": "2026-11-16",
                  "notes": "Synthetic evidence supplied by this test; no external fetch is claimed."}
        if previous_revision is not None:
            record["previous_revision"] = previous_revision
        return register_source(self.store, key, record)["source"]

    def cite_reference(self, item_id, source, *, proof_id=None, previous_revision=None, status="checked"):
        state = self.store.state()
        inspected = "The explicitly admitted premise holds in this synthetic fixture."
        record = {"citation_key": "fixture-premise", "source_revision": source["revision"],
                  "declaration_revision": state["items"][item_id]["declaration_revision"],
                  "proof_id": proof_id, "proof_revision": state["proofs"][proof_id]["revision"] if proof_id else None,
                  "status": status, "locator": {"theorem": "Fixture premise", "page": "1"},
                  "supporting_statement": inspected, "assumptions": [], "no_assumptions": True,
                  "substitution": "Use the displayed fixture premise.", "conclusion": "The local premise is available.",
                  "justification": "The supplied evidence and local fixture use the same premise.",
                  "inspected_text": inspected, "checked_by": "fixture-reviewer", "accessed_at": "2026-11-16"}
        if previous_revision is not None:
            record["previous_revision"] = previous_revision
        return cite_source(self.store, item_id, source["key"], record)["citation"]

    def objection(self, scope="statement", proof_id=None):
        report = prepare_review(self.store, self.main, proof_id or self.proofs[1])["template"]
        report.update(reviewer={"id": "objection-reviewer", "kind": "human", "independent": True, "author_of_change": False},
                      verdict="changes_required", summary="A concrete fixture objection remains to be resolved.",
                      findings=[{"scope": scope, "severity": "error", "title": "A premise needs explanation",
                                 "reason": "The displayed scope needs further justification.",
                                 "required_action": "Resolve the stated scope question and record a fresh review."}])
        for check in report["checks"]:
            check.update(status="issue" if check["name"] == "scope" else "pass", reason="This check records the fixture objection.")
        return record_review(self.store, report)["issues"][0]

    def export_release(self, name="v1", destination="exports/reviewed"):
        return export_project(self.store, destination, mode="reviewed", release_id=name)

    def files(self, directory):
        return {str(path.relative_to(directory)): path.read_bytes() for path in Path(directory).rglob("*") if path.is_file()}

    def test_preview_is_conspicuous_and_does_not_create_a_release(self):
        result = export_project(self.store, "exports/preview")
        index = Path(result["index"]).read_text(encoding="utf-8")
        self.assertIn("Draft preview", index)
        self.assertIn("not a reviewed release", index)
        self.assertIn("Foundations and applications", index)
        self.assertIn("Atlas &lt;&amp;&gt; &quot;test&quot;", index)
        self.assertEqual(self.store.state()["releases"], {})
        self.assertFalse((Path(result["output"]) / "release.json").exists())
        self.assertTrue((Path(result["output"]) / "preview.json").is_file())

    def test_reviewed_release_freezes_selected_closure_and_admitted_assumptions(self):
        result = self.ready_release()
        self.assertEqual(set(result["included"]), {self.base, self.main})
        self.assertEqual(result["selected_proofs"], {self.main: self.proofs[0]})
        self.assertEqual(result["admitted_inputs"], [self.base])
        manifest = json.loads(Path(result["manifest"]).read_text(encoding="utf-8"))
        self.assertEqual(manifest["kind"], "reviewed_release")
        self.assertEqual(digest(manifest["snapshot_data"]), manifest["snapshot"])
        self.assertEqual(digest({key: value for key, value in manifest.items() if key != "id"}), result["release_id"])
        self.assertIn("issue_context", next(iter(manifest["state"]["reviews"].values()))["binding"])
        self.assertIn("citations", manifest["state"])
        self.assertIn("source_records", manifest["state"])
        exported = self.export_release()
        directory = Path(exported["output"])
        main_page = (directory / "items" / f"{self.main}.html").read_text(encoding="utf-8")
        base_page = (directory / "items" / f"{self.base}.html").read_text(encoding="utf-8")
        self.assertIn("Selected proof in the frozen support plan", main_page)
        self.assertIn("Alternative proof from the source; not part of this release", main_page)
        self.assertIn("outside this export", main_page)
        self.assertFalse((directory / "items" / f"{self.draft}.html").exists())
        self.assertIn("Explicitly admitted input", base_page)
        self.assertIn("An explicit assumption", base_page)
        self.assertIn(f"{self.main}.html#{self.main}", base_page)

    def test_eligible_alternative_does_not_enlarge_the_selected_closure(self):
        self.ready_release("first")
        set_foundation(self.store, self.draft, "Separate input for the alternative fixture proof.", kind="assumption")
        self.accept(self.main, self.proofs[1])
        release = create_release(self.store, "two-eligible", [self.main])
        self.assertEqual(release["selected_proofs"][self.main], self.proofs[0])
        self.assertNotIn(self.draft, release["included"])
        frozen = json.loads(Path(release["manifest"]).read_text(encoding="utf-8"))
        self.assertTrue(frozen["support"]["eligibility"][self.proofs[1]]["eligible"])
        result = self.export_release("two-eligible")
        page = (Path(result["output"]) / "items" / f"{self.main}.html").read_text(encoding="utf-8")
        self.assertIn("not part of this release&#x27;s support plan", page)

    def test_shared_prerequisite_diamond_is_fully_included_once(self):
        addition = r"""\begin{lemma}\label{left}Left result.\end{lemma}
\begin{proof}Apply \ref{base}.\end{proof}
\begin{lemma}\label{right}Right result.\end{lemma}
\begin{proof}Apply \ref{base}.\end{proof}
\begin{lemma}\label{top}Top result.\end{lemma}
\begin{proof}Apply \ref{left} and \ref{right}.\end{proof}
"""
        self.source.write_text(SOURCE + addition, encoding="utf-8")
        ingest(self.store)
        state = self.store.state()
        left, right, top = [resolve_item(state, label) for label in ("left", "right", "top")]
        set_foundation(self.store, self.base, "Explicit premise for the diamond.", kind="assumption")
        for iid in (left, right, top):
            self.accept(iid, state["items"][iid]["proof_ids"][0])
        release = create_release(self.store, "diamond", [top])
        self.assertEqual(set(release["included"]), {self.base, left, right, top})
        manifest = json.loads(Path(release["manifest"]).read_text(encoding="utf-8"))
        order = manifest["support"]["order"]
        self.assertLess(order.index(self.base), order.index(left))
        self.assertLess(order.index(left), order.index(top))
        self.assertLess(order.index(right), order.index(top))

    def test_unreviewed_or_stale_sources_cannot_become_a_release(self):
        before = len(self.store.history())
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "draft", [self.main])
        self.assertEqual(len(self.store.history()), before)
        self.assertEqual(list((self.store.meta / "releases").iterdir()), [])
        self.ready_release("good")
        self.source.write_text(SOURCE.replace("The principal conclusion holds.", "The edited conclusion differs."), encoding="utf-8")
        with self.assertRaisesRegex(ProjectError, "Import current"):
            create_release(self.store, "stale", [self.main])
        ingest(self.store)
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "new-unreviewed", [self.main])

    def test_default_release_requires_support_for_every_mathematical_target(self):
        self.ready_release("partial")
        with self.assertRaisesRegex(ProjectError, self.draft):
            create_release(self.store, "all-items")
        with self.assertRaisesRegex(ProjectError, "nonempty"):
            create_release(self.store, "empty", [])

    def test_statement_wide_issue_blocks_every_alternative_and_needs_new_review(self):
        self.ready_release("before-objection")
        issue_id = self.objection("statement")
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "blocked", [self.main])
        resolve_issue(self.store, issue_id, reason="The fixture objection is now explicitly discharged.", reviewer="resolution-reviewer")
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "resolved-without-review", [self.main])
        self.accept(self.main, self.proofs[0])
        release = create_release(self.store, "freshly-reviewed", [self.main])
        frozen = json.loads(Path(release["manifest"]).read_text(encoding="utf-8"))
        self.assertEqual(frozen["state"]["issues"][issue_id]["status"], "resolved")

    def test_alternative_proof_specific_issue_does_not_block_selected_proof(self):
        self.ready_release("before-objection")
        issue_id = self.objection("proof", self.proofs[1])
        release = create_release(self.store, "selected-remains-supported", [self.main])
        frozen = json.loads(Path(release["manifest"]).read_text(encoding="utf-8"))
        self.assertEqual(frozen["state"]["issues"][issue_id]["status"], "open")
        self.assertEqual(frozen["support"]["selected_proofs"][self.main], self.proofs[0])

    def test_historical_release_is_byte_reproducible_after_current_changes(self):
        release = self.ready_release()
        first = self.export_release(destination="exports/first")
        expected = self.files(first["output"])
        self.source.write_text(SOURCE.replace("The principal conclusion holds.", "A later unrelated version of the conclusion."), encoding="utf-8")
        ingest(self.store)
        manifest = self.store.manifest()
        manifest["name"] = "A later project title"
        self.store.manifest_path.write_text(json.dumps(manifest), encoding="utf-8")
        # The current source and manifest are now irrelevant to the frozen
        # review content, except for protecting live source output paths.
        second = self.export_release(release["release_id"], "exports/second")
        self.assertEqual(expected, self.files(second["output"]))
        historical = json.loads((Path(second["output"]) / "release.json").read_text(encoding="utf-8"))
        self.assertEqual(historical["id"], release["release_id"])
        self.assertNotEqual(historical["snapshot"], self.store.state()["current_snapshot"])

    def test_old_preview_does_not_borrow_current_review_judgments(self):
        old_snapshot = self.store.state()["current_snapshot"]
        release = self.ready_release()
        self.source.write_text(SOURCE.replace("The principal conclusion holds.", "An updated conclusion."), encoding="utf-8")
        ingest(self.store)
        result = export_project(self.store, "exports/historical", snapshot=old_snapshot)
        data = json.loads((Path(result["output"]) / "preview.json").read_text(encoding="utf-8"))
        self.assertEqual(data["state"]["reviews"], {})
        self.assertEqual(data["support"]["selected_proofs"], {})
        self.assertIn("Historical source preview", Path(result["index"]).read_text(encoding="utf-8"))
        self.assertIsNotNone(release["release_id"])

    def test_pending_source_changes_are_visible_in_preview(self):
        self.source.write_text(SOURCE + "% a pending source edit\n", encoding="utf-8")
        result = export_project(self.store, "exports/pending")
        self.assertIn("changed since import", Path(result["index"]).read_text(encoding="utf-8"))

    def test_hostile_text_is_escaped_and_every_local_link_resolves(self):
        hostile = '<script>alert("x")</script><img src=x onerror="alert(1)">' 
        self.source.write_text(SOURCE.replace("The principal conclusion holds.", hostile), encoding="utf-8")
        ingest(self.store)
        result = export_project(self.store, "exports/safe")
        directory = Path(result["output"])
        parsed = {}
        for file in directory.rglob("*.html"):
            parser = InspectHTML()
            parser.feed(file.read_text(encoding="utf-8"))
            parsed[file.resolve()] = parser
            self.assertNotIn("script", parser.tags)
            self.assertNotIn("img", parser.tags)
            self.assertFalse(any(name.lower().startswith("on") for name, _ in parser.attributes))
        page = (directory / "items" / f"{self.main}.html").read_text(encoding="utf-8")
        self.assertIn("&lt;script&gt;", page)
        self.assertIn("&lt;img", page)
        self.assertIn(f"{self.base}.html#{self.base}", page)
        for file, parser in parsed.items():
            for href in parser.hrefs:
                url = urlsplit(href)
                self.assertEqual(url.scheme, "")
                self.assertEqual(url.netloc, "")
                target = (file.parent / unquote(url.path)).resolve() if url.path else file
                self.assertTrue(target.is_relative_to(directory.resolve()), href)
                self.assertTrue(target.is_file(), href)
                if url.fragment:
                    self.assertIn(unquote(url.fragment), parsed[target].ids, href)

    def test_export_hash_manifest_matches_every_generated_file(self):
        result = export_project(self.store, "exports/checksums")
        directory = Path(result["output"])
        manifest = json.loads((directory / "export.json").read_text(encoding="utf-8"))
        for filename, checksum in manifest["files"].items():
            self.assertEqual(hashlib.sha256((directory / filename).read_bytes()).hexdigest(), checksum)
        self.assertEqual(len(manifest["files"]) + 1, result["files"])

    def test_export_modes_cannot_relabel_a_draft_as_reviewed(self):
        for kwargs in ({"mode": "reviewed"}, {"mode": "release"}, {"release_id": "absent"}):
            with self.assertRaises(ProjectError):
                export_project(self.store, "exports/invalid", **kwargs)
        self.ready_release()
        with self.assertRaisesRegex(ProjectError, "cannot be overridden"):
            export_project(self.store, "exports/wrong-scope", mode="reviewed", release_id="v1", targets=[self.draft])
        with self.assertRaisesRegex(ProjectError, "cannot be overridden"):
            export_project(self.store, "exports/wrong-snapshot", mode="reviewed", release_id="v1", snapshot=self.store.state()["current_snapshot"])

    def test_release_names_and_manifests_are_immutable(self):
        release = self.ready_release()
        before = Path(release["manifest"]).read_bytes()
        events = len(self.store.history())
        with self.assertRaisesRegex(ProjectError, "already frozen"):
            create_release(self.store, "v1", [self.main])
        self.assertEqual(Path(release["manifest"]).read_bytes(), before)
        self.assertEqual(len(self.store.history()), events)
        for name in ("../escape", "/absolute", "a/b", ""):
            with self.assertRaises(ProjectError):
                create_release(self.store, name, [self.main])

    def test_corrupt_release_fails_before_creating_output(self):
        release = self.ready_release()
        path = Path(release["manifest"])
        manifest = json.loads(path.read_text(encoding="utf-8"))
        manifest["name"] = "Tampered archive"
        path.write_text(json.dumps(manifest), encoding="utf-8")
        with self.assertRaisesRegex(ProjectError, "integrity failed"):
            self.export_release()
        self.assertFalse((self.root / "exports" / "reviewed").exists())

    def test_embedded_snapshot_integrity_is_validated_independently(self):
        release = self.ready_release()
        manifest = json.loads(Path(release["manifest"]).read_text(encoding="utf-8"))
        manifest["snapshot_data"]["manifest"]["name"] = "A mismatched embedded snapshot"
        manifest.pop("id")
        new_id = digest(manifest)
        manifest["id"] = new_id
        (self.store.meta / "releases" / f"{new_id}.json").write_text(json.dumps(manifest), encoding="utf-8")
        self.store.transact("test_malformed_archive_registration", lambda state: state["releases"]["v1"].update(
            id=new_id, manifest_sha256=new_id))
        with self.assertRaisesRegex(ProjectError, "source snapshot integrity"):
            self.export_release()

    def test_output_protection_preserves_existing_files_and_rejects_symlinks(self):
        existing = self.root / "exports" / "existing"
        existing.mkdir(parents=True)
        (existing / "keep.txt").write_text("User content", encoding="utf-8")
        (self.root / "linked").symlink_to("exports", target_is_directory=True)
        for destination in ("content/site", "mpm/export", ".", "mathproject.json", "exports/existing", "linked/site", "../outside"):
            with self.subTest(destination=destination):
                with self.assertRaises(ProjectError):
                    export_project(self.store, destination)
        self.assertEqual((existing / "keep.txt").read_text(encoding="utf-8"), "User content")
        self.assertEqual(list(existing.iterdir()), [existing / "keep.txt"])

    def test_destination_race_never_overwrites_even_an_empty_directory(self):
        original = publish._rename_new
        def appear(source, destination, parent_fd):
            os.mkdir(destination, dir_fd=parent_fd)
            return original(source, destination, parent_fd)
        with patch.object(publish, "_rename_new", appear):
            with self.assertRaisesRegex(ProjectError, "appeared"):
                export_project(self.store, "exports/raced")
        self.assertTrue((self.root / "exports" / "raced").is_dir())
        self.assertEqual(list((self.root / "exports" / "raced").iterdir()), [])
        self.assertEqual(list((self.root / "exports").glob(".mpm-export-*")), [])

    def test_partial_render_failure_only_cleans_owned_staging(self):
        exports = self.root / "exports"
        exports.mkdir()
        (exports / "keep.txt").write_text("User file", encoding="utf-8")
        def broken(data):
            yield "items/first.html", b"generated"
            raise ProjectError("Synthetic renderer failure")
        with patch.object(publish, "_render_files", broken):
            with self.assertRaisesRegex(ProjectError, "Synthetic"):
                export_project(self.store, "exports/incomplete")
        self.assertFalse((exports / "incomplete").exists())
        self.assertEqual(list(exports.iterdir()), [exports / "keep.txt"])

    def test_permanent_id_pages_survive_source_relocation(self):
        first = export_project(self.store, "exports/before-move")
        original = json.loads((Path(first["output"]) / "atlas.json").read_text(encoding="utf-8"))["items"]
        self.source.rename(self.source.with_name("relocated.tex"))
        ingest(self.store)
        second = export_project(self.store, "exports/after-move")
        moved = json.loads((Path(second["output"]) / "atlas.json").read_text(encoding="utf-8"))["items"]
        self.assertEqual(original, moved)

    def test_reviewed_declaration_with_no_proof_has_frozen_provenance(self):
        self.source.write_text(SOURCE + r"\begin{definition}\label{notation}A widget is a named object.\end{definition}" + "\n", encoding="utf-8")
        ingest(self.store)
        item_id = resolve_item(self.store.state(), "notation")
        self.accept(item_id)
        release = create_release(self.store, "declaration", [item_id])
        self.assertEqual(release["selected_proofs"], {item_id: item_id + ":declaration"})
        exported = self.export_release("declaration")
        page = (Path(exported["output"]) / "items" / f"{item_id}.html").read_text(encoding="utf-8")
        self.assertIn("Declaration review", page)
        self.assertIn("reviews.html#review-", page)

    def test_external_admission_requires_item_evidence_and_rebind_after_source_change(self):
        source = self.register_reference()
        base_proof = self.store.state()["items"][self.base]["proof_ids"][0]
        self.cite_reference(self.base, source, proof_id=base_proof)
        with self.assertRaisesRegex(ProjectError, "item-level citation"):
            set_foundation(self.store, self.base, "An external result from the supplied fixture.")
        citation = self.cite_reference(self.base, source)
        set_foundation(self.store, self.base, "An external result from the supplied fixture.")
        old = create_release(self.store, "external-v1", [self.base])
        updated = self.register_reference(version="fixture-v2", previous_revision=source["revision"])
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "external-stale", [self.base])
        self.cite_reference(self.base, updated, previous_revision=citation["revision"])
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "external-admission-not-rebound", [self.base])
        set_foundation(self.store, self.base, "Re-examined and admitted the updated fixture source.")
        create_release(self.store, "external-v2", [self.base])
        frozen = json.loads(Path(old["manifest"]).read_text(encoding="utf-8"))
        self.assertEqual(frozen["state"]["source_records"]["fixture"]["revision"], source["revision"])
        self.assertEqual(frozen["support"]["admissions"][self.base]["source_binding"]["citations"],
                         {citation["id"]: citation["revision"]})

    def test_selected_citation_and_source_updates_require_current_review_but_preserve_release(self):
        self.ready_release("before-citation")
        source = self.register_reference()
        citation = self.cite_reference(self.main, source, proof_id=self.proofs[0])
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "citation-without-review", [self.main])
        self.accept(self.main, self.proofs[0])
        release = create_release(self.store, "with-citation", [self.main])
        first = self.export_release("with-citation", "exports/citation-before")
        updated = self.register_reference(version="fixture-v2", previous_revision=source["revision"])
        self.assertEqual(self.store.state()["citations"][citation["id"]]["source_revision"], source["revision"])
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "stale-citation", [self.main])
        self.cite_reference(self.main, updated, proof_id=self.proofs[0], previous_revision=citation["revision"])
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "citation-updated-no-review", [self.main])
        self.accept(self.main, self.proofs[0])
        create_release(self.store, "citation-reviewed-v2", [self.main])
        second = self.export_release(release["release_id"], "exports/citation-after")
        self.assertEqual(self.files(first["output"]), self.files(second["output"]))

    def test_candidate_citation_blocks_selected_subject_but_not_unused_alternative(self):
        self.ready_release("before-candidate")
        source = self.register_reference(status="candidate")
        self.cite_reference(self.main, source, proof_id=self.proofs[1], status="candidate")
        release = create_release(self.store, "unused-candidate", [self.main])
        self.assertEqual(release["selected_proofs"][self.main], self.proofs[0])
        self.cite_reference(self.main, source, status="candidate")
        with self.assertRaisesRegex(ProjectError, "no reviewed support"):
            create_release(self.store, "item-candidate-blocked", [self.main])

    def test_unrelated_uncited_source_does_not_block_reviewed_release(self):
        self.ready_release("before-unused-source")
        self.register_reference(status="candidate")
        result = create_release(self.store, "after-unused-source", [self.main])
        frozen = json.loads(Path(result["manifest"]).read_text(encoding="utf-8"))
        self.assertEqual(frozen["state"]["source_records"]["fixture"]["status"], "candidate")
        self.assertTrue(frozen["support"]["eligibility"][self.proofs[0]]["eligible"])

    def test_historical_preview_preserves_snapshot_bibliography_without_new_review_claims(self):
        source = self.register_reference()
        citation = self.cite_reference(self.main, source, proof_id=self.proofs[0])
        old_snapshot = ingest(self.store)["snapshot"]
        self.register_reference(version="fixture-v2", previous_revision=source["revision"])
        ingest(self.store)
        result = export_project(self.store, "exports/old-bibliography", snapshot=old_snapshot)
        frozen = json.loads((Path(result["output"]) / "preview.json").read_text(encoding="utf-8"))
        self.assertEqual(frozen["state"]["source_records"]["fixture"]["revision"], source["revision"])
        self.assertEqual(frozen["state"]["citations"][citation["id"]]["source_revision"], source["revision"])
        self.assertEqual(frozen["state"]["reviews"], {})


if __name__ == "__main__":
    unittest.main()
