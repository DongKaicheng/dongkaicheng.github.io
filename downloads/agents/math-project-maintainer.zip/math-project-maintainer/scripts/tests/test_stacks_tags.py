"""Exact external-tag navigation without changing local identities or evidence."""

from __future__ import annotations

import hashlib
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from mathproj.project import ingest
from mathproj.stacks_tags import audit_tags, lookup_tags
from mathproj.store import ProjectError, ProjectStore


SOURCE = r"""\title{Algebra}
\phantomsection\label{section-phantom}
\section{Nakayama's lemma}\label{section-nakayama}
\begin{lemma}[Nakayama]\label{lemma-NAK}
Let $R$ be a ring.
\begin{enumerate}
\item\label{item-nakayama} A first conclusion.
\item A second conclusion.
\end{enumerate}
\end{lemma}
\begin{proof}\label{proof-NAK}
Use the hypotheses.
\end{proof}
\begin{enumerate}
\item\label{item-independent} A navigation fragment.
\end{enumerate}
"""

REGISTRY = """# List of current tags in the stacks project
# tag,full_label

00DV,algebra-lemma-NAK
00DW,algebra-item-nakayama
07RC,algebra-section-nakayama
0000,algebra-section-phantom
0001,algebra-item-independent
0002,algebra-proof-NAK
"""


class StacksTagsCase(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.store = ProjectStore.create(self.root, "Tag navigation tests", "TEST")
        self.source = self.root / "content" / "algebra.tex"
        self.source.write_text(SOURCE, encoding="utf-8")
        self.registry = self.root / "tags"
        self.registry.write_text(REGISTRY, encoding="utf-8")
        self.snapshot = ingest(self.store)["snapshot"]
        self.state = self.store.state()
        self.lemma = next(item for item in self.state["items"].values() if item["label"] == "lemma-NAK")

    def lookup(self, *tags, **kwargs):
        return lookup_tags(self.store, self.registry, tags, **kwargs)

    def test_primary_and_nested_alias_keep_distinct_targets(self):
        result = self.lookup("00DV", "00DW", "0002")
        theorem, clause, proof_anchor = result["results"]
        self.assertEqual(self.snapshot, result["snapshot"])
        self.assertTrue(result["current_snapshot"])
        self.assertEqual("selected_snapshot", result["source_basis"])
        for row in result["results"]:
            self.assertEqual("mapped", row["status"])
            self.assertEqual(self.lemma["id"], row["item_id"])
            self.assertEqual(self.lemma["revision"], row["item_revision"])
            self.assertEqual(self.lemma["source_key"], row["source_key"])
            self.assertEqual(self.lemma["source"], row["source"])
            self.assertEqual(self.snapshot, row["snapshot"])
            self.assertEqual(result["registry"]["sha256"], row["registry_sha256"])
            self.assertEqual("https://stacks.math.columbia.edu/tag/" + row["tag"], row["official_url"])
        self.assertIsNone(theorem["target_clause"])
        self.assertEqual("item", theorem["source_scope"])
        self.assertEqual("item-nakayama", clause["target_clause"])
        self.assertEqual("label_alias", clause["target_scope"])
        self.assertEqual("owning_item", clause["source_scope"])
        self.assertFalse(clause["clause_span_available"])
        self.assertEqual("proof-NAK", proof_anchor["target_clause"])
        self.assertFalse(proof_anchor["clause_span_available"])
        self.assertNotIn("statement", clause)

    def test_navigation_and_fragment_kinds_are_preserved(self):
        rows = self.lookup("07RC", "0000", "0001")["results"]
        self.assertEqual(["section", "document", "fragment"], [row["kind"] for row in rows])
        self.assertEqual(["navigation", "navigation", "item"], [row["target_scope"] for row in rows])
        self.assertTrue(all(row["target_clause"] is None for row in rows))
        self.assertIn("start_char", rows[1]["source"])
        self.assertIn("end_char", rows[2]["source"])

    def test_registry_bytes_and_source_bytes_have_distinct_hashes(self):
        result = self.lookup("00DV")
        self.assertEqual(hashlib.sha256(self.registry.read_bytes()).hexdigest(), result["registry"]["sha256"])
        self.assertEqual(hashlib.sha256(self.source.read_bytes()).hexdigest(), result["results"][0]["source_sha256"])
        self.assertFalse(result["provenance"]["same_upstream_revision_verified"])
        self.assertFalse(result["provenance"]["mathematical_review_performed"])

    def test_unknown_tags_and_labels_are_explicitly_unmapped(self):
        self.registry.write_text(REGISTRY + "ABCD,algebra-lemma-missing\nABCE,wrong-lemma-NAK\n")
        rows = self.lookup("ZZZZ", "ABCD", "ABCE")["results"]
        self.assertEqual(["unmapped"] * 3, [row["status"] for row in rows])
        self.assertEqual("tag_not_in_registry", rows[0]["reason"])
        self.assertIsNone(rows[0]["full_label"])
        for row in rows[1:]:
            self.assertEqual("label_not_indexed_in_snapshot", row["reason"])
            self.assertNotIn("item_id", row)

    def test_duplicate_basenames_do_not_select_an_arbitrary_owner(self):
        other = self.root / "content" / "appendix" / "algebra.tex"
        other.parent.mkdir()
        other.write_text(SOURCE)
        ingest(self.store)
        row = self.lookup("00DW")["results"][0]
        self.assertEqual("ambiguous", row["status"])
        self.assertEqual("multiple_snapshot_targets", row["reason"])
        self.assertEqual(2, row["candidate_count"])
        self.assertEqual(2, len({candidate["item_id"] for candidate in row["candidates"]}))
        self.assertEqual({"content/algebra.tex", "content/appendix/algebra.tex"},
                         {candidate["source"]["path"] for candidate in row["candidates"]})
        self.assertTrue(all(candidate["target_clause"] == "item-nakayama" for candidate in row["candidates"]))
        self.assertNotIn("item_id", row)

    def test_hyphenated_filename_and_label_collision_is_ambiguous(self):
        (self.root / "content" / "chapter-one.tex").write_text(r"\begin{lemma}\label{lemma-x}X.\end{lemma}")
        (self.root / "content" / "chapter.tex").write_text(r"\begin{lemma}\label{one-lemma-x}Y.\end{lemma}")
        ingest(self.store)
        self.registry.write_text("ABCD,chapter-one-lemma-x\n")
        row = self.lookup("ABCD")["results"][0]
        self.assertEqual("ambiguous", row["status"])
        self.assertEqual({"lemma-x", "one-lemma-x"}, {c["matched_label"] for c in row["candidates"]})

    def test_cross_file_proof_alias_does_not_acquire_an_invented_filename(self):
        self.source.write_text(r"\begin{lemma}\label{lemma-NAK}A claim.\end{lemma}")
        other = self.root / "content" / "other.tex"
        other.write_text(r"\begin{proof}[Proof of \ref{lemma-NAK}]\label{proof-separate}An argument.\end{proof}")
        ingest(self.store)
        self.registry.write_text("00DV,algebra-lemma-NAK\nABCD,algebra-proof-separate\nABCE,other-proof-separate\n")
        theorem, invented, actual = self.lookup("00DV", "ABCD", "ABCE")["results"]
        self.assertEqual("mapped", theorem["status"])
        for row in (invented, actual):
            self.assertEqual("unmapped", row["status"])
            self.assertEqual("alias_source_not_recorded", row["reason"])
            self.assertEqual(["content/algebra.tex", "content/other.tex"], row["diagnostic_sources"])
            self.assertNotIn("item_id", row)

    def test_duplicate_nested_labels_in_incomplete_import_do_not_appear_unique(self):
        self.source.write_text(SOURCE.replace("\\item A second conclusion.",
                                              "\\item\\label{item-nakayama} A second conclusion."))
        ingest(self.store, allow_incomplete=True)
        for row in self.lookup("00DV", "00DW")["results"]:
            self.assertEqual("unmapped", row["status"])
            self.assertEqual("source_has_parse_errors", row["reason"])
            self.assertEqual(["content/algebra.tex"], row["diagnostic_sources"])
            self.assertNotIn("item_id", row)

    def test_orphan_proof_is_exposed_without_suppressing_unambiguous_labels(self):
        self.source.write_text(SOURCE.replace("\\section", "\\begin{proof}An unattached argument.\\end{proof}\n\\section", 1))
        ingest(self.store, allow_incomplete=True)
        rows = self.lookup("00DV", "00DW")["results"]
        for row in rows:
            self.assertEqual("mapped", row["status"])
            self.assertEqual([{"code": "orphan_proof", "severity": "error", "path": "content/algebra.tex", "line": 3}],
                             row["source_diagnostics"])
            self.assertEqual(0, row["source_diagnostics_omitted"])
        self.assertEqual("item-nakayama", rows[1]["target_clause"])
        report = audit_tags(self.store, self.registry)
        self.assertEqual(6, report["mapped_with_source_diagnostics"])
        self.assertEqual({"orphan_proof": 6}, report["mapped_by_source_diagnostic_code"])

    def test_historical_lookup_does_not_use_current_item_or_old_source_key_aliases(self):
        before = self.lookup("00DV")["results"][0]
        moved = self.root / "content" / "renamed.tex"
        self.source.rename(moved)
        moved.write_text(SOURCE.replace("Let $R$ be a ring.", "Let $R$ be a commutative ring."))
        # Preserve the ID explicitly across a move and a changed statement.
        moved.write_text(moved.read_text().replace(r"\label{lemma-NAK}",
                         "% mpm:id=" + self.lemma["id"] + "\n" + r"\label{lemma-NAK}"))
        current = ingest(self.store)["snapshot"]
        self.assertNotEqual(self.snapshot, current)
        self.assertEqual("unmapped", self.lookup("00DV")["results"][0]["status"])
        historical = self.lookup("00DV", snapshot=self.snapshot)
        self.assertFalse(historical["current_snapshot"])
        self.assertEqual(before, historical["results"][0])
        self.registry.write_text(REGISTRY.replace("algebra-", "renamed-"))
        after = self.lookup("00DV")["results"][0]
        self.assertEqual(before["item_id"], after["item_id"])
        self.assertNotEqual(before["item_revision"], after["item_revision"])
        self.assertNotEqual(before["registry_sha256"], after["registry_sha256"])
        self.assertEqual("content/renamed.tex", after["source"]["path"])

    def test_current_working_source_changes_do_not_change_snapshot_result(self):
        before = self.lookup("00DW")
        self.source.write_text("This file now differs from its imported snapshot.\n")
        self.assertEqual(before, self.lookup("00DW"))

    def test_no_metadata_or_source_writes_even_with_missing_write_lock(self):
        self.store.lock_path.unlink()
        before = {path.relative_to(self.root): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        self.lookup("00DV", "00DW")
        audit_tags(self.store, self.registry)
        after = {path.relative_to(self.root): path.read_bytes() for path in self.root.rglob("*") if path.is_file()}
        self.assertEqual(before, after)
        self.assertFalse(self.store.lock_path.exists())

    def test_corrupt_state_cache_is_not_navigation_evidence(self):
        self.store.state_path.write_text('{"items": {"invented": {}}}')
        self.assertEqual(self.lemma["id"], self.lookup("00DV")["results"][0]["item_id"])

    def test_invalid_requested_tags_are_rejected_without_normalization(self):
        for invalid in ("00dv", "0DV", "000DV", " 00DV", "00DV\n", "００ＤＶ", 1234, None):
            with self.subTest(tag=invalid), self.assertRaisesRegex(ProjectError, "four uppercase ASCII"):
                self.lookup(invalid)

    def test_single_tag_order_duplicates_and_request_bound(self):
        self.assertEqual("00DV", lookup_tags(self.store, self.registry, "00DV")["results"][0]["tag"])
        self.assertEqual(["00DW", "00DV", "00DW"], [r["tag"] for r in self.lookup("00DW", "00DV", "00DW")["results"]])
        for tags in ([], ["00DV"] * 257, None):
            with self.subTest(tags=type(tags).__name__), self.assertRaises(ProjectError):
                lookup_tags(self.store, self.registry, tags)

    def test_malformed_registry_fails_even_when_requested_row_is_valid(self):
        for malformed in ("00dv,algebra-label", "ABCDE,algebra-label", "ABCD", "ABCD,a-b,extra",
                          "ABCD,", "ABCD,unprefixed", 'ABCD,"unclosed', "ABCD,a label-x", "ABCD,a-\\label{x}"):
            with self.subTest(line=malformed):
                self.registry.write_text(REGISTRY + malformed + "\n")
                with self.assertRaises(ProjectError):
                    self.lookup("00DV")
        self.registry.write_bytes(b"\xff")
        with self.assertRaisesRegex(ProjectError, "UTF-8"):
            self.lookup("00DV")
        self.registry.write_text("# only a comment\n\n")
        with self.assertRaisesRegex(ProjectError, "no tag records"):
            self.lookup("00DV")

    def test_conflicts_fail_and_identical_records_are_counted(self):
        for conflict in ("00DV,algebra-different", "ABCD,algebra-lemma-NAK"):
            with self.subTest(line=conflict):
                self.registry.write_text(REGISTRY + conflict + "\n")
                with self.assertRaisesRegex(ProjectError, "Conflicting"):
                    self.lookup("00DV")
        self.registry.write_text(REGISTRY + "00DV,algebra-lemma-NAK\n")
        metadata = self.lookup("00DV")["registry"]
        self.assertEqual(6, metadata["tag_count"])
        self.assertEqual(7, metadata["record_count"])
        self.assertEqual(1, metadata["duplicate_record_count"])

    def test_registry_comments_csv_quotes_bom_and_plus_are_supported(self):
        self.registry.write_text('\ufeff  # comment\n\n"00DV","algebra-lemma-NAK"\n0H2V,curves-lemma-degree-at-least-2g+1\n')
        result = self.lookup("00DV", "0H2V")
        self.assertEqual("mapped", result["results"][0]["status"])
        self.assertEqual("curves-lemma-degree-at-least-2g+1", result["results"][1]["full_label"])
        self.assertEqual(hashlib.sha256(self.registry.read_bytes()).hexdigest(), result["registry"]["sha256"])

    def test_registry_path_and_resource_limits(self):
        with self.assertRaisesRegex(ProjectError, "absolute local file"):
            lookup_tags(self.store, Path("tags"), "00DV")
        with self.assertRaises(ProjectError):
            lookup_tags(self.store, self.root, "00DV")
        with patch("mathproj.stacks_tags.MAX_REGISTRY_BYTES", 8):
            with self.assertRaisesRegex(ProjectError, "byte limit"):
                self.lookup("00DV")
        with patch("mathproj.stacks_tags.MAX_REGISTRY_RECORDS", 2):
            with self.assertRaisesRegex(ProjectError, "record limit"):
                self.lookup("00DV")

    def test_unknown_invalid_and_corrupt_snapshots_fail_closed(self):
        for snapshot in ("f" * 64, "short", [], 1):
            with self.subTest(snapshot=snapshot), self.assertRaises(ProjectError):
                self.lookup("00DV", snapshot=snapshot)
        self.assertTrue(self.lookup("00DV", snapshot="current")["current_snapshot"])
        archive = self.store.meta / "snapshots" / (self.snapshot + ".json")
        archive.write_text(archive.read_text().replace("Nakayama", "Modified"))
        with self.assertRaisesRegex(ProjectError, "Snapshot integrity"):
            self.lookup("00DV")

    def test_audit_counts_all_rows_but_bounds_diagnostic_output(self):
        self.registry.write_text(REGISTRY + "ABCD,algebra-unindexed\nABCE,absent-lemma\n")
        report = audit_tags(self.store, self.registry, diagnostic_limit=1)
        self.assertEqual(8, report["total_tags"])
        self.assertEqual({"mapped": 6, "unmapped": 2, "ambiguous": 0}, report["counts"])
        self.assertEqual({"document": 1, "fragment": 1, "lemma": 3, "section": 1}, report["mapped_by_kind"])
        self.assertEqual({"item": 2, "label_alias": 2, "navigation": 2}, report["mapped_by_target_scope"])
        self.assertEqual({"label_not_indexed_in_snapshot": 2}, report["unresolved_by_reason"])
        self.assertEqual(1, len(report["diagnostics"]))
        self.assertEqual(1, report["diagnostics_omitted"])
        self.assertEqual([], audit_tags(self.store, self.registry, diagnostic_limit=0)["diagnostics"])
        for limit in (-1, 1001, True, "10"):
            with self.subTest(limit=limit), self.assertRaises(ProjectError):
                audit_tags(self.store, self.registry, diagnostic_limit=limit)


if __name__ == "__main__":
    unittest.main()
