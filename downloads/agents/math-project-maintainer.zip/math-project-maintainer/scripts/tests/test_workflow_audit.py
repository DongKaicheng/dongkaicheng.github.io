"""Independent regressions for issue provenance and accepting-review freshness.

These tests inspect the semantics of recorded judgments. They do not claim
that the metadata checks can determine whether a mathematical objection is true.
"""

from __future__ import annotations

from copy import deepcopy
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj.project import ingest, resolve_item
from mathproj.store import ProjectError, ProjectStore
from mathproj.workflow import prepare_review, record_review, resolve_issue, support_report


SOURCE = r"""\section{Integer addition}
\begin{lemma}\label{lem-identity}
For every integer $n$, $n+0=n$.
\end{lemma}
\begin{proof}
Apply the identity axiom.
\end{proof}
\begin{proof}[Alternative proof]
The element $0$ is the additive identity in the abelian group of integers.
Consequently adding it on the right fixes every integer $n$.
\end{proof}
\begin{definition}\label{def-even}
An integer is even if it is twice an integer.
\end{definition}
"""


class WorkflowAuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, "Workflow audit", "AUDIT")
        (self.root / "content/a.tex").write_text(SOURCE)
        ingest(self.store)
        state = self.store.state()
        self.item = resolve_item(state, "lem-identity")
        self.definition = resolve_item(state, "def-even")
        self.first, self.second = state["items"][self.item]["proof_ids"]

    def report(self, proof=None, *, reference=None, accept=True, scope="proof"):
        reference = reference or self.item
        if reference == self.item and proof is None:
            proof = self.first
        result = prepare_review(self.store, reference, proof)["template"]
        result["reviewer"] = {"id": "audit-reviewer", "kind": "agent",
                              "independent": True, "author_of_change": False}
        result["summary"] = "The input uses the usual integer addition and its identity axiom."
        result["verdict"] = "accept" if accept else "changes_required"
        reasons = {
            "hypotheses": "The quantified variable is an integer and zero is an integer.",
            "inference": "The additive identity law directly gives the displayed equality.",
            "scope": "The statement and proof use the same integer operation.",
            "constructions": "No quotient, extension, or limiting construction occurs.",
            "citations": "The proof invokes the stated elementary identity axiom directly."
        }
        for check in result["checks"]:
            check.update(status="pass", reason=reasons[check["name"]])
        if not accept:
            result["summary"] = "A recorded reviewer objection requires an explicit response."
            result["checks"][1].update(status="issue", reason="The reviewer asks for the ambient operation to be identified.")
            result["findings"] = [{
                "scope": scope, "severity": "error", "title": "Identify the ambient operation",
                "reason": "The reviewer asks whether the operation is the usual integer addition.",
                "required_action": "State the intended operation and reconsider this objection."
            }]
        return result

    def accept(self, proof=None):
        return record_review(self.store, self.report(proof))

    def object_to(self, proof=None, scope="proof"):
        return record_review(self.store, self.report(proof, accept=False, scope=scope))

    def resolve(self, issue_id):
        return resolve_issue(self.store, issue_id,
                             reason="The symbols explicitly denote the usual integers and their usual addition.",
                             reviewer="audit-reviewer", disposition="invalid")

    def test_finding_cannot_override_authoritative_issue_fields(self):
        reserved = {
            "id": "invented-issue", "item_id": self.definition,
            "proof_id": self.second, "review_id": "invented-review", "binding": {},
            "status": "resolved", "created_at": "1900-01-01", "resolutions": []
        }
        for field, value in reserved.items():
            with self.subTest(field=field):
                report = self.report(accept=False)
                report["findings"][0][field] = value
                before = self.store.events.read_bytes()
                with self.assertRaises(ProjectError):
                    record_review(self.store, report)
                self.assertEqual(self.store.events.read_bytes(), before)

    def test_statement_issue_blocks_every_alternative(self):
        self.accept(self.first)
        self.accept(self.second)
        saved = self.object_to(self.first, scope="statement")
        issue = self.store.state()["issues"][saved["issues"][0]]
        self.assertEqual(issue["item_id"], self.item)
        self.assertIsNone(issue["proof_id"])
        result = support_report(self.store)
        self.assertNotIn(self.item, result["grounded"])
        for proof in (self.first, self.second):
            self.assertFalse(result["eligibility"][proof]["eligible"])
            with self.assertRaisesRegex(ProjectError, "open issues"):
                self.accept(proof)

    def test_proof_issue_preserves_an_accepted_independent_alternative(self):
        self.accept(self.first)
        self.accept(self.second)
        saved = self.object_to(self.first, scope="proof")
        issue = self.store.state()["issues"][saved["issues"][0]]
        self.assertEqual(issue["proof_id"], self.first)
        result = support_report(self.store)
        self.assertIn(self.item, result["grounded"])
        self.assertEqual(result["selected_proofs"][self.item], self.second)
        self.assertFalse(result["eligibility"][self.first]["eligible"])
        self.assertTrue(result["eligibility"][self.second]["eligible"])

    def test_resolving_statement_objection_does_not_restore_old_acceptance(self):
        self.accept(self.second)
        saved = self.object_to(self.first, scope="statement")
        self.resolve(saved["issues"][0])
        self.assertNotIn(self.item, support_report(self.store)["grounded"])
        self.accept(self.second)
        self.assertIn(self.item, support_report(self.store)["grounded"])

    def test_proof_local_resolution_does_not_stale_other_alternative(self):
        self.accept(self.second)
        saved = self.object_to(self.first, scope="proof")
        self.resolve(saved["issues"][0])
        result = support_report(self.store)
        self.assertIn(self.item, result["grounded"])
        self.assertEqual(result["selected_proofs"][self.item], self.second)

    def test_finding_requires_a_valid_explicit_scope(self):
        for scope in (None, "everything", 5):
            with self.subTest(scope=scope):
                report = self.report(accept=False)
                if scope is None:
                    report["findings"][0].pop("scope")
                else:
                    report["findings"][0]["scope"] = scope
                with self.assertRaises(ProjectError):
                    record_review(self.store, report)

    def test_proof_scope_requires_an_actual_proof_subject(self):
        report = self.report(reference=self.definition, accept=False, scope="proof")
        self.assertIsNone(report["binding"]["proof_id"])
        with self.assertRaises(ProjectError):
            record_review(self.store, report)
        report["findings"][0]["scope"] = "statement"
        saved = record_review(self.store, report)
        self.assertIsNone(self.store.state()["issues"][saved["issues"][0]]["proof_id"])

    def test_acceptance_with_nonblocking_findings_remains_current(self):
        for severity in ("warning", "note"):
            with self.subTest(severity=severity):
                report = self.report(self.second)
                report["findings"] = [{
                    "scope": "proof", "severity": severity,
                    "title": "Optional explanatory pointer",
                    "reason": "The elementary proof is complete; an explicit pointer to the group axiom could aid readers.",
                    "required_action": "Optionally add the pointer during an editorial pass."
                }]
                saved = record_review(self.store, report)
                self.assertEqual(len(saved["issues"]), 1)
                support = support_report(self.store)
                self.assertIn(self.item, support["grounded"])
                self.assertTrue(support["eligibility"][self.second]["eligible"])

    def test_review_prepared_before_issue_resolution_is_stale(self):
        prepared = deepcopy(self.report(self.first))
        saved = self.object_to(self.first, scope="proof")
        self.resolve(saved["issues"][0])
        with self.assertRaisesRegex(ProjectError, "stale|issue|objection"):
            record_review(self.store, prepared)

    def test_backwards_clock_cannot_reactivate_pre_resolution_acceptance(self):
        # Wall clocks can change; causal review eligibility must not depend on
        # a previous acceptance timestamp sorting after a later resolution.
        with patch("mathproj.workflow.utc_now", return_value="2040-01-01T00:00:00.000000+00:00"):
            self.accept(self.first)
        with patch("mathproj.workflow.utc_now", return_value="2040-01-01T00:01:00.000000+00:00"):
            saved = self.object_to(self.first, scope="proof")
        with patch("mathproj.workflow.utc_now", return_value="2039-12-31T23:59:00.000000+00:00"):
            self.resolve(saved["issues"][0])
        self.assertNotIn(self.item, support_report(self.store)["grounded"])


if __name__ == "__main__":
    unittest.main()
