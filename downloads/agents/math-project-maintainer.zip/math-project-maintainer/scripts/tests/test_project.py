"""Integration regressions for identity, context, impact, and source freshness."""

from __future__ import annotations

import json
import hashlib
from pathlib import Path
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj.project import dependency_edges, ingest, item_history, resolve_item, set_context
from mathproj.store import ProjectError, ProjectStore, atomic_json
from mathproj.workflow import freshness, record_applications, require_fresh


def lemma(label, statement="For a real number $x$, one has $x^2\\geq0$.",
          proof="Apply the order axioms to $x$ or to $-x$.", explicit_id=None):
    identity = f"% mpm:id={explicit_id}\n" if explicit_id else ""
    return ("\\begin{lemma}\n" + identity + "\\label{" + label + "}\n" + statement +
            "\n\\end{lemma}\n\\begin{proof}\n" + proof + "\n\\end{proof}\n")


class ProjectTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, "Import test", "TEST")

    def write(self, path, text):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text, encoding="utf-8")
        return target

    def item(self, label):
        state = self.store.state()
        return state["items"][resolve_item(state, label)]

    def test_identical_import_is_idempotent_and_does_not_allocate_ids(self):
        self.write("content/a.tex", lemma("lem-square"))
        first = ingest(self.store)
        before = self.store.state()
        events = self.store.events.read_bytes()
        second = ingest(self.store)
        self.assertEqual(second["snapshot"], first["snapshot"])
        self.assertEqual(second["added"], [])
        self.assertEqual(second["changed"], [])
        self.assertEqual(self.store.state(), before)
        self.assertEqual(self.store.events.read_bytes(), events)

    def test_statement_revision_preserves_identity_and_historical_source(self):
        original = lemma("lem-square")
        path = self.write("content/a.tex", original)
        initial = ingest(self.store)
        before = self.item("lem-square")
        path.write_text(lemma("lem-square", "For real $x$, one has $x^2+1\\geq1$."))
        changed = ingest(self.store)
        after = self.item("lem-square")
        self.assertEqual(after["id"], before["id"])
        self.assertNotEqual(after["declaration_revision"], before["declaration_revision"])
        self.assertIn(after["id"], changed["changed"])
        history = item_history(self.store, after["id"])
        self.assertEqual(history[0]["snapshot"], initial["snapshot"])
        self.assertEqual(history[0]["item"]["statement"], before["statement"])
        self.assertEqual(history[-1]["item"]["statement"], after["statement"])
        self.assertEqual(self.store.snapshot(initial["snapshot"])["files"][0]["text"], original)

    def test_import_archives_exact_bom_crlf_source_bytes(self):
        raw = ("\ufeff" + lemma("lem-square").replace("\n", "\r\n")).encode("utf-8")
        path = self.root / "content" / "main.tex"
        path.write_bytes(raw)
        report = ingest(self.store)
        archived = self.store.snapshot(report["snapshot"])["files"][0]
        self.assertEqual(archived["text"].encode("utf-8"), raw)
        self.assertEqual(archived["sha256"], hashlib.sha256(raw).hexdigest())
        self.assertTrue(freshness(self.store)["fresh"])

    def test_relocation_preserves_unique_identity_and_old_source_alias(self):
        path = self.write("content/old.tex", lemma("lem-square"))
        ingest(self.store)
        before = self.item("lem-square")
        path.rename(self.root / "content/new.tex")
        report = ingest(self.store)
        after = self.item("lem-square")
        self.assertEqual(after["id"], before["id"])
        self.assertEqual(after["revision"], before["revision"])
        self.assertEqual(report["moved"], [after["id"]])
        self.assertEqual(report["added"], [])
        self.assertEqual(report["missing"], [])
        self.assertEqual(resolve_item(self.store.state(), before["source_key"]), after["id"])

    def test_move_outside_context_scope_changes_effective_declaration(self):
        path = self.write("content/local/a.tex", lemma("lem-square"))
        set_context(self.store, "ordered", "All scalars in this section are real.",
                    paths=["content/local/*"])
        ingest(self.store)
        before = self.item("lem-square")
        path.rename(self.root / "content/a.tex")
        report = ingest(self.store)
        after = self.item("lem-square")
        self.assertEqual(after["id"], before["id"])
        self.assertEqual(after["statement_hash"], before["statement_hash"])
        self.assertNotEqual(after["context_hash"], before["context_hash"])
        self.assertNotEqual(after["declaration_revision"], before["declaration_revision"])
        self.assertIn(after["id"], report["moved"])
        self.assertIn(after["id"], report["changed"])

    def test_explicit_identity_permits_relocation_and_statement_edit(self):
        old = self.write("content/a.tex", lemma("lem-square"))
        ingest(self.store)
        iid = self.item("lem-square")["id"]
        old.unlink()
        self.write("content/b.tex", lemma("lem-shift", "For real $x$, $x^2+2\\geq2$.", explicit_id=iid))
        report = ingest(self.store)
        self.assertEqual(self.item("lem-shift")["id"], iid)
        self.assertEqual(report["added"], [])
        self.assertEqual(report["moved"], [iid])
        self.assertEqual(report["changed"], [iid])

    def test_two_objects_cannot_claim_the_same_registered_id(self):
        self.write("content/a.tex", lemma("lem-square"))
        ingest(self.store)
        iid = self.item("lem-square")["id"]
        self.write("content/b.tex", lemma("lem-other", explicit_id=iid))
        before_state = self.store.state()
        before_events = self.store.events.read_bytes()
        with self.assertRaisesRegex(ProjectError, "Two current source objects claim ID"):
            ingest(self.store)
        self.assertEqual(self.store.state(), before_state)
        self.assertEqual(self.store.events.read_bytes(), before_events)

    def test_explicit_id_cannot_allocate_an_unregistered_identity(self):
        self.write("content/a.tex", lemma("lem-square", explicit_id="TEST-999999"))
        before = self.store.state()
        with self.assertRaisesRegex(ProjectError, "not registered"):
            ingest(self.store)
        self.assertEqual(self.store.state(), before)

    def test_ambiguous_same_text_relocation_does_not_guess_identity(self):
        self.write("content/a.tex", lemma("lem-square"))
        self.write("content/b.tex", lemma("lem-square"))
        ingest(self.store)
        previous = set(self.store.state()["items"])
        (self.root / "content/a.tex").unlink()
        (self.root / "content/b.tex").unlink()
        self.write("content/c.tex", lemma("lem-square"))
        report = ingest(self.store)
        iid = self.item("lem-square")["id"]
        self.assertNotIn(iid, previous)
        self.assertEqual(report["added"], [iid])
        self.assertEqual(set(report["missing"]), previous)

    def test_missing_identity_is_retained_and_not_recycled_for_new_label(self):
        path = self.write("content/a.tex", lemma("lem-square"))
        ingest(self.store)
        iid = self.item("lem-square")["id"]
        path.write_text("\\section{An empty section}\n")
        ingest(self.store)
        self.assertEqual(self.store.state()["items"][iid]["lifecycle"], "missing")
        self.write("content/b.tex", lemma("lem-unrelated", "The integer $0$ is even.", "One has $0=2\\cdot0$."))
        report = ingest(self.store)
        replacement = self.item("lem-unrelated")["id"]
        self.assertNotEqual(replacement, iid)
        self.assertGreater(int(replacement.split("-")[-1]), int(iid.split("-")[-1]))
        self.assertEqual(self.store.state()["items"][iid]["lifecycle"], "missing")
        self.assertEqual(report["added"], [replacement])

    def test_context_update_invalidates_only_matching_objects(self):
        self.write("content/a.tex", lemma("lem-a") + lemma("lem-b"))
        set_context(self.store, "scalar-field", "The scalar field is Q.", labels=["lem-a"])
        ingest(self.store)
        a, b = self.item("lem-a"), self.item("lem-b")
        set_context(self.store, "scalar-field", "The scalar field is R.", labels=["lem-a"])
        pending = freshness(self.store)
        self.assertFalse(pending["fresh"])
        self.assertIn("contexts_changed", {r["kind"] for r in pending["reasons"]})
        report = ingest(self.store)
        self.assertEqual(self.item("lem-a")["statement_hash"], a["statement_hash"])
        self.assertNotEqual(self.item("lem-a")["declaration_revision"], a["declaration_revision"])
        self.assertEqual(self.item("lem-b")["revision"], b["revision"])
        self.assertEqual(report["changed"], [a["id"]])
        self.assertTrue(freshness(self.store)["fresh"])

    def test_removed_dependency_rechecks_transitive_consumers(self):
        self.write("content/a.tex", lemma("lem-a"))
        self.write("content/b.tex", lemma("lem-b", proof="Use Lemma~\\ref{lem-a}."))
        self.write("content/c.tex", lemma("lem-c", proof="Use Lemma~\\ref{lem-b}."))
        ingest(self.store)
        a, b, c = (self.item(label)["id"] for label in ("lem-a", "lem-b", "lem-c"))
        (self.root / "content/a.tex").unlink()
        report = ingest(self.store)
        self.assertEqual(report["missing"], [a])
        self.assertEqual(set(report["impact"]["affected"]), {a, b, c})
        queued = {iid for task in self.store.state()["tasks"].values() for iid in task["target_ids"]}
        self.assertTrue({a, b, c}.issubset(queued))
        self.assertIsNone(self.store.state()["proofs"][b + ":proof:1"]["references"][0]["target_id"])

    def test_recorded_manual_use_is_present_in_impact_graph(self):
        path = self.write("content/a.tex", lemma("lem-a"))
        self.write("content/b.tex", lemma("lem-b", "For real $x$, $x^2+1\\geq1$.",
                                          "Add $1$ to the nonnegativity inequality for $x^2$."))
        ingest(self.store)
        a, b = self.item("lem-a"), self.item("lem-b")
        proof_id = b["proof_ids"][0]
        proof = self.store.state()["proofs"][proof_id]
        record_applications(self.store, [{
            "proof_id": proof_id, "proof_revision": proof["revision"],
            "target_id": a["id"], "target_revision": a["declaration_revision"],
            "manual": True, "relation": "uses", "substitution": "Use the same real number x.",
            "hypotheses": [{"required": "x is real", "discharge": "The statement assumes x is real."}],
            "conclusion": "x^2 is nonnegative.",
            "justification": "The prose uses this inequality without a TeX cross-reference.",
            "reviewer": "integration-test-reviewer"
        }])
        edges = dependency_edges(self.store.state())
        self.assertTrue(any(e["consumer"] == b["id"] and e["dependency"] == a["id"] for e in edges),
                        "A recorded manual theorem use must participate in revision-impact analysis.")
        path.write_text(lemma("lem-a", "For real $x$, $x^2+2\\geq2$."))
        report = ingest(self.store)
        self.assertIn(b["id"], report["impact"]["affected"])

    def test_source_freshness_detects_addition_deletion_and_unimported_edits(self):
        path = self.write("content/a.tex", lemma("lem-square"))
        ingest(self.store)
        self.assertTrue(freshness(self.store)["fresh"])
        self.write("content/new.tex", lemma("lem-new"))
        report = freshness(self.store)
        self.assertIn({"kind": "source_added", "path": "content/new.tex"}, report["reasons"])
        with self.assertRaisesRegex(ProjectError, "Import current sources"):
            require_fresh(self.store, self.store.state())
        ingest(self.store)
        path.write_text(lemma("lem-square", "The number $1$ is positive."))
        self.assertIn({"kind": "source_changed", "path": "content/a.tex"}, freshness(self.store)["reasons"])
        path.unlink()
        self.assertIn({"kind": "source_missing", "path": "content/a.tex"}, freshness(self.store)["reasons"])

    def test_freshness_rediscovers_literal_include_graph(self):
        self.write("main.tex", "\\input{content/a}\n")
        self.write("content/a.tex", lemma("lem-a"))
        self.write("content/b.tex", lemma("lem-b"))
        manifest = self.store.manifest()
        manifest["entrypoints"] = ["main.tex"]
        atomic_json(self.store.manifest_path, manifest)
        ingest(self.store)
        self.assertEqual(len(self.store.state()["items"]), 1)
        self.write("main.tex", "\\input{content/a}\n\\input{content/b}\n")
        result = freshness(self.store)
        reasons = {(r["kind"], r.get("path")) for r in result["reasons"]}
        self.assertIn(("source_changed", "main.tex"), reasons)
        self.assertIn(("source_added", "content/b.tex"), reasons)

    def test_manifest_policy_change_requires_a_new_snapshot(self):
        self.write("content/a.tex", lemma("lem-square"))
        ingest(self.store)
        manifest = self.store.manifest()
        manifest["policy"]["require_independent_review"] = False
        atomic_json(self.store.manifest_path, manifest)
        result = freshness(self.store)
        self.assertFalse(result["fresh"])
        self.assertIn({"kind": "manifest_changed"}, result["reasons"])
        with self.assertRaisesRegex(ProjectError, "Import current sources"):
            require_fresh(self.store, self.store.state())

    def test_structurally_failed_import_preserves_the_last_snapshot(self):
        path = self.write("content/a.tex", lemma("lem-square"))
        ingest(self.store)
        before = self.store.state()
        before_events = self.store.events.read_bytes()
        path.write_text("\\begin{lemma}\\label{broken} Unclosed result.\n")
        with self.assertRaisesRegex(ProjectError, "structural errors"):
            ingest(self.store)
        self.assertEqual(self.store.state(), before)
        self.assertEqual(self.store.events.read_bytes(), before_events)
        self.assertFalse(freshness(self.store)["fresh"])


if __name__ == "__main__":
    unittest.main()
