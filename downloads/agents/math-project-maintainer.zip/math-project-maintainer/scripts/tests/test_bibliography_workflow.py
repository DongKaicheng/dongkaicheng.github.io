"""Literal citations must have exact, scoped, current evidence.

All bibliographic sources below are synthetic supplied data. The tests do not
fetch an external paper or use review-record validation as a proof certificate.
"""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj import latex
from mathproj.project import ingest, resolve_item
from mathproj.publish import create_release, export_project
from mathproj.sources import (audit_sources, citation_binding, cite_source,
                             register_source, retire_citation, _revision)
from mathproj.store import ProjectError, ProjectStore
from mathproj.workflow import prepare_review, record_review, support_report


SOURCE = r"""A preliminary survey citation is \cite{Survey}.
\section{Real order}\label{sec-order}
Historical comparison: \cite[Section 1]{History}.
\begin{lemma}\label{square}
For every real $x$, one has $x^2\geq0$.
\end{lemma}
\begin{proof}
Apply the square inequality in \cite[Lemma 1]{Order} to the real number $x$.
\end{proof}
\begin{proof}[Alternative proof]
For nonnegative $x$ multiply nonnegative numbers; otherwise use $(-x)^2=x^2$.
\end{proof}
"""
INSPECTED = "Lemma 1. Every real number x satisfies x^2 >= 0.\n"


class BibliographyWorkflowTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, "Literal bibliography fixture", "BIB")
        self.path = self.root / "content/main.tex"
        self.path.write_text(SOURCE)
        self.import_source()

    def import_source(self, text=None):
        if text is not None:
            self.path.write_text(text)
        imported = ingest(self.store)
        state = self.store.state()
        self.iid = resolve_item(state, "square")
        self.first, self.second = state["items"][self.iid]["proof_ids"]
        return imported

    def slots(self, proof_id="first"):
        state = self.store.state()
        if proof_id == "first":
            proof_id = self.first
        subject = state["proofs"][proof_id] if proof_id else state["items"][self.iid]
        return subject.get("bibliographic_references", [])

    def register(self, key="source-order", *, previous=None, version="fixture-v1", status="checked"):
        row = {"title": "Supplied real-order fixture", "uri": "urn:sha256:" + hashlib.sha256(INSPECTED.encode()).hexdigest(),
               "version": version, "status": status, "checked_by": "fixture-inspector",
               "accessed_at": "2026-11-16", "notes": "Synthetic supplied evidence; no external fetch is claimed."}
        if previous is not None:
            row["previous_revision"] = previous
        return register_source(self.store, key, row)["source"]

    def citation(self, *, proof_id="first", reference_ids="current", source_key="source-order", **changes):
        state = self.store.state()
        if proof_id == "first":
            proof_id = self.first
        row = {"citation_key": "square-use", "source_revision": state["source_records"][source_key]["revision"],
               "declaration_revision": state["items"][self.iid]["declaration_revision"],
               "proof_id": proof_id, "proof_revision": state["proofs"][proof_id]["revision"] if proof_id else None,
               "status": "checked", "locator": {"theorem": "Lemma 1", "page": "1"},
               "supporting_statement": INSPECTED.strip(), "assumptions": [
                   {"required": "x is real", "discharge": "The local statement assumes precisely that domain."}],
               "substitution": "Use the same real x.", "conclusion": "The square x^2 is nonnegative.",
               "justification": "The supplied source and the local use have identical data and conclusion.",
               "inspected_text": INSPECTED, "checked_by": "fixture-inspector", "accessed_at": "2026-11-16"}
        if reference_ids == "current":
            reference_ids = [entry["reference_id"] for entry in self.slots(proof_id)]
        if reference_ids is not None:
            row["reference_ids"] = reference_ids
        row.update(changes)
        return row

    def cite(self, **kwargs):
        source_key = kwargs.get("source_key", "source-order")
        return cite_source(self.store, self.iid, source_key, self.citation(**kwargs))["citation"]

    def accepting(self, proof_id=None):
        row = prepare_review(self.store, self.iid, proof_id or self.first)["template"]
        row.update(reviewer={"id": "independent-fixture-reviewer", "kind": "agent",
                             "independent": True, "author_of_change": False}, verdict="accept",
                   summary="The real order argument proves the specified square inequality.")
        for check in row["checks"]:
            check.update(status="pass", reason="Checked the literal fixture assumptions, argument, and supplied evidence at this exact version.")
        return row

    def missing(self, proof_id=None):
        return [row for row in citation_binding(self.store.state(), self.iid, proof_id or self.first)["obstacles"]
                if row["kind"] == "bibliography_evidence_missing"]

    def test_uncovered_literal_citation_blocks_acceptance_without_any_registered_source(self):
        packet = prepare_review(self.store, self.iid, self.first)
        slots = packet["bibliographic_references"]
        self.assertEqual(len(slots), 1)
        self.assertEqual(slots[0]["key"], "Order")
        self.assertEqual(slots[0]["notes"], ["Lemma 1"])
        self.assertEqual(slots[0]["status"], "uncovered")
        self.assertEqual(self.missing()[0]["reference_id"], slots[0]["reference_id"])
        with self.assertRaisesRegex(ProjectError, "evidence|obstacles|applications"):
            record_review(self.store, self.accepting())

    def test_matching_source_key_or_legacy_citation_does_not_cover_a_slot_implicitly(self):
        self.register(key="Order")
        self.assertTrue(self.missing())
        saved = self.cite(source_key="Order", reference_ids=None)
        self.assertNotIn("reference_ids", saved)
        self.assertTrue(self.missing())
        self.assertEqual(citation_binding(self.store.state(), self.iid, self.first)["citations"], {saved["id"]: saved["revision"]})

    def test_explicit_checked_coverage_allows_current_review_with_arbitrary_source_key(self):
        self.register()
        saved = self.cite()
        slot = self.slots()[0]
        self.assertEqual(saved["reference_ids"], [slot["reference_id"]])
        self.assertEqual(set(saved["reference_bindings"]), {slot["reference_id"]})
        self.assertEqual(self.missing(), [])
        packet = prepare_review(self.store, self.iid, self.first)
        self.assertEqual(packet["bibliographic_references"][0]["covered_by"], [saved["id"]])
        record_review(self.store, self.accepting())
        self.assertIn(self.iid, support_report(self.store)["grounded"])

    def test_reference_ids_require_exact_subject_and_cannot_cross_to_an_alternative(self):
        self.register()
        first_slot = self.slots()[0]["reference_id"]
        before = self.store.events.read_bytes()
        for proof_id in (None, self.second):
            with self.subTest(proof=proof_id):
                with self.assertRaisesRegex(ProjectError, "exactly this statement or proof"):
                    self.cite(proof_id=proof_id, reference_ids=[first_slot])
        with self.assertRaisesRegex(ProjectError, "exactly this statement or proof"):
            self.cite(reference_ids=["f" * 24])
        self.assertEqual(self.store.events.read_bytes(), before)

    def test_repeated_same_key_with_different_locators_is_not_auto_coalesced(self):
        self.import_source(SOURCE.replace("to the real number $x$.", "to $x$, and compare \\cite[Corollary 2]{Order}."))
        self.register()
        first, second = self.slots()
        self.assertNotEqual(first["reference_id"], second["reference_id"])
        self.cite(reference_ids=[first["reference_id"]])
        missing = self.missing()
        self.assertEqual([row["reference_id"] for row in missing], [second["reference_id"]])
        self.assertEqual(missing[0]["notes"], ["Corollary 2"])
        self.cite(citation_key="second-explicit-use", reference_ids=[second["reference_id"]],
                  locator={"theorem": "Corollary 2"})
        self.assertEqual(self.missing(), [])

    def test_one_explicit_record_can_cover_multiple_checked_occurrences(self):
        self.import_source(SOURCE.replace("to the real number $x$.", "to $x$, and compare \\cite[Lemma 1]{Order}."))
        self.register()
        saved = self.cite()
        self.assertEqual(len(saved["reference_ids"]), 2)
        self.assertEqual(self.missing(), [])

    def test_candidate_evidence_stays_uncovered_despite_exact_slot_ids(self):
        self.register()
        saved = self.cite(status="candidate")
        obstacles = citation_binding(self.store.state(), self.iid, self.first)["obstacles"]
        self.assertIn("citation_unchecked", {row["kind"] for row in obstacles})
        self.assertEqual(len(self.missing()), 1)
        self.assertEqual(prepare_review(self.store, self.iid, self.first)["bibliographic_references"][0]["covered_by"], [])
        self.assertTrue(saved["reference_ids"])

    def test_source_revision_change_invalidates_coverage_until_evidence_is_rebound(self):
        source = self.register()
        citation = self.cite()
        self.register(previous=source["revision"], version="fixture-v2")
        kinds = {row["kind"] for row in citation_binding(self.store.state(), self.iid, self.first)["obstacles"]}
        self.assertTrue({"citation_source_stale", "bibliography_evidence_missing"}.issubset(kinds))
        self.cite(previous_revision=citation["revision"])
        self.assertEqual(self.missing(), [])

    def test_retiring_evidence_leaves_the_still_written_citation_uncovered(self):
        self.register()
        citation = self.cite()
        old_review = self.accepting()
        record_review(self.store, old_review)
        retire_citation(self.store, citation["id"], expected_revision=citation["revision"],
                        reason="The source use is withdrawn pending reinspection.", reviewer="fixture-inspector")
        self.assertTrue(self.missing())
        self.assertNotIn(self.iid, support_report(self.store)["grounded"])
        self.cite(citation_key="renewed-use")
        self.assertEqual(self.missing(), [])
        with self.assertRaisesRegex(ProjectError, "stale"):
            record_review(self.store, old_review)
        record_review(self.store, self.accepting())
        self.assertIn(self.iid, support_report(self.store)["grounded"])

    def test_uncited_alternative_can_be_selected_without_covering_unused_proof(self):
        self.assertTrue(self.missing(self.first))
        self.assertEqual(self.missing(self.second), [])
        record_review(self.store, self.accepting(self.second))
        support = support_report(self.store)
        self.assertEqual(support["selected_proofs"][self.iid], self.second)
        self.assertFalse(support["eligibility"][self.first]["eligible"])

    def test_statement_citation_is_required_for_every_alternative(self):
        self.import_source(SOURCE.replace("For every real $x$", "As in \\cite[Theorem 1]{Order}, for every real $x$"))
        statement_slot = self.slots(None)[0]["reference_id"]
        for proof in (self.first, self.second):
            self.assertIn(statement_slot, [row["reference_id"] for row in self.missing(proof)])
        self.register()
        self.cite(proof_id=None)
        self.assertEqual(self.missing(self.second), [])
        self.assertEqual(len(self.missing(self.first)), 1)

    def test_nocite_and_navigation_are_inventory_without_proof_obligations(self):
        text = SOURCE.replace("Apply the square inequality in \\cite[Lemma 1]{Order} to the real number $x$.",
                              "Use the ordered-field argument. \\nocite{Order}")
        self.import_source(text)
        packet = prepare_review(self.store, self.iid, self.first)
        self.assertEqual(packet["obstacles"], [])
        self.assertEqual(packet["bibliographic_references"][0]["status"], "not_required")
        audit = audit_sources(self.store)
        self.assertEqual(len(audit["textual_references"]), 2)
        self.assertTrue(all(not row["required"] for row in audit["textual_references"]))
        self.assertEqual(audit["obstacles"], [])
        self.register()
        self.cite(status="candidate")
        self.assertIn("citation_unchecked", {row["kind"] for row in prepare_review(self.store, self.iid, self.first)["obstacles"]})

    def test_audit_exposes_unowned_inventory_only_when_requested_and_without_duplicates(self):
        ordinary = audit_sources(self.store)
        full = audit_sources(self.store, include_unowned=True)
        self.assertFalse(ordinary["unowned_inventory_included"])
        self.assertEqual(ordinary["unowned_bibliographic_references"], [])
        self.assertEqual([row["key"] for row in full["unowned_bibliographic_references"]], ["Survey"])
        self.assertEqual(full["textual_references"], ordinary["textual_references"])
        ids = [row["reference_id"] for row in full["textual_references"]]
        self.assertEqual(len(ids), len(set(ids)))
        self.assertEqual(len([row for row in full["obstacles"] if row["kind"] == "bibliography_evidence_missing"]), 1)

    def test_bad_reference_id_lists_and_internal_binding_overrides_are_rejected(self):
        self.register()
        identifier = self.slots()[0]["reference_id"]
        for value in (None, identifier, [3], ["bad"], [identifier, identifier]):
            with self.subTest(value=value):
                raw = self.citation()
                raw["reference_ids"] = value
                with self.assertRaises(ProjectError):
                    cite_source(self.store, self.iid, "source-order", raw)
        raw = self.citation()
        raw["reference_bindings"] = {identifier: "0" * 64}
        with self.assertRaisesRegex(ProjectError, "Unsupported citation"):
            cite_source(self.store, self.iid, "source-order", raw)

    def test_reader_reinterpretation_stales_statement_slot_evidence_even_with_same_declaration(self):
        self.import_source(SOURCE.replace("For every real $x$", "As in \\cite[Theorem 1]{Order}, for every real $x$"))
        self.register()
        self.cite(proof_id=None)
        original = self.store.state()["items"][self.iid]
        parser = latex.parse_project
        def changed_interpretation(*args, **kwargs):
            parsed = parser(*args, **kwargs)
            target = next(row for row in parsed["items"] if row["label"] == "square")
            target["bibliographic_references"][0]["notes"] = ["A newly interpreted locator"]
            return parsed
        with patch.object(latex, "parse_project", side_effect=changed_interpretation):
            ingest(self.store)
        current = self.store.state()["items"][self.iid]
        self.assertEqual(current["declaration_revision"], original["declaration_revision"])
        self.assertEqual(current["bibliographic_references"][0]["reference_id"], original["bibliographic_references"][0]["reference_id"])
        obstacles = citation_binding(self.store.state(), self.iid, self.second)["obstacles"]
        self.assertIn("citation_reference_stale", {row["kind"] for row in obstacles})
        self.assertTrue(self.missing(self.second))

    def test_source_line_relocation_preserves_signature_and_exact_acceptance_inputs(self):
        self.register()
        self.cite()
        report = self.accepting()
        self.import_source("% A harmless leading comment.\n" + SOURCE)
        self.assertEqual(self.missing(), [])
        self.assertEqual(prepare_review(self.store, self.iid, self.first)["template"]["binding"], report["binding"])
        record_review(self.store, report)

    def test_explicit_slot_evidence_without_internal_signatures_cannot_cover(self):
        self.register()
        citation = self.cite()
        state = self.store.state()
        old_style = state["citations"][citation["id"]]
        del old_style["reference_bindings"]
        old_style["revision"] = _revision(old_style)
        binding = citation_binding(state, self.iid, self.first)
        self.assertIn("citation_reference_bindings_invalid", {row["kind"] for row in binding["obstacles"]})
        self.assertEqual(binding["textual_references"][0]["covered_by"], [])

    def test_proof_header_locator_is_a_bound_obligation_even_when_body_is_unchanged(self):
        text = SOURCE.replace("\\begin{proof}\nApply the square inequality in \\cite[Lemma 1]{Order} to the real number $x$.",
                              "\\begin{proof}[Following \\cite[Lemma 1]{Order}]\nApply the stated square inequality.")
        self.import_source(text)
        self.assertTrue(self.slots()[0]["in_header"])
        self.register()
        self.cite()
        before = self.store.state()["proofs"][self.first]
        self.import_source(text.replace("[Lemma 1]", "[Lemma 2]"))
        after = self.store.state()["proofs"][self.first]
        self.assertEqual(before["text"], after["text"])
        self.assertNotEqual(before["revision"], after["revision"])
        self.assertTrue(self.missing())

    def test_frozen_release_keeps_covered_slots_after_current_evidence_withdrawal(self):
        self.register()
        citation = self.cite()
        record_review(self.store, self.accepting())
        release = create_release(self.store, "bibliography-v1", [self.iid])
        frozen = json.loads(Path(release["manifest"]).read_text())
        self.assertEqual(frozen["state"]["citations"][citation["id"]]["reference_ids"], citation["reference_ids"])
        self.assertTrue(frozen["state"]["proofs"][self.first]["bibliographic_references"])
        retire_citation(self.store, citation["id"], expected_revision=citation["revision"],
                        reason="A later review withdraws this live use.", reviewer="fixture-inspector")
        self.assertTrue(self.missing())
        exported = export_project(self.store, "exports/frozen", mode="reviewed", release_id="bibliography-v1")
        self.assertTrue(Path(exported["index"]).is_file())
        self.assertEqual(json.loads(Path(release["manifest"]).read_text()), frozen)


if __name__ == "__main__":
    unittest.main()
