"""Decision-level regressions for fast source and archive validation."""
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj import latex
from mathproj.project import ingest, set_context
from mathproj.store import ProjectError, ProjectStore, atomic_json
from mathproj.workflow import freshness, require_fresh


SOURCE = r"""\begin{lemma}\label{identity}For an integer $n$, $n+0=n$.\end{lemma}
\begin{proof}Use the additive identity.\end{proof}
"""


class FreshnessTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.store = ProjectStore.create(self.root, 'Freshness integration', 'TEST')
        self.write('content/main.tex', SOURCE)

    def write(self, path, text):
        target = self.root / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(text)
        return target

    def entries(self, values):
        manifest = self.store.manifest()
        manifest['entrypoints'] = values
        atomic_json(self.store.manifest_path, manifest)

    def test_clean_decision_checks_bytes_without_materializing_snapshot_or_parsing(self):
        ingest(self.store)
        with patch.object(latex, 'parse_project', side_effect=AssertionError('Unneeded parse')), \
             patch.object(self.store, 'snapshot', side_effect=AssertionError('Unneeded JSON decode')):
            self.assertTrue(freshness(self.store)['fresh'])
            require_fresh(self.store, self.store.state())

    def test_context_change_blocks_decision_without_reparsing_identical_text(self):
        ingest(self.store)
        set_context(self.store, 'domain', 'The parameter is now positive.', global_scope=True)
        with patch.object(latex, 'parse_project', side_effect=AssertionError('Unneeded parse')):
            result = freshness(self.store)
            self.assertEqual(result['reasons'], [{'kind': 'contexts_changed'}])

    def test_source_edit_uses_full_parse_for_precise_changed_graph_diagnostics(self):
        self.write('main.tex', '\\input{content/main}\n')
        self.entries(['main.tex'])
        ingest(self.store)
        self.write('content/new.tex', SOURCE.replace('identity', 'new'))
        self.write('main.tex', '\\input{content/main}\n\\input{content/new}\n')
        with patch.object(latex, 'parse_project', wraps=latex.parse_project) as parse:
            result = freshness(self.store)
        parse.assert_called_once()
        self.assertIn({'kind': 'source_added', 'path': 'content/new.tex'}, result['reasons'])

    def test_archive_corruption_is_not_hidden_by_authoritative_summary(self):
        report = ingest(self.store)
        path = self.store.meta / 'snapshots' / (report['snapshot'] + '.json')
        path.write_bytes(path.read_bytes() + b' ')
        with self.assertRaisesRegex(ProjectError, 'archive byte integrity'):
            require_fresh(self.store, self.store.state())

    def test_source_basis_cannot_be_replaced_through_disposable_state_cache(self):
        ingest(self.store)
        cache = self.store.state()
        self.write('content/main.tex', SOURCE.replace('integer', 'positive integer'))
        cache['source_basis']['files'] = []
        atomic_json(self.store.state_path, cache)
        self.assertFalse(freshness(self.store)['fresh'])

    def test_extensionless_include_shadow_blocks_before_another_import(self):
        self.write('main.tex', '\\input{content/main}\n')
        self.entries(['main.tex'])
        ingest(self.store)
        self.write('content/main', SOURCE)
        result = freshness(self.store)
        self.assertFalse(result['fresh'])
        self.assertIn({'kind': 'source_layout_changed'}, result['reasons'])
        self.assertIn({'kind': 'source_added', 'path': 'content/main'}, result['reasons'])

    def test_root_relative_shadow_blocks_even_when_new_target_bytes_are_equal(self):
        self.write('content/entry.tex', '\\input{main}\n')
        self.entries(['content/entry.tex'])
        ingest(self.store)
        self.write('main.tex', SOURCE)
        self.assertFalse(freshness(self.store)['fresh'])

    def test_unreachable_new_source_does_not_change_entrypoint_decision(self):
        self.entries(['content/main.tex'])
        ingest(self.store)
        self.write('content/unrelated.tex', SOURCE.replace('identity', 'elsewhere'))
        with patch.object(latex, 'parse_project', side_effect=AssertionError('Unneeded parse')):
            self.assertTrue(freshness(self.store)['fresh'])

    def test_reader_upgrade_requires_import_even_when_source_bytes_are_identical(self):
        ingest(self.store)
        with patch('mathproj.workflow.reader_fingerprint', return_value='0' * 64):
            result = freshness(self.store)
            self.assertIn({'kind': 'reader_changed'}, result['reasons'])
            self.assertFalse(result['fresh'])

    def test_legacy_snapshot_uses_full_validation_until_next_import(self):
        ingest(self.store)
        self.store.transact('legacy-compatibility-fixture', lambda state: state.update(source_basis=None))
        with patch.object(self.store, 'snapshot', wraps=self.store.snapshot) as snapshot:
            self.assertTrue(freshness(self.store)['fresh'])
        snapshot.assert_called_once()

    def test_incomplete_import_errors_continue_to_block_on_the_fast_path(self):
        self.write('content/main.tex', '\\begin{proof}Unattached proof.\\end{proof}\n')
        ingest(self.store, allow_incomplete=True)
        with patch.object(latex, 'parse_project', side_effect=AssertionError('Unneeded parse')):
            result = freshness(self.store)
        self.assertFalse(result['fresh'])
        self.assertTrue(any(row['kind'] == 'parse_error' for row in result['reasons']))

    def test_source_discovery_race_during_import_does_not_commit_partial_corpus(self):
        original_parse = latex.parse_project
        def racing_parse(*args, **kwargs):
            result = original_parse(*args, **kwargs)
            self.write('content/appeared.tex', SOURCE.replace('identity', 'appeared'))
            return result
        before = self.store.events.read_bytes()
        with patch.object(latex, 'parse_project', side_effect=racing_parse):
            with self.assertRaisesRegex(ProjectError, 'discovery or include resolution changed'):
                ingest(self.store)
        self.assertEqual(self.store.events.read_bytes(), before)
        self.assertIsNone(self.store.state()['current_snapshot'])


if __name__ == '__main__':
    unittest.main()
