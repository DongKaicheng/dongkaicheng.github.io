"""Regression checks for research coverage and typed, non-authoritative outlines."""

from __future__ import annotations

import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from research_outline import audit_outline, load_outline


def outline():
    def record(key, state="complete"):
        return {"id": key, "source_ids": ["source-1"], "statement_ref": "source.tex#" + key,
                "domain": "The category specified in source.tex", "hypotheses": [],
                "proof_state": state, "proof_refs": ["source.tex#proof-" + key],
                "open_obligations": [] if state == "complete" else ["Prove the stated limit passage."]}
    return {
        "schema": 1, "snapshot": "synthetic-snapshot", "scope": "All cases in the supplied source.",
        "sources": [{"id": "source-1", "locator": "source.tex at synthetic-snapshot", "availability": "available"}],
        "required_ids": ["A", "B", "H"],
        "records": [record("A"), record("B", "partial"), record("H")],
        "relations": [{"id": "A-H-B", "kind": "implication", "premises": ["A", "H"],
                       "conclusion": "B", "extra_hypotheses": [], "state": "established",
                       "justification_ref": "source.tex#reduction"}],
        "placements": [{"id": "A", "parent": None, "relation": None},
                       {"id": "H", "parent": None, "relation": None},
                       {"id": "B", "parent": "A", "relation": "A-H-B"}],
        "steps": [{"id": "limit", "target": "B", "inputs": ["A", "H"],
                  "problem_ref": "source.tex#problem-limit", "output_ref": "source.tex#limit-identity",
                  "mechanism": "Construct a common dominating function.",
                  "obstruction": "The current estimate depends on the approximation index.",
                  "acceptance": "Prove an integrable bound independent of that index."}],
    }


class ResearchOutlineTests(unittest.TestCase):
    def reject(self, value, fragment):
        result = audit_outline(value)
        self.assertFalse(result["valid"])
        self.assertTrue(any(fragment in e for e in result["errors"]), result)

    def test_complete_scope_keeps_partial_case_and_all_premises(self):
        value = outline()
        before = copy.deepcopy(value)
        result = audit_outline(value)
        self.assertTrue(result["valid"], result)
        self.assertEqual(result["checks"]["required_cases"], 3)
        self.assertEqual(value, before)
        self.assertIn("H", value["relations"][0]["premises"])

    def test_omitting_partial_result_fails(self):
        value = outline()
        value["records"] = [r for r in value["records"] if r["id"] != "B"]
        self.reject(value, "unaccounted case B")

    def test_missing_proof_remains_a_recovery_gap(self):
        value = outline()
        value["sources"][0]["availability"] = "summary_only"
        for row in value["records"]:
            row.update(proof_state="not_recovered", proof_refs=[], statement_ref=None,
                       open_obligations=["Recover the source statement and proof."])
        result = audit_outline(value)
        self.assertTrue(result["valid"], result)
        self.assertTrue(result["warnings"])

    def test_summary_cannot_supply_complete_proof(self):
        value = outline()
        value["sources"][0]["availability"] = "summary_only"
        self.reject(value, "recovered proof needs an available source")

    def test_partial_proof_needs_specific_gap_field(self):
        value = outline()
        value["records"][1]["open_obligations"] = []
        self.reject(value, "unresolved inference")

    def test_proof_recovery_and_conditional_support_are_separate(self):
        value = outline()
        value["records"][0]["open_obligations"] = ["Analytic prerequisite R11 awaits independent review."]
        self.assertTrue(audit_outline(value)["valid"])

    def test_conditional_arrow_requires_conditions(self):
        value = outline()
        value["relations"][0]["kind"] = "conditional_implication"
        self.reject(value, "explicit extra hypotheses")
        value["relations"][0]["extra_hypotheses"] = ["Uniform integrability of the selected family."]
        self.assertTrue(audit_outline(value)["valid"])

    def test_extra_conditions_cannot_be_unconditional(self):
        value = outline()
        value["relations"][0]["extra_hypotheses"] = ["A common fixed neighbourhood."]
        self.reject(value, "require conditional_implication")

    def test_relation_direction_cannot_be_reversed(self):
        value = outline()
        value["placements"][2]["parent"] = "B"
        self.reject(value, "direction")

    def test_analogy_cannot_be_consequence(self):
        value = outline()
        value["relations"][0]["kind"] = "analogy"
        self.reject(value, "not a consequence")

    def test_proof_use_cannot_be_single_parent_implication(self):
        value = outline()
        value["relations"][0]["kind"] = "proof_dependency"
        self.reject(value, "not a consequence")

    def test_proposed_bridge_is_not_an_established_consequence(self):
        value = outline()
        value["relations"][0]["state"] = "proposed"
        self.reject(value, "proposed implication")

    def test_established_arrow_needs_argument_locator(self):
        value = outline()
        value["relations"][0]["justification_ref"] = ""
        self.reject(value, "justification_ref")

    def test_missing_input_and_duplicate_record_fail(self):
        value = outline()
        value["relations"][0]["premises"].append("unknown")
        value["records"].append(value["records"][0].copy())
        self.reject(value, "unknown premise")
        self.reject(value, "duplicate ID")

    def test_programme_needs_problem_output_and_mechanism(self):
        for field in ("problem_ref", "output_ref", "mechanism", "obstruction", "acceptance"):
            with self.subTest(field=field):
                value = outline()
                value["steps"][0].pop(field)
                self.reject(value, field)

    def test_navigation_cycle_fails_even_if_implications_are_valid(self):
        value = outline()
        value["relations"].append({"id": "B-A", "kind": "implication", "premises": ["B"],
                                   "conclusion": "A", "extra_hypotheses": [], "state": "established",
                                   "justification_ref": "source.tex#reverse"})
        value["placements"][0].update(parent="B", relation="B-A")
        self.reject(value, "cyclic reading")

    def test_alternative_route_does_not_create_union_support_error(self):
        value = outline()
        value["relations"].append({"id": "B-A", "kind": "alternative_route", "premises": ["B"],
                                   "conclusion": "A", "extra_hypotheses": [], "state": "proposed"})
        self.assertTrue(audit_outline(value)["valid"])

    def test_boolean_schema_and_bad_fields_do_not_crash(self):
        value = outline()
        value["schema"] = True
        value["relations"][0].update(conclusion={}, premises=[[]], kind={})
        self.reject(value, "schema")
        self.assertFalse(audit_outline([])["valid"])

    def test_cli_is_read_only_and_returns_failure_code(self):
        script = Path(__file__).resolve().parents[1] / "research_outline.py"
        with tempfile.TemporaryDirectory() as temporary:
            path = Path(temporary) / "outline.json"
            raw = json.dumps(outline())
            path.write_text(raw)
            result = subprocess.run([sys.executable, str(script), str(path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertTrue(json.loads(result.stdout)["valid"])
            self.assertEqual(path.read_text(), raw)
            path.write_text('{"schema":1,"schema":2}')
            with self.assertRaises(ValueError):
                load_outline(path)
            result = subprocess.run([sys.executable, str(script), str(path)], capture_output=True, text=True)
            self.assertEqual(result.returncode, 2)
            self.assertIn("duplicate JSON key", result.stdout)


if __name__ == "__main__":
    unittest.main()
