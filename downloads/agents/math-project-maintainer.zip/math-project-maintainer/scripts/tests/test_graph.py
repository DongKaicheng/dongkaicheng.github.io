"""Behavioral regression tests for mathematical dependency bookkeeping."""

from __future__ import annotations

import copy
import json
from pathlib import Path
import random
import sys
import unittest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from mathproj.graph import impact_path, reverse_impact, solve_support


def proof(proof_id, conclusion, dependencies=(), eligible=True):
    return {"id": proof_id, "conclusion": conclusion,
            "dependencies": list(dependencies), "eligible": eligible}


class SupportTests(unittest.TestCase):
    def assert_order_valid(self, result, proofs, roots=()):
        positions = {node: position for position, node in enumerate(result["order"])}
        by_id = {row["id"]: row for row in proofs}
        self.assertEqual(set(positions), set(result["grounded"]))
        for conclusion, proof_id in result["selected_proofs"].items():
            self.assertEqual(by_id[proof_id]["conclusion"], conclusion)
            self.assertIs(by_id[proof_id]["eligible"], True)
            for dependency in set(by_id[proof_id]["dependencies"]):
                self.assertLess(positions[dependency], positions[conclusion])
        self.assertEqual(set(result["grounded"]) - set(roots), set(result["selected_proofs"]))

    def test_foundation_and_dependency_free_proof(self):
        proofs = [proof("p-a", "A"), proof("p-b", "B", ["A", "R"])]
        result = solve_support(["A", "B", "R"], proofs, ["R"])
        self.assertEqual(result["grounded"], ["A", "B", "R"])
        self.assertEqual(result["order"], ["R", "A", "B"])
        self.assertEqual(result["selected_proofs"], {"A": "p-a", "B": "p-b"})
        self.assert_order_valid(result, proofs, ["R"])

    def test_all_premises_are_required(self):
        result = solve_support(["A", "B", "C"], [proof("p", "C", ["A", "B"])], ["A"])
        self.assertEqual(result["grounded"], ["A"])
        self.assertEqual(result["blocked_details"]["C"]["proofs"][0]["ungrounded_dependencies"], ["B"])

    def test_alternative_proof_breaks_union_cycle(self):
        proofs = [proof("p1", "A", ["B"]), proof("p2", "A", ["C"]), proof("q", "B", ["A"])]
        result = solve_support(["A", "B", "C"], proofs, ["C"])
        self.assertEqual(result["selected_proofs"], {"A": "p2", "B": "q"})
        self.assertEqual(result["cycles"], [])
        self.assert_order_valid(result, proofs, ["C"])

    def test_actual_unsupported_cycle(self):
        result = solve_support(["A", "B"], [proof("p", "A", ["B"]), proof("q", "B", ["A"])])
        self.assertEqual(result["grounded"], [])
        self.assertEqual(result["cycles"], [["A", "B"]])
        self.assertEqual(result["blocked_details"]["A"]["reason"], "unresolved_dependencies")

    def test_self_cycle_and_explicit_foundation(self):
        proofs = [proof("p", "A", ["A"])]
        self.assertEqual(solve_support(["A"], proofs)["cycles"], [["A"]])
        admitted = solve_support(["A"], proofs, ["A"])
        self.assertEqual(admitted["cycles"], [])
        self.assertEqual(admitted["selected_proofs"], {})

    def test_ineligible_cycle_is_not_a_support_cycle(self):
        result = solve_support(["A", "B"], [proof("p", "A", ["B"], False), proof("q", "B", ["A"])])
        self.assertEqual(result["cycles"], [])
        self.assertEqual(result["blocked_details"]["A"]["reason"], "no_eligible_proofs")

    def test_missing_dependency_never_becomes_a_root(self):
        result = solve_support(["A"], [proof("p", "A", ["missing"])], ["missing"])
        self.assertEqual(result["grounded"], [])
        self.assertEqual(result["blocked"], ["A"])
        codes = {row["code"] for row in result["diagnostics"]}
        self.assertIn("unknown_root", codes)
        self.assertIn("missing_dependency", codes)

    def test_duplicate_proof_ids_are_all_excluded(self):
        result = solve_support(["A", "B"], [proof("p", "A"), proof("p", "B")])
        self.assertEqual(result["grounded"], [])
        self.assertIn("duplicate_proof_id", {row["code"] for row in result["diagnostics"]})
        self.assertFalse(result["blocked_details"]["A"]["proofs"][0]["valid"])

    def test_eligibility_must_be_literal_boolean(self):
        for value in ("true", 1, None):
            with self.subTest(value=value):
                row = proof("p", "A")
                row["eligible"] = value
                result = solve_support(["A"], [row])
                self.assertEqual(result["grounded"], [])
                self.assertIn("invalid_eligibility", {d["code"] for d in result["diagnostics"]})

    def test_status_in_node_metadata_does_not_admit_node(self):
        result = solve_support({"A": {"status": "accepted", "verified": True}}, [])
        self.assertEqual(result["grounded"], [])
        self.assertEqual(result["blocked_details"]["A"]["reason"], "no_proofs")

    def test_malformed_proofs_and_unknown_conclusion(self):
        rows = [None, {}, proof("p", "UNKNOWN"),
                {"id": "q", "conclusion": "A", "dependencies": "B", "eligible": True},
                {"id": "r", "conclusion": "A", "dependencies": [None], "eligible": True}]
        result = solve_support(["A"], rows)
        self.assertEqual(result["grounded"], [])
        codes = {d["code"] for d in result["diagnostics"]}
        self.assertTrue({"invalid_proof", "invalid_proof_identity", "unknown_conclusion",
                         "invalid_dependencies", "invalid_dependency_id"}.issubset(codes))

    def test_minimum_height_before_lexicographic_proof_id(self):
        proofs = [proof("p-x", "X", ["R"]), proof("p-y", "Y", ["X"]),
                  proof("a-deep", "A", ["Y"]), proof("z-shallow", "A", ["R"])]
        result = solve_support(["A", "R", "X", "Y"], proofs, ["R"])
        self.assertEqual(result["selected_proofs"]["A"], "z-shallow")
        self.assertEqual(result["depths"]["A"], 1)

    def test_determinism_under_input_permutations(self):
        nodes = ["A", "B", "C", "D", "R"]
        proofs = [proof("z", "A", ["R"]), proof("a", "A", ["R"]),
                  proof("p-b", "B", ["A"]), proof("p-c", "C", ["A"]),
                  proof("p-d", "D", ["C", "B", "B"])]
        expected = solve_support(nodes, proofs, ["R"])
        rng = random.Random(8921)
        for _ in range(30):
            rng.shuffle(nodes)
            rng.shuffle(proofs)
            for row in proofs:
                rng.shuffle(row["dependencies"])
            self.assertEqual(solve_support(nodes, proofs, ["R"]), expected)
        self.assertEqual(expected["selected_proofs"]["A"], "a")

    def test_inputs_are_not_mutated(self):
        nodes = {"A": {"status": "candidate"}, "R": {}}
        proofs = [proof("p", "A", ["R", "R"])]
        before = copy.deepcopy((nodes, proofs))
        solve_support(nodes, proofs, ["R"])
        self.assertEqual((nodes, proofs), before)

    def test_shared_diamonds(self):
        nodes = ["R"]
        rows = []
        predecessor = "R"
        for level in range(70):
            left, right, joint = f"L{level}", f"R{level}", f"J{level}"
            nodes.extend((left, right, joint))
            rows.extend((proof(f"pl{level}", left, [predecessor]),
                         proof(f"pr{level}", right, [predecessor]),
                         proof(f"pj{level}", joint, [left, right])))
            predecessor = joint
        result = solve_support(nodes, rows, ["R"])
        self.assertEqual(len(result["grounded"]), len(nodes))
        self.assert_order_valid(result, rows, ["R"])

    def test_ten_thousand_node_chain(self):
        nodes = [f"N{i:05}" for i in range(10000)]
        rows = [proof(f"p{i:05}", nodes[i], [nodes[i-1]]) for i in range(1, len(nodes))]
        result = solve_support(nodes, rows, [nodes[0]])
        self.assertEqual(result["order"], nodes)
        self.assertEqual(result["depths"][nodes[-1]], 9999)
        self.assertEqual(result["blocked"], [])

    def test_ten_thousand_node_cycle(self):
        nodes = [f"N{i:05}" for i in range(10000)]
        rows = [proof(f"p{i:05}", nodes[i], [nodes[(i-1) % len(nodes)]]) for i in range(len(nodes))]
        result = solve_support(nodes, rows)
        self.assertEqual(result["cycles"], [nodes])
        self.assertEqual(result["grounded"], [])
        escaped = solve_support(nodes, rows, [nodes[0]])
        self.assertEqual(escaped["cycles"], [])
        self.assertEqual(len(escaped["grounded"]), len(nodes))

    def test_against_small_independent_fixed_point_oracle(self):
        rng = random.Random(64391)
        for iteration in range(100):
            nodes = [str(i) for i in range(rng.randint(1, 12))]
            roots = rng.sample(nodes, rng.randrange(len(nodes)+1))
            rows = [proof(str(i), rng.choice(nodes), rng.sample(nodes, rng.randrange(min(4,len(nodes))+1)), rng.choice([True,False]))
                    for i in range(rng.randint(0, 30))]
            expected = set(roots)
            changed = True
            while changed:
                before = set(expected)
                for row in rows:
                    if row["eligible"] and set(row["dependencies"]) <= expected:
                        expected.add(row["conclusion"])
                changed = before != expected
            result = solve_support(nodes, rows, roots)
            with self.subTest(iteration=iteration):
                self.assertEqual(set(result["grounded"]), expected)
                self.assert_order_valid(result, rows, roots)

    def test_empty_input_and_invalid_container(self):
        result = solve_support([], [])
        self.assertEqual(result["grounded"], [])
        self.assertEqual(result["cycles"], [])
        with self.assertRaises(TypeError):
            solve_support("ABC", [])
        with self.assertRaises(TypeError):
            solve_support(["ABC"], [], "ABC")


class ImpactTests(unittest.TestCase):
    def edge(self, consumer, dependency, kind="uses_in_proof"):
        return {"consumer": consumer, "dependency": dependency, "kind": kind}

    def test_shortest_deterministic_witnesses(self):
        edges = [self.edge("C", "A"), self.edge("B", "A"),
                 self.edge("D", "C"), self.edge("D", "B"), self.edge("E", "D")]
        result = reverse_impact(edges, ["A"])
        self.assertEqual(result["affected"], ["A", "B", "C", "D", "E"])
        self.assertEqual(impact_path(result, "E"), ["A", "B", "D", "E"])
        self.assertEqual(result, reverse_impact(list(reversed(edges)), ["A", "A"]))

    def test_multiple_seeds_choose_nearest_then_stable_tie(self):
        edges = [self.edge("B", "A"), self.edge("C", "B"), self.edge("C", "Z"),
                 self.edge("D", "A"), self.edge("D", "Z")]
        result = reverse_impact(edges, ["Z", "A"])
        self.assertEqual(impact_path(result, "C"), ["Z", "C"])
        self.assertEqual(impact_path(result, "D"), ["A", "D"])

    def test_cycle_does_not_recurse_or_repeat(self):
        edges = [self.edge("B", "A"), self.edge("C", "B"), self.edge("A", "C")]
        result = reverse_impact(edges, ["A"])
        self.assertEqual(impact_path(result, "C"), ["A", "B", "C"])
        self.assertEqual(result["paths"]["A"]["distance"], 0)

    def test_isolated_seed_remains_affected(self):
        result = reverse_impact([], ["A"])
        self.assertEqual(result["affected"], ["A"])
        self.assertEqual(impact_path(result, "A"), ["A"])
        self.assertIn("seed_not_in_graph", {d["code"] for d in result["diagnostics"]})

    def test_empty_and_invalid_seeds(self):
        result = reverse_impact([self.edge("B", "A")], [])
        self.assertEqual(result["affected"], [])
        self.assertIn("empty_seeds", {d["code"] for d in result["diagnostics"]})
        invalid = reverse_impact([], ["", None])
        self.assertEqual(invalid["affected"], [])
        self.assertIn("invalid_impact_seed", {d["code"] for d in invalid["diagnostics"]})

    def test_invalid_edges_and_duplicate_kinds(self):
        edges = [None, {"consumer": "B"}, self.edge("B", "A", "z"), self.edge("B", "A", "a")]
        result = reverse_impact(edges, ["A"])
        self.assertEqual(result["paths"]["B"]["kind"], "a")
        self.assertEqual(len([d for d in result["diagnostics"] if d["code"] == "invalid_impact_edge"]), 2)

    def test_ten_thousand_chain_compact_output(self):
        nodes = [f"N{i:05}" for i in range(10000)]
        edges = [self.edge(nodes[i], nodes[i-1]) for i in range(1,len(nodes))]
        result = reverse_impact(edges, [nodes[0]])
        self.assertEqual(impact_path(result, nodes[-1]), nodes)
        self.assertEqual(result["paths"][nodes[-1]]["distance"], 9999)
        self.assertLess(len(json.dumps(result)), 2_000_000)

    def test_unknown_target_and_corrupt_witness(self):
        original = reverse_impact([self.edge("B", "A")], ["A"])
        with self.assertRaises(KeyError):
            impact_path(original, "unaffected")
        for field, value in (("predecessor", "B"), ("distance", 5), ("seed", "wrong")):
            result = copy.deepcopy(original)
            result["paths"]["B"][field] = value
            with self.subTest(field=field), self.assertRaises(ValueError):
                impact_path(result, "B")
        result = copy.deepcopy(original)
        del result["paths"]["A"]
        with self.assertRaises(ValueError):
            impact_path(result, "B")


if __name__ == "__main__":
    unittest.main()
