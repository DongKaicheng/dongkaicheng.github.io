#!/usr/bin/env python3
"""Run the Math Project Maintainer command-line tools."""
from mathproj.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
