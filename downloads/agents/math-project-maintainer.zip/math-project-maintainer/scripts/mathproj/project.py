"""Stable item identities, snapshots, context changes, and impact analysis."""
from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
from fnmatch import fnmatchcase
from pathlib import Path
import hashlib
import re
import subprocess

from .store import ProjectError, ProjectStore, digest, utc_now, valid_name


DECLARATIONS = {"definition", "convention", "notation", "situation"}
NAVIGATION = {"document", "section", "subsection", "chapter", "part", "remark", "remarks"}


def reader_fingerprint() -> str:
    """Bind parsing and registry interpretation to their exact source code.

    Registry normalization determines revisions and reference ownership too;
    upgrading it requires a new import even when the LaTeX scanner is unchanged.
    """
    directory = Path(__file__).parent
    return digest({name: hashlib.sha256((directory / name).read_bytes()).hexdigest()
                   for name in ("latex.py", "project.py")})


def resolve_item(state: dict, reference: str, *, active: bool = True) -> str:
    if reference in state["items"]:
        item_id = reference
    elif reference in state["aliases"]:
        item_id = state["aliases"][reference]
    else:
        hits = [i for i, item in state["items"].items()
                if item.get("label") == reference and item.get("lifecycle") == "active"]
        if len(hits) != 1:
            reason = "ambiguous" if hits else "unknown"
            raise ProjectError(f"{reason.capitalize()} mathematical item: {reference}")
        item_id = hits[0]
    if active and state["items"][item_id].get("lifecycle") != "active":
        raise ProjectError(f"Item {item_id} is not active; inspect its history or replacement")
    return item_id


def matching_contexts(state: dict, item: dict) -> list[dict]:
    path = item["source"]["path"]
    label = item.get("label", "")
    matched = []
    for key, ctx in sorted(state["contexts"].items()):
        if not ctx.get("active", True):
            continue
        scope = ctx["scope"]
        paths, labels = scope.get("paths", []), scope.get("labels", [])
        if scope.get("global") or any(fnmatchcase(path, p) for p in paths) or label in labels:
            matched.append({"key": key, "text": ctx["text"],
                            "revision": ctx["revision"]})
    return matched


def _git_head(root: Path) -> str | None:
    try:
        result = subprocess.run(["git", "-C", str(root), "rev-parse", "HEAD"],
                                capture_output=True, text=True, timeout=5)
        value = result.stdout.strip()
        return value if result.returncode == 0 and re.fullmatch(r"[0-9a-f]{40,64}", value) else None
    except (OSError, subprocess.TimeoutExpired):
        return None


def _text_hash(item: dict) -> str:
    return digest({"kind": item["kind"], "title": item.get("title", ""),
                   "statement": item["statement"].replace("\r\n", "\n").strip()})


def _reference_target(ref: dict, key_ids: dict, labels: dict, state: dict) -> str | None:
    if ref.get("target_key") in key_ids:
        return key_ids[ref["target_key"]]
    label = ref.get("label")
    if label in state["items"] and state["items"][label].get("lifecycle") == "active":
        return label
    candidates = labels.get(label, [])
    if len(candidates) == 1:
        return candidates[0]
    return None


def _refs(refs: list, key_ids: dict, labels: dict, state: dict, proof_id: str = "") -> list:
    result = []
    for index, ref in enumerate(refs):
        target = _reference_target(ref, key_ids, labels, state)
        result.append({**ref, "target_id": target,
                       "application_key": digest([proof_id, index, ref.get("label")])[:24] if proof_id else None})
    return result


def _bibliographic_refs(refs: list, subject: str) -> list:
    return [{**deepcopy(ref), "reference_id": digest([subject, index, ref.get("key")])[:24]}
            for index, ref in enumerate(refs)]


def _bibliographic_signature(refs: list) -> list:
    return [{key: row.get(key) for key in ("key", "command", "notes", "role", "in_header")} for row in refs]


def ingest(store: ProjectStore, *, allow_incomplete: bool = False) -> dict:
    from .latex import parse_project
    from .changes import pending_change
    if pending_change(store):
        raise ProjectError("Recover the pending source change before importing files")
    manifest = store.manifest()
    reader_version = reader_fingerprint()
    parsed = parse_project(store.root, entrypoints=manifest["entrypoints"] or None,
                           source_roots=manifest["source_roots"])
    errors = [x for x in parsed["diagnostics"] if x.get("severity") == "error"]
    if not parsed["files"] and not allow_incomplete:
        raise ProjectError("No source files were found; refusing an empty import that could hide all existing items")
    if errors and not allow_incomplete:
        raise ProjectError("Import has structural errors; no state was changed: " +
                           "; ".join(x["message"] for x in errors[:8]))

    def mutate(state):
        if pending_change(store):
            raise ProjectError("Recover the pending source change before importing files")
        if digest(store.manifest()) != digest(manifest):
            raise ProjectError("Project manifest changed during parsing; import again")
        if reader_fingerprint() != reader_version:
            raise ProjectError("Source reader changed during parsing; import again")
        if parsed.get("source_layout") is not None:
            from .latex import source_layout
            current_layout = source_layout(store.root, entrypoints=manifest["entrypoints"] or None,
                                           source_roots=manifest["source_roots"],
                                           lookups=parsed["source_layout"].get("lookups", []))
            if current_layout != parsed["source_layout"]:
                raise ProjectError("Source discovery or include resolution changed during parsing; import again")
        for source in parsed["files"]:
            path = store.root / source["path"]
            try:
                current_hash = hashlib.sha256(path.read_bytes()).hexdigest()
            except OSError as exc:
                raise ProjectError("Source changed during parsing; import again: "+source["path"]) from exc
            if current_hash != source["sha256"]:
                raise ProjectError("Source changed during parsing; import again: "+source["path"])
        old_edges = dependency_edges(state, include_candidates=True)
        old_items = deepcopy(state["items"])
        old_proofs = deepcopy(state["proofs"])
        recorded_by_item = defaultdict(list)
        for pid, proof in old_proofs.items():
            if proof.get("origin") == "recorded" and proof.get("active"):
                recorded_by_item[proof["conclusion"]].append(pid)
        prior_keys = {i["source_key"]: iid for iid, i in old_items.items()}
        parsed_keys = {i["key"] for i in parsed["items"]}
        if len(parsed_keys) != len(parsed["items"]):
            raise ProjectError("Duplicate source keys prevent a trustworthy import")
        old_candidates = defaultdict(list)
        for iid, item in old_items.items():
            if item.get("source_key") not in parsed_keys and item.get("origin") != "external":
                old_candidates[(item.get("label"), item.get("statement_hash"))].append(iid)
        label_counts = Counter(i.get("label") for i in parsed["items"])
        key_ids, used, identity_notes = {}, set(), []
        for item in parsed["items"]:
            iid = item.get("explicit_id")
            if iid:
                if not re.fullmatch(re.escape(manifest["namespace"])+r"-[0-9]{6,}", iid):
                    raise ProjectError(f"Invalid explicit ID {iid!r}")
                if iid not in old_items:
                    raise ProjectError(f"Explicit ID {iid} is not registered; import first and use the assigned ID")
            else:
                iid = prior_keys.get(item["key"]) or state["aliases"].get(item["key"])
            if not iid:
                candidates = old_candidates.get((item.get("label"), _text_hash(item)), [])
                if len(candidates) == 1 and label_counts[item.get("label")] == 1:
                    iid = candidates[0]
                    identity_notes.append({"item_id": iid, "kind": "relocated_same_label_and_statement",
                                           "from": old_items[iid]["source_key"], "to": item["key"]})
            if not iid:
                iid = f"{manifest['namespace']}-{state['next_id']:06d}"
                state["next_id"] += 1
            if iid in used:
                raise ProjectError(f"Two current source objects claim ID {iid}; use distinct labels/IDs")
            used.add(iid)
            key_ids[item["key"]] = iid
        labels = defaultdict(list)
        for item in parsed["items"]:
            iid = key_ids[item["key"]]
            for label in [item.get("label"), *item.get("label_aliases", [])]:
                if label and iid not in labels[label]:
                    labels[label].append(iid)

        active_proofs = set()
        for item in parsed["items"]:
            iid = key_ids[item["key"]]
            contexts = matching_contexts(state, item)
            context_hash = digest(contexts)
            sr = _text_hash(item)
            declaration_revision = digest([sr, context_hash])
            statement_refs = _refs(item.get("references", []), key_ids, labels, state, iid+":statement")
            bibliography_refs = _bibliographic_refs(item.get("bibliographic_references", []), iid+":statement")
            proof_ids = []
            for index, parsed_proof in enumerate(item.get("proofs", [])):
                pid = f"{iid}:proof:{index+1}"
                proof_refs = _refs(parsed_proof.get("references", []), key_ids, labels, state, pid)
                normalized_refs = [{"label": r.get("label"), "target_id": r.get("target_id"),
                                    "target_clause": r.get("target_clause"), "command": r.get("command")}
                                   for r in proof_refs]
                proof_bibliography = _bibliographic_refs(parsed_proof.get("bibliographic_references", []), pid)
                proof_content = {"text": parsed_proof["text"], "declaration": declaration_revision,
                                 "references": normalized_refs}
                if proof_bibliography:
                    proof_content["bibliographic_references"] = _bibliographic_signature(proof_bibliography)
                revision = digest(proof_content)
                state["proofs"][pid] = {"id": pid, "conclusion": iid, "text": parsed_proof["text"],
                                        "revision": revision, "source": parsed_proof.get("source", item["source"]),
                                        "references": proof_refs, "active": True, "origin": "latex"}
                if proof_bibliography:
                    state["proofs"][pid]["bibliographic_references"] = proof_bibliography
                proof_ids.append(pid)
                active_proofs.add(pid)
            # Explicitly recorded alternative proofs survive source imports.
            for pid in recorded_by_item.get(iid, []):
                proof_ids.append(pid)
                active_proofs.add(pid)
            item_content = {"statement": sr, "context": context_hash,
                               "proofs": [state["proofs"][pid]["revision"] for pid in proof_ids],
                               "statement_references": [{"label": r.get("label"), "target_id": r.get("target_id"),
                                                         "target_clause": r.get("target_clause")}
                                                        for r in statement_refs]}
            if bibliography_refs:
                item_content["bibliographic_references"] = _bibliographic_signature(bibliography_refs)
            revision = digest(item_content)
            state["items"][iid] = {"id": iid, "source_key": item["key"], "label": item.get("label"),
                                    "label_aliases": item.get("label_aliases", []), "kind": item["kind"],
                                    "title": item.get("title", ""), "statement": item["statement"],
                                    "source": item["source"], "section": item.get("section", []),
                                    "statement_hash": sr, "declaration_revision": declaration_revision,
                                    "context_hash": context_hash, "contexts": contexts,
                                    "revision": revision, "proof_ids": proof_ids,
                                    "statement_references": statement_refs, "lifecycle": "active", "origin": "latex"}
            if bibliography_refs:
                state["items"][iid]["bibliographic_references"] = bibliography_refs
            if "fragment_context" in item:
                state["items"][iid]["fragment_context"] = deepcopy(item["fragment_context"])
            state["aliases"][item["key"]] = iid
        for iid, item in state["items"].items():
            if item.get("origin") == "latex" and iid not in used:
                item["lifecycle"] = "missing"
        for pid, proof in state["proofs"].items():
            if proof.get("origin") == "latex" and pid not in active_proofs:
                proof["active"] = False
        changed = sorted(i for i in used if i in old_items and state["items"][i]["revision"] != old_items[i]["revision"])
        removed = sorted(i for i in old_items if old_items[i].get("lifecycle") == "active"
                         and state["items"][i].get("lifecycle") != "active")
        added = sorted(used - old_items.keys())
        moved = sorted(i for i in used & old_items.keys()
                       if state["items"][i]["source_key"] != old_items[i]["source_key"])
        snapshot = {"schema_version": 1, "source_encoding": "utf-8-exact", "manifest": manifest,
                    "git_commit": _git_head(store.root), "files": parsed["files"],
                    "items": {i: deepcopy(v) for i, v in state["items"].items() if v.get("lifecycle") == "active"},
                    "proofs": {i: deepcopy(v) for i, v in state["proofs"].items() if v.get("active")},
                    "contexts": deepcopy(state["contexts"]), "source_records": deepcopy(state["source_records"]),
                    "citations": deepcopy(state["citations"]), "diagnostics": parsed["diagnostics"]}
        if parsed.get("source_layout") is not None:
            snapshot["source_layout"] = parsed["source_layout"]
            snapshot["reader_fingerprint"] = reader_version
        sid = store.put_snapshot(snapshot)
        state["current_snapshot"] = sid
        state["source_basis"] = {
            "snapshot": sid, "snapshot_file_sha256": store.snapshot_bytes_hash(sid),
            "manifest_hash": digest(manifest), "contexts_hash": digest(state["contexts"]),
            "files": [{"path": f["path"], "sha256": f["sha256"]} for f in parsed["files"]],
            "source_layout": parsed.get("source_layout"), "reader_fingerprint": reader_version,
            "diagnostics": parsed["diagnostics"],
        }
        if sid not in state["snapshot_history"]:
            state["snapshot_history"].append(sid)
        state["manifest_hash"] = digest(manifest)
        report = {"snapshot": sid, "added": added, "changed": changed, "moved": moved,
                  "missing": removed, "identity_notes": identity_notes,
                  "diagnostics": parsed["diagnostics"], "items": len(used), "files": len(parsed["files"])}
        # Preserve a repair queue for mathematical changes; do not call a result false.
        if changed or removed:
            from .graph import reverse_impact
            edges = old_edges + dependency_edges(state, include_candidates=True)
            impact = reverse_impact(edges, changed+removed)
            report["impact"] = impact
            for iid in impact["affected"]:
                if iid not in state["items"]:
                    continue
                task_id = "recheck-" + digest([sid, iid])[:16]
                state["tasks"].setdefault(task_id, {"id": task_id, "title": f"Recheck {iid} after an upstream/source change",
                    "target_ids": [iid], "kind": "recheck", "status": "ready", "base_snapshot": sid,
                    "created_at": utc_now(), "updated_at": utc_now(), "checkpoints": [],
                    "dependencies": [], "assignee": None, "changed_inputs": changed+removed,
                    "acceptance": "Resolve the affected application, context, or support and record a current review."})
        return report
    return store.transact("import", mutate, details={"allow_incomplete": allow_incomplete})


def dependency_edges(state: dict, *, include_candidates: bool = True) -> list[dict]:
    edges = []
    manual_by_subject = defaultdict(list)
    for app in state["applications"].values():
        if app.get("manual") and app.get("relation") == "uses":
            manual_by_subject[app.get("proof_id")].append(app)
    for iid, item in state["items"].items():
        if item.get("lifecycle") != "active":
            continue
        statement_rev = digest([item["declaration_revision"],
                [{"label": r.get("label"), "target_id": r.get("target_id"), "target_clause": r.get("target_clause")}
                 for r in item.get("statement_references", [])]])
        for ref in item.get("statement_references", []):
            app = state["applications"].get(ref.get("application_key"), {})
            target = state["items"].get(ref.get("target_id"), {})
            current = app.get("proof_revision") == statement_rev and app.get("target_revision") == target.get("declaration_revision")
            if current and app.get("relation") in {"mention", "internal"}:
                continue
            if ref.get("target_id") and ref["target_id"] != iid and (include_candidates or current):
                edges.append({"consumer": iid, "dependency": ref["target_id"],
                              "kind": "uses_in_statement" if current else "statement_reference"})
        for pid in item["proof_ids"]:
            proof = state["proofs"].get(pid, {})
            if not proof.get("active"):
                continue
            for ref in proof.get("references", []):
                app = state["applications"].get(ref.get("application_key"), {})
                target = state["items"].get(ref.get("target_id"), {})
                current_app = (app.get("proof_revision") == proof.get("revision") and
                               app.get("target_revision") == target.get("declaration_revision"))
                relation = app.get("relation") if current_app else None
                if relation in {"mention", "internal"}:
                    continue
                if ref.get("target_id") and (relation == "uses" or include_candidates):
                    edges.append({"consumer": iid, "dependency": ref["target_id"],
                                  "kind": "uses_in_proof" if relation == "uses" else "candidate_reference"})
            for dep in proof.get("declared_dependencies", []):
                edges.append({"consumer": iid, "dependency": dep, "kind": "declared_dependency"})
        # Applications may expose an implicit mathematical prerequisite that is
        # absent from the source's literal ref commands.
        subjects = {p: state["proofs"][p].get("revision") for p in item["proof_ids"] if p in state["proofs"]}
        subjects[iid+":statement"] = statement_rev
        for subject, revision in subjects.items():
            for app in manual_by_subject.get(subject, []):
                if app.get("proof_revision") == revision:
                    edges.append({"consumer": iid, "dependency": app["target_id"], "kind": "reviewed_implicit_dependency"})
    return sorted({(e["consumer"],e["dependency"],e["kind"]):e for e in edges}.values(),
                  key=lambda e:(e["consumer"],e["dependency"],e["kind"]))


def set_context(store: ProjectStore, key: str, text: str, *, paths: list[str] | None = None,
                labels: list[str] | None = None, global_scope: bool = False) -> dict:
    valid_name(key, "context key")
    if not text.strip():
        raise ProjectError("A context must contain its actual convention or assumptions")
    if not global_scope and not paths and not labels:
        raise ProjectError("Specify global scope, paths, or labels")
    for path in paths or []:
        if Path(path).is_absolute() or ".." in Path(path).parts:
            raise ProjectError("Context path patterns must stay within the project")
    scope = {"global": global_scope, "paths": sorted(paths or []), "labels": sorted(labels or [])}
    context = {"key": key, "text": text, "scope": scope, "revision": digest([text, scope]), "active": True}
    def change(state):
        state["contexts"][key] = context
        return {"context": context, "next": "Import the sources to bind the changed context and create recheck tasks."}
    return store.transact("set_context", change, details={"key": key})


def set_foundation(store: ProjectStore, reference: str, reason: str, kind: str = "external_theorem") -> dict:
    if kind not in {"axiom", "definition", "external_theorem", "assumption"}:
        raise ProjectError("Unknown foundation kind")
    if not reason.strip():
        raise ProjectError("An admitted input requires an explicit reason/source")
    def change(state):
        from .workflow import require_fresh
        require_fresh(store, state)
        iid = resolve_item(state, reference)
        item = state["items"][iid]
        if item["kind"] in NAVIGATION:
            raise ProjectError("Navigation and commentary objects cannot be admitted as mathematical foundations")
        source_binding = None
        if kind == "external_theorem":
            from .sources import citation_binding
            bibliography = citation_binding(state, iid)
            if not bibliography["citations"] or bibliography["obstacles"]:
                raise ProjectError("An external theorem admission requires current checked item-level citation evidence with an exact source locator")
            source_binding = {k: bibliography[k] for k in ("sources", "citations", "retired_citations")}
        entry = {"item_id": iid, "revision": item["revision"],
                 "declaration_revision": item["declaration_revision"], "kind": kind,
                 "reason": reason, "source_binding": source_binding, "recorded_at": utc_now(), "active": True}
        state["foundations"][iid] = entry
        return {"foundation": entry, "status": "explicitly_admitted_input"}
    return store.transact("admit_foundation", change, details={"reference": reference})


def item_history(store: ProjectStore, reference: str) -> list[dict]:
    state = store.state()
    iid = resolve_item(state, reference, active=False)
    result = []
    for sid in state["snapshot_history"]:
        item = store.snapshot(sid)["items"].get(iid)
        result.append({"snapshot": sid, "present": item is not None,
                       "item": item})
    return result
