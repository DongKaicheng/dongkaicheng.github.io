"""Read-only Stacks Tag navigation into an integrity-checked local snapshot.

The caller supplies the official-format ``tags/tags`` registry.  Its bytes are
hashed, never fetched or installed.  Matching uses the snapshot's source-file
basename and its actual primary labels / label aliases.  A tag remains an
external identifier; no permanent item ID, alias, or review record is changed.
"""

from __future__ import annotations

from collections import Counter, defaultdict
from copy import deepcopy
import csv
from dataclasses import dataclass
import hashlib
from itertools import islice
from pathlib import Path, PurePosixPath
import re
from typing import Iterable

from .store import ProjectError, ProjectStore


MAX_REGISTRY_BYTES = 16 * 1024 * 1024
MAX_REGISTRY_RECORDS = 250_000
MAX_LOOKUP_TAGS = 256
MAX_AMBIGUOUS_CANDIDATES = 20
MAX_SOURCE_DIAGNOSTICS = 20
MAX_AUDIT_DIAGNOSTICS = 1_000
_TAG = re.compile(r"[A-Z0-9]{4}")
_SNAPSHOT = re.compile(r"[0-9a-f]{64}")
# A full label is literal navigation data, not TeX.  Preserve punctuation such
# as '+' (which is present in the official registry), without interpreting it.
_FULL_LABEL = re.compile(r"[^\s,{}\\\x00-\x1f\x7f]+-[^\s,{}\\\x00-\x1f\x7f]+")


@dataclass(frozen=True)
class _Registry:
    tags: dict[str, str]
    metadata: dict


def _valid_tag(tag: str) -> str:
    if not isinstance(tag, str) or not _TAG.fullmatch(tag):
        raise ProjectError("A Stacks Tag must contain exactly four uppercase ASCII letters or digits")
    return tag


def _read_registry(registry: str | Path) -> _Registry:
    try:
        path = Path(registry).expanduser()
        if not path.is_absolute():
            raise ProjectError("The Stacks tag registry must be an absolute local file path")
        path = path.resolve()
        if not path.is_file():
            raise ProjectError(f"The Stacks tag registry is not a regular file: {path}")
        with path.open("rb") as handle:
            raw = handle.read(MAX_REGISTRY_BYTES + 1)
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        raise ProjectError(f"Cannot read the local Stacks tag registry: {exc}") from exc
    if len(raw) > MAX_REGISTRY_BYTES:
        raise ProjectError(f"Stacks tag registry exceeds the {MAX_REGISTRY_BYTES}-byte limit")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeError as exc:
        raise ProjectError("The Stacks tag registry must be UTF-8 text") from exc

    tags, labels, first_lines = {}, {}, {}
    record_count = duplicate_count = 0
    for line_number, line in enumerate(text.splitlines(), 1):
        if not line.strip() or line.lstrip().startswith("#"):
            continue
        try:
            fields = next(csv.reader([line], strict=True))
        except csv.Error as exc:
            raise ProjectError(f"Malformed Stacks registry CSV at line {line_number}: {exc}") from exc
        if len(fields) != 2:
            raise ProjectError(f"Stacks registry line {line_number} must contain tag,full_label")
        tag, label = (value.strip() for value in fields)
        if not _TAG.fullmatch(tag):
            raise ProjectError(f"Invalid Stacks Tag at registry line {line_number}: {tag!r}")
        if not _FULL_LABEL.fullmatch(label):
            raise ProjectError(f"Invalid filename-prefixed label at registry line {line_number}: {label!r}")
        record_count += 1
        if record_count > MAX_REGISTRY_RECORDS:
            raise ProjectError(f"Stacks tag registry exceeds the {MAX_REGISTRY_RECORDS}-record limit")
        if tag in tags:
            if tags[tag] != label:
                raise ProjectError(f"Conflicting Stacks Tag {tag} at registry lines {first_lines[tag]} and {line_number}")
            duplicate_count += 1
            continue
        if label in labels:
            raise ProjectError(f"Conflicting tags {labels[label]} and {tag} for full label {label!r} at registry line {line_number}")
        tags[tag], labels[label], first_lines[tag] = label, tag, line_number
    if not tags:
        raise ProjectError("The Stacks tag registry contains no tag records")
    return _Registry(tags, {"path": str(path), "sha256": hashlib.sha256(raw).hexdigest(),
                            "tag_count": len(tags), "record_count": record_count,
                            "duplicate_record_count": duplicate_count})


def _selected_snapshot(store: ProjectStore, snapshot: str | None) -> tuple[str, dict, bool]:
    if snapshot is not None and not isinstance(snapshot, str):
        raise ProjectError("Snapshot selection must be a complete snapshot ID or 'current'")
    # replay without repair is strictly read-only, even if write.lock is
    # absent.  An incomplete concurrent append fails closed; retry after the
    # writer finishes.  Neither state.json nor historical state aliases are
    # navigation evidence for the selected snapshot.
    state, _ = store.replay()
    selected = state.get("current_snapshot") if snapshot in {None, "current"} else snapshot
    if not isinstance(selected, str) or not _SNAPSHOT.fullmatch(selected):
        raise ProjectError("Select a complete snapshot ID, or import the current project first")
    if selected not in state.get("snapshot_history", []):
        raise ProjectError(f"Snapshot {selected} is not in the recorded project history")
    value = store.snapshot(selected)
    for field in ("items", "proofs"):
        if not isinstance(value.get(field), dict):
            raise ProjectError(f"Snapshot {selected} has no valid {field} collection")
    return selected, value, selected == state.get("current_snapshot")


def _target(item: dict, label: str, files: dict) -> dict:
    source = item.get("source")
    if not isinstance(source, dict) or source.get("path") not in files:
        raise ProjectError(f"Snapshot item {item.get('id')} has no archived local source")
    if not isinstance(item.get("revision"), str) or not _SNAPSHOT.fullmatch(item["revision"]):
        raise ProjectError(f"Snapshot item {item.get('id')} has no valid revision")
    for field in ("start_line", "end_line"):
        if not isinstance(source.get(field), int) or isinstance(source[field], bool) or source[field] < 1:
            raise ProjectError(f"Snapshot item {item.get('id')} has no valid source span")
    if source["end_line"] < source["start_line"]:
        raise ProjectError(f"Snapshot item {item.get('id')} has a reversed source span")
    alias = label != item.get("label")
    target = {"item_id": item["id"], "item_revision": item["revision"],
              "source_key": item.get("source_key"), "kind": item.get("kind"),
              "primary_label": item.get("label"), "matched_label": label,
              "target_clause": label if alias else None,
              "target_scope": "label_alias" if alias else
                              "navigation" if item.get("kind") in {"section", "document"} else "item",
              "source": deepcopy(source), "source_sha256": files[source["path"]]["sha256"],
              "source_scope": "owning_item" if alias else "item"}
    if alias:
        target["clause_span_available"] = False
    return target


def _index(snapshot: dict) -> dict[str, list[dict]]:
    files = {source["path"]: source for source in snapshot["files"]}
    source_errors = defaultdict(list)
    for diagnostic in snapshot.get("diagnostics", []):
        if diagnostic.get("severity") == "error":
            source_errors[diagnostic.get("path")].append(
                {key: diagnostic.get(key) for key in ("code", "severity", "path", "line")})
    # An unattached proof does not make an existing indexed source label
    # ambiguous.  Keep this sole exception explicit and expose its diagnostics
    # on every affected mapped target; no claim about proof validity follows.
    error_paths = {diagnostic.get("path") for diagnostic in snapshot.get("diagnostics", [])
                   if diagnostic.get("severity") == "error" and diagnostic.get("code") != "orphan_proof"}
    candidates = defaultdict(dict)
    for item_id, item in sorted(snapshot["items"].items()):
        if not isinstance(item, dict) or item.get("id") != item_id:
            raise ProjectError("Snapshot item identities are inconsistent")
        if item.get("lifecycle", "active") != "active" or item.get("origin") == "external":
            continue
        source = item.get("source", {})
        if not isinstance(source, dict) or not isinstance(source.get("path"), str):
            raise ProjectError(f"Snapshot item {item_id} has no valid source path")
        aliases = item.get("label_aliases", [])
        if not isinstance(aliases, list) or not all(isinstance(label, str) and label for label in aliases):
            raise ProjectError(f"Snapshot item {item_id} has invalid label aliases")
        label = item.get("label")
        if label is not None and (not isinstance(label, str) or not label):
            raise ProjectError(f"Snapshot item {item_id} has an invalid primary label")
        # The official registry uses the chapter filename without .tex,
        # followed by '-' and the literal source label.  Do not strip an
        # arbitrary suffix, infer a label from its spelling, or consult old
        # source-key aliases after a move.  Duplicate basenames can produce
        # multiple exact targets and remain explicitly ambiguous.
        source_path = source["path"]
        proof_paths = {proof["source"]["path"] for proof_id in item.get("proof_ids", [])
                       if (proof := snapshot["proofs"].get(proof_id))
                       and proof.get("origin") == "latex" and proof.get("active", True)
                       and isinstance(proof.get("source"), dict)
                       and isinstance(proof["source"].get("path"), str)}
        for alias in dict.fromkeys(([label] if label is not None else []) + aliases):
            target = _target(item, alias, files)
            possible_paths = {source_path}
            if alias != label:
                possible_paths |= proof_paths
            diagnostics = [diagnostic for path in sorted(possible_paths) for diagnostic in source_errors[path]]
            if diagnostics:
                target["source_diagnostics"] = diagnostics[:MAX_SOURCE_DIAGNOSTICS]
                target["source_diagnostics_omitted"] = max(0, len(diagnostics) - MAX_SOURCE_DIAGNOSTICS)
            if possible_paths & error_paths:
                # allow_incomplete imports can deduplicate repeated labels in
                # label_aliases.  Do not turn that lost occurrence count into
                # a false unique target, or trust other structural errors.
                target["_unavailable"] = "source_has_parse_errors"
                target["_diagnostic_sources"] = sorted(possible_paths & error_paths)
            elif len(possible_paths) > 1:
                # Separately located proof labels are attached to the owner's
                # alias list, but their individual paths are not archived.
                # Every possible prefix stays unresolved until the parser
                # stores per-alias provenance.  Never invent an owner prefix.
                target["_unavailable"] = "alias_source_not_recorded"
                target["_diagnostic_sources"] = sorted(possible_paths)
            for path in sorted(possible_paths):
                full_label = PurePosixPath(path).stem + "-" + alias
                candidates[full_label][(item_id, alias)] = target
    return {label: list(targets.values()) for label, targets in candidates.items()}


def _result(tag: str, registry: _Registry, index: dict, snapshot: str) -> dict:
    result = {"tag": tag, "official_url": "https://stacks.math.columbia.edu/tag/" + tag,
              "snapshot": snapshot, "registry_sha256": registry.metadata["sha256"],
              "full_label": registry.tags.get(tag)}
    if tag not in registry.tags:
        return {**result, "status": "unmapped", "reason": "tag_not_in_registry"}
    targets = index.get(registry.tags[tag], [])
    if not targets:
        return {**result, "status": "unmapped", "reason": "label_not_indexed_in_snapshot"}
    unavailable = [target for target in targets if target.get("_unavailable")]
    if unavailable:
        reason = ("source_has_parse_errors" if any(target["_unavailable"] == "source_has_parse_errors"
                                                  for target in unavailable) else "alias_source_not_recorded")
        return {**result, "status": "unmapped", "reason": reason,
                "diagnostic_sources": sorted({path for target in unavailable
                                               for path in target["_diagnostic_sources"]})}
    if len(targets) > 1:
        return {**result, "status": "ambiguous", "reason": "multiple_snapshot_targets",
                "candidate_count": len(targets),
                "candidates": deepcopy(targets[:MAX_AMBIGUOUS_CANDIDATES]),
                "candidates_omitted": max(0, len(targets) - MAX_AMBIGUOUS_CANDIDATES)}
    return {**result, "status": "mapped", **deepcopy(targets[0])}


def _prepare(store: ProjectStore, registry: str | Path, snapshot: str | None) -> tuple[dict, _Registry, dict]:
    records = _read_registry(registry)
    selected, data, current = _selected_snapshot(store, snapshot)
    envelope = {"schema_version": 1, "adapter": "stacks-tags-v1", "snapshot": selected,
                "current_snapshot": current, "source_basis": "selected_snapshot",
                "registry": records.metadata,
                "provenance": {"registry_origin": "caller_supplied_local_file",
                               "same_upstream_revision_verified": False,
                               "mathematical_review_performed": False}}
    return envelope, records, _index(data)


def lookup_tags(store: ProjectStore, registry: str | Path, tags: str | Iterable[str], *,
                snapshot: str | None = None) -> dict:
    """Resolve at most 256 external tags, preserving request order.

    Each successful row binds a tag to an existing local item revision in one
    recorded snapshot.  A nonprimary label retains ``target_clause`` and the
    owning item's archived span; no narrower clause span is invented.  Missing
    and ambiguous mappings are ordinary explicit result rows.  Invalid input,
    conflicting registry records, and broken snapshot integrity raise
    ``ProjectError``.  No project or registry file is written.
    """
    try:
        requested = [tags] if isinstance(tags, str) else list(islice(iter(tags), MAX_LOOKUP_TAGS + 1))
    except TypeError as exc:
        raise ProjectError("Provide one or more Stacks Tags") from exc
    if not requested or len(requested) > MAX_LOOKUP_TAGS:
        raise ProjectError(f"Provide between 1 and {MAX_LOOKUP_TAGS} Stacks Tags per lookup")
    requested = [_valid_tag(tag) for tag in requested]
    envelope, records, index = _prepare(store, registry, snapshot)
    results = [_result(tag, records, index, envelope["snapshot"]) for tag in requested]
    return {**envelope, "results": results}


def audit_tags(store: ProjectStore, registry: str | Path, *, snapshot: str | None = None,
               diagnostic_limit: int = 100) -> dict:
    """Count every registry mapping and retain bounded unresolved examples.

    This is a navigation census, not a mathematical review or a claim that
    the registry and local source were taken from the same upstream commit.
    """
    if (not isinstance(diagnostic_limit, int) or isinstance(diagnostic_limit, bool)
            or not 0 <= diagnostic_limit <= MAX_AUDIT_DIAGNOSTICS):
        raise ProjectError(f"Audit diagnostic limit must be an integer from 0 to {MAX_AUDIT_DIAGNOSTICS}")
    envelope, records, index = _prepare(store, registry, snapshot)
    statuses, kinds, scopes, reasons, source_codes = Counter(), Counter(), Counter(), Counter(), Counter()
    mapped_with_diagnostics = 0
    diagnostics, diagnostic_count = [], 0
    for tag in sorted(records.tags):
        result = _result(tag, records, index, envelope["snapshot"])
        statuses[result["status"]] += 1
        if result["status"] == "mapped":
            kinds[result["kind"]] += 1
            scopes[result["target_scope"]] += 1
            if result.get("source_diagnostics"):
                mapped_with_diagnostics += 1
                source_codes.update({diagnostic["code"] for diagnostic in result["source_diagnostics"]})
        else:
            reasons[result["reason"]] += 1
            diagnostic_count += 1
            if len(diagnostics) < diagnostic_limit:
                diagnostics.append(result)
    return {**envelope, "total_tags": len(records.tags),
            "counts": {key: statuses[key] for key in ("mapped", "unmapped", "ambiguous")},
            "mapped_by_kind": dict(sorted(kinds.items())),
            "mapped_by_target_scope": dict(sorted(scopes.items())),
            "mapped_with_source_diagnostics": mapped_with_diagnostics,
            "mapped_by_source_diagnostic_code": dict(sorted(source_codes.items())),
            "unresolved_by_reason": dict(sorted(reasons.items())),
            "diagnostics": diagnostics, "diagnostic_limit": diagnostic_limit,
            "diagnostics_omitted": diagnostic_count - len(diagnostics)}
