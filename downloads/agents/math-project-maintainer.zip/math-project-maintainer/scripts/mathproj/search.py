"""Snapshot-bound retrieval with a disposable SQLite FTS5 index.

The authoritative text is always read from an integrity-checked snapshot.
The cache can be deleted, is never written into the event log, and is checked
against the snapshot before use.  Search is lexical retrieval, not a decision
about mathematical equivalence, applicability, or correctness.

Ordinary terms are ANDed as quoted FTS literals.  TeX control sequences also
receive case-preserving encoded tokens, so ``\\Gamma`` and ``\\gamma`` differ.
The ``exact`` mode searches a case-sensitive literal substring, including
formula punctuation; it does not evaluate regular expressions or TeX.
"""

from __future__ import annotations

from contextlib import closing
from copy import deepcopy
from dataclasses import dataclass
from fnmatch import fnmatchcase
from itertools import zip_longest
import os
from pathlib import Path
import re
import sqlite3
import tempfile
from typing import Iterable

from .store import ProjectError, ProjectStore, digest


INDEX_VERSION = 1
_TOKEN_RE = re.compile(r"\\(?:[A-Za-z@]+|[^\s])|[^\W_]+", re.UNICODE)
_COMMAND_RE = re.compile(r"\\(?:[A-Za-z@]+|[^\s])")
_ROW_FIELDS = ("doc_key", "item_id", "evidence_id", "part", "kind", "path",
               "title", "labels", "body", "math")
_ROW_COLUMNS = ", ".join(_ROW_FIELDS)
_PART_ORDER = {"statement": 0, "proof": 1, "context": 2}


@dataclass
class _Snapshot:
    id: str
    data: dict
    current: bool


def _selected_snapshot(store: ProjectStore, snapshot: str | None) -> _Snapshot:
    if snapshot is not None and not isinstance(snapshot, str):
        raise ProjectError("Snapshot selection must be a complete snapshot ID or 'current'")
    state = store.state()
    selected = state.get("current_snapshot") if snapshot in {None, "current"} else snapshot
    if not isinstance(selected, str) or not re.fullmatch(r"[0-9a-f]{64}", selected):
        raise ProjectError("Select a complete snapshot ID, or import the current project first")
    if selected not in state.get("snapshot_history", []):
        raise ProjectError(f"Snapshot {selected} is not in the recorded project history")
    value = store.snapshot(selected)
    for field in ("items", "proofs", "contexts"):
        if not isinstance(value.get(field), dict):
            raise ProjectError(f"Snapshot {selected} has no valid {field} collection")
    return _Snapshot(selected, value, selected == state.get("current_snapshot"))


def _math_tokens(text: str) -> str:
    return " ".join(sorted({"zztex" + m.group(0)[1:].encode("utf-8").hex()
                            for m in _COMMAND_RE.finditer(text)}))


def _plain_terms(query: str) -> list[tuple[str, str]]:
    """Return literal MATCH expressions with their original spelling."""
    terms, seen = [], set()
    for match in _TOKEN_RE.finditer(query):
        value = match.group(0)
        if value.startswith("\\"):
            token = "zztex" + value[1:].encode("utf-8").hex()
            expression, key = 'math:"' + token + '"', token
        else:
            # The lexer discards punctuation; quoting also prevents OR, NOT,
            # NEAR, column selectors, stars, and quotes from becoming syntax.
            expression, key = '"' + value.replace('"', '""') + '"', value.casefold()
        if key not in seen:
            terms.append((expression, value))
            seen.add(key)
    if len(terms) > 256:
        raise ProjectError("Use at most 256 lexical search terms, or use exact literal search")
    return terms


def _proofs_for(snapshot: dict, item: dict) -> list[dict]:
    proofs = []
    seen = set()
    for proof_id in item.get("proof_ids", []):
        if proof_id in seen:
            continue
        seen.add(proof_id)
        proof = snapshot["proofs"].get(proof_id)
        if proof and proof.get("active", True):
            if proof.get("conclusion") != item["id"]:
                raise ProjectError(f"Proof {proof_id} has a different conclusion in the snapshot")
            proofs.append(proof)
    return proofs


def _documents(selected: _Snapshot) -> list[dict]:
    documents = []
    snapshot = selected.data
    for item_id, item in sorted(snapshot["items"].items()):
        if item.get("lifecycle", "active") != "active":
            continue
        source = item.get("source", {})
        labels = " ".join(dict.fromkeys(str(x) for x in
                           [item_id, item.get("label"), item.get("source_key"), *item.get("label_aliases", [])] if x))
        common = {"item_id": item_id, "item": item, "kind": item["kind"],
                  "path": source.get("path", ""), "title": item.get("title", ""),
                  "labels": labels, "item_revision": item["revision"]}

        def add(part, evidence_id, revision, body, evidence_source, context=None):
            if not isinstance(body, str):
                raise ProjectError(f"Snapshot evidence {evidence_id} is not text")
            key = digest([item_id, part, evidence_id, revision])
            doc = {**common, "doc_key": key, "evidence_id": evidence_id,
                   "revision": revision, "part": part, "body": body,
                   "source": evidence_source, "context": context}
            if context:
                doc["labels"] += " " + context["key"]
            doc["math"] = _math_tokens(doc["title"] + "\n" + doc["labels"] + "\n" + body)
            documents.append(doc)

        add("statement", item_id + ":statement", item["revision"], item["statement"], source)
        for proof in _proofs_for(snapshot, item):
            add("proof", proof["id"], proof["revision"], proof["text"], proof.get("source", source))
        # Only explicitly bound contexts are applicable.  Section titles do
        # not silently turn nearby prose into a hypothesis.
        seen_contexts = set()
        for context in item.get("contexts", []):
            key = (context["key"], context["revision"])
            if key in seen_contexts:
                continue
            seen_contexts.add(key)
            add("context", "context:" + context["key"], context["revision"],
                context["text"], None, context)
    documents.sort(key=lambda doc: doc["doc_key"])
    return documents


def _cache_path(store: ProjectStore, snapshot_id: str) -> Path:
    directory = store.meta / "search"
    if directory.is_symlink():
        raise ProjectError("Search cache directory must not be a symlink")
    if directory.exists() and not directory.is_dir():
        raise ProjectError("Search cache location is not a directory")
    directory.mkdir(exist_ok=True)
    path = directory / (snapshot_id + ".sqlite3")
    if path.is_symlink():
        raise ProjectError("Search index must not be a symlink")
    if path.exists() and not path.is_file():
        raise ProjectError("Search index location is not a regular file")
    return path


def _connect(path: Path, *, readonly=False) -> sqlite3.Connection:
    connection = sqlite3.connect(path.as_uri() + "?mode=ro" if readonly else str(path),
                                 uri=readonly, timeout=5)
    connection.execute("PRAGMA trusted_schema=OFF")
    return connection


def _valid_cache(path: Path, metadata: dict[str, str], rows: list[tuple]) -> bool:
    if not path.exists():
        return False
    try:
        with closing(_connect(path)) as connection:
            if connection.execute("PRAGMA user_version").fetchone()[0] != INDEX_VERSION:
                return False
            if dict(connection.execute("SELECT key, value FROM metadata")) != metadata:
                return False
            actual = connection.execute("SELECT " + _ROW_COLUMNS + " FROM documents ORDER BY doc_key")
            if any(found != expected for found, expected in zip_longest(actual, rows)):
                return False
            # The rank=1 option checks the external-content FTS index against
            # its documents table, including missing or altered postings.
            connection.execute("INSERT INTO search_fts(search_fts, rank) VALUES ('integrity-check', 1)")
            return True
    except (sqlite3.DatabaseError, OSError):
        return False


def _write_cache(path: Path, metadata: dict[str, str], rows: list[tuple]) -> None:
    descriptor, name = tempfile.mkstemp(prefix=".building-search-", suffix=".sqlite3", dir=path.parent)
    os.close(descriptor)
    temporary = Path(name)
    try:
        with closing(_connect(temporary)) as connection:
            connection.execute("PRAGMA journal_mode=DELETE")
            connection.execute("PRAGMA synchronous=FULL")
            connection.execute("PRAGMA user_version=" + str(INDEX_VERSION))
            connection.execute("CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT NOT NULL)")
            definitions = [field + " TEXT NOT NULL" + (" UNIQUE" if field == "doc_key" else "") for field in _ROW_FIELDS]
            connection.execute("CREATE TABLE documents(" + ", ".join(definitions) + ")")
            connection.execute("CREATE INDEX documents_item ON documents(item_id, part)")
            connection.execute("CREATE VIRTUAL TABLE search_fts USING fts5("
                               "title, labels, body, math, content='documents', content_rowid='rowid', "
                               "tokenize='unicode61 remove_diacritics 0')")
            connection.executemany("INSERT INTO metadata(key,value) VALUES (?,?)", sorted(metadata.items()))
            connection.executemany("INSERT INTO documents(" + _ROW_COLUMNS + ") VALUES (" +
                                   ",".join("?" for _ in _ROW_FIELDS) + ")", rows)
            connection.execute("INSERT INTO search_fts(search_fts) VALUES ('rebuild')")
            connection.execute("INSERT INTO search_fts(search_fts,rank) VALUES ('integrity-check',1)")
            connection.commit()
        with temporary.open("rb") as handle:
            os.fsync(handle.fileno())
        if path.is_symlink():
            raise ProjectError("Search index became a symlink during rebuilding")
        os.replace(temporary, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    except sqlite3.DatabaseError as exc:
        raise ProjectError(f"Cannot build the disposable SQLite FTS5 index: {exc}") from exc
    except OSError as exc:
        raise ProjectError(f"Cannot save the disposable search index: {exc}") from exc
    finally:
        for suffix in ("", "-journal", "-wal", "-shm"):
            candidate = Path(str(temporary) + suffix)
            if candidate.exists():
                candidate.unlink()


def _ensure_index(store: ProjectStore, selected: _Snapshot, documents: list[dict], force=False) -> dict:
    rows = [tuple(doc[field] for field in _ROW_FIELDS) for doc in documents]
    metadata = {"snapshot": selected.id, "version": str(INDEX_VERSION),
                "documents": str(len(rows)), "documents_digest": digest(rows)}
    # A cache for each immutable snapshot avoids a reader switching snapshots
    # while another query rebuilds the current index.  Atomic replacement also
    # lets an already-open reader finish against the old inode.
    with store.locked():
        path = _cache_path(store, selected.id)
        rebuilt = bool(force or not _valid_cache(path, metadata, rows))
        if rebuilt:
            _write_cache(path, metadata, rows)
    return {"path": path.relative_to(store.root).as_posix(), "snapshot": selected.id,
            "version": INDEX_VERSION, "documents": len(rows), "rebuilt": rebuilt,
            "authoritative": False}


def rebuild_index(store: ProjectStore, *, snapshot: str | None = None, force: bool = False) -> dict:
    """Validate or atomically rebuild the selected snapshot's disposable cache."""
    selected = _selected_snapshot(store, snapshot)
    return _ensure_index(store, selected, _documents(selected), force)


def _excerpt(text: str, needles: Iterable[str], maximum: int = 600, *, case_sensitive=False) -> tuple[str, dict]:
    positions = []
    for needle in needles:
        if not needle:
            continue
        # Offset searches use the original string: casefold can change length.
        match = re.search(re.escape(needle), text, 0 if case_sensitive or needle.startswith("\\") else re.IGNORECASE)
        if match:
            positions.append(match.start())
    focus = min(positions, default=0)
    start = max(0, focus - maximum // 4)
    end = min(len(text), start + maximum)
    if end == len(text):
        start = max(0, end - maximum)
    return text[start:end], {"start_char": start, "end_char": end, "total_chars": len(text),
                             "complete": start == 0 and end == len(text)}


def _evidence(doc: dict, selected: _Snapshot, needles: list[str], rank: float | None, *, exact=False) -> dict:
    item = doc["item"]
    excerpt, extent = _excerpt(doc["body"], needles, case_sensitive=exact)
    statement, statement_extent = _excerpt(item["statement"], needles, case_sensitive=exact)
    result = {"id": doc["item_id"], "evidence_id": doc["evidence_id"], "revision": doc["revision"],
              "item_revision": item["revision"], "declaration_revision": item.get("declaration_revision"),
              "snapshot": selected.id, "part": doc["part"], "kind": doc["kind"],
              "label": item.get("label"), "title": item.get("title", ""),
              "source": deepcopy(doc["source"]), "item_source": deepcopy(item.get("source")),
              "section": list(item.get("section", [])), "excerpt": excerpt, "excerpt_range": extent,
              "statement_excerpt": statement, "statement_excerpt_range": statement_extent,
              "rank": rank}
    if doc["context"]:
        result["context"] = {"key": doc["context"]["key"], "revision": doc["context"]["revision"]}
        result["source_kind"] = "explicit_context_binding"
    else:
        result["source_kind"] = "snapshot_source_span"
    return result


def search(store: ProjectStore, query: str, *, snapshot: str | None = None,
           kind: str | None = None, path: str | None = None, limit: int = 20,
           exact: bool = False) -> dict:
    """Search exact snapshot evidence; ``path`` is a case-sensitive POSIX glob.

    A permanent item ID or proof ID is resolved directly. Other ordinary
    queries are literal AND terms, while ``exact=True`` preserves all query
    punctuation and case. Hit text and revisions come from the snapshot,
    never from cached SQLite text.
    """
    if not isinstance(query, str) or not query.strip() or "\x00" in query:
        raise ProjectError("A nonempty search string without NUL characters is required")
    if not isinstance(limit, int) or isinstance(limit, bool) or limit < 1:
        raise ProjectError("Search limit must be a positive integer")
    for label, value in (("kind", kind), ("path", path)):
        if value is not None and (not isinstance(value, str) or not value or "\x00" in value):
            raise ProjectError(f"Search {label} filter must be a nonempty string")
    selected = _selected_snapshot(store, snapshot)
    documents = _documents(selected)
    index = _ensure_index(store, selected, documents)
    by_key = {doc["doc_key"]: doc for doc in documents}
    reference = query.strip()
    direct = [doc for doc in documents if
              (doc["part"] == "statement" and doc["item_id"] == reference) or
              (doc["part"] == "proof" and doc["evidence_id"] == reference)]
    diagnostics = []
    if direct:
        direct = [doc for doc in direct if (kind is None or doc["kind"] == kind)
                  and (path is None or fnmatchcase(doc["path"], path))]
        direct.sort(key=lambda doc: (doc["item_id"], _PART_ORDER[doc["part"]], doc["evidence_id"]))
        total, mode = len(direct), "id"
        results = [_evidence(doc, selected, [reference], None) for doc in direct[:limit]]
    else:
        terms = [] if exact else _plain_terms(query)
        mode = "exact" if exact else "terms"
        needles = [query] if exact else [value for _, value in terms]
        filters, arguments = [], []
        if kind is not None:
            filters.append("d.kind = ?")
            arguments.append(kind)
        if path is not None:
            # Match the Python fnmatchcase interpretation, including slash
            # characters. Parameters are values, never interpolated SQL.
            filters.append("path_matches(?, d.path)")
            arguments.append(path)
        if exact:
            condition = "(instr(d.title, ?) > 0 OR instr(d.labels, ?) > 0 OR instr(d.body, ?) > 0)"
            arguments = [query, query, query] + arguments
            table = "documents d"
            ranking = "0.0"
        elif terms:
            condition = "search_fts MATCH ?"
            arguments = [" AND ".join(expression for expression, _ in terms)] + arguments
            table = "search_fts JOIN documents d ON d.rowid = search_fts.rowid"
            ranking = "bm25(search_fts,4.0,3.0,1.0,1.0)"
        else:
            condition, table, ranking = "0", "documents d", "0.0"
            diagnostics.append({"code": "no_searchable_terms", "severity": "info",
                                "message": "This query has no lexical terms; use exact literal search for formula punctuation."})
        where = " WHERE " + " AND ".join([condition, *filters])
        with closing(_connect(store.root / index["path"], readonly=True)) as connection:
            connection.create_function("path_matches", 2, lambda pattern, candidate: int(fnmatchcase(candidate, pattern)), deterministic=True)
            total = connection.execute("SELECT count(*) FROM " + table + where, arguments).fetchone()[0]
            rows = connection.execute("SELECT d.doc_key, " + ranking + " AS score FROM " + table + where +
                                      " ORDER BY score, d.item_id, CASE d.part WHEN 'statement' THEN 0 WHEN 'proof' THEN 1 ELSE 2 END, d.evidence_id, d.doc_key LIMIT ?",
                                      [*arguments, limit]).fetchall()
        results = [_evidence(by_key[key], selected, needles, score, exact=exact) for key, score in rows]
    return {"query": query, "snapshot": selected.id, "current_snapshot": selected.current,
            "mode": mode, "filters": {"kind": kind, "path": path}, "limit": limit,
            "total": total, "truncated": total > len(results), "results": results,
            "index": index, "diagnostics": diagnostics,
            "meaning": "Lexical matches in the selected imported snapshot; applicability requires mathematical review."}


def _snapshot_names(snapshot: dict) -> dict[str, set[str]]:
    names: dict[str, set[str]] = {}
    for item_id, item in snapshot["items"].items():
        aliases = [item.get("label"), *item.get("label_aliases", [])]
        path = Path(item.get("source", {}).get("path", ""))
        prefixes = {path.stem, path.with_suffix("").as_posix().replace("/", "-")} if path.name else set()
        expanded = [prefix + "-" + label for prefix in prefixes for label in aliases if label]
        for name in [item_id, item.get("source_key"), *aliases, *expanded]:
            if name:
                names.setdefault(name, set()).add(item_id)
    return names


def context_packet(store: ProjectStore, refs: Iterable[str], *, snapshot: str | None = None,
                   max_items: int = 40, max_chars: int = 30000) -> dict:
    """Collect requested proofs, direct dependency statements, and bound context.

    ``max_items`` counts mathematical objects; ``max_chars`` counts included
    text characters, excluding identifying metadata and omission records.
    Text truncation is always accompanied by its exact omitted extent. This
    packet does not claim to contain a transitive support closure. Dependencies
    from parsed references remain candidates, not accepted applications.
    """
    for name, value in (("max_items", max_items), ("max_chars", max_chars)):
        if not isinstance(value, int) or isinstance(value, bool) or value < 0:
            raise ProjectError(f"{name} must be a nonnegative integer")
    if isinstance(refs, str):
        refs = [refs]
    try:
        requested = list(refs)
    except TypeError as exc:
        raise ProjectError("Context references must be an iterable of item or proof identifiers") from exc
    if not requested or any(not isinstance(ref, str) or not ref.strip() for ref in requested):
        raise ProjectError("Supply at least one nonempty item or proof reference")
    selected = _selected_snapshot(store, snapshot)
    data, names = selected.data, _snapshot_names(selected.data)
    omissions, roots, selections = [], [], {}
    proofs_by_item: dict[str, list[dict]] = {}

    def item_proofs(item_id):
        if item_id not in proofs_by_item:
            proofs_by_item[item_id] = _proofs_for(data, data["items"][item_id])
        return proofs_by_item[item_id]

    for reference in requested:
        reference = reference.strip()
        proof = data["proofs"].get(reference)
        if reference in data["items"]:
            candidates = {reference}
            proof = None
        elif proof and proof.get("active", True):
            candidates = {proof["conclusion"]}
        else:
            candidates = names.get(reference, set())
            proof = None
        candidates = {candidate for candidate in candidates if candidate in data["items"]}
        if len(candidates) != 1:
            omissions.append({"reference": reference, "reason": "ambiguous_reference" if candidates else "unknown_reference",
                              "candidates": sorted(candidates)})
            continue
        item_id = next(iter(candidates))
        if item_id not in selections:
            roots.append(item_id)
            selections[item_id] = set()
        if proof:
            selections[item_id].add(proof["id"])
        else:
            selections[item_id].update(p["id"] for p in item_proofs(item_id))

    edges, dependencies = [], set()
    edge_keys = set()

    def add_reference(consumer, subject, reference, relation):
        target = reference.get("target_id")
        key = (consumer, subject, target, reference.get("label"), reference.get("target_clause"), relation)
        if key in edge_keys:
            return
        edge_keys.add(key)
        edge = {"consumer": consumer, "subject": subject, "target_id": target,
                "reference_label": reference.get("label"), "target_clause": reference.get("target_clause"),
                "relation": relation, "source_line": reference.get("line")}
        edges.append(edge)
        if target not in data["items"]:
            omissions.append({"reason": "dependency_not_in_snapshot" if target else "unresolved_reference",
                              "consumer": consumer, "subject": subject, "target_id": target,
                              "reference_label": reference.get("label")})
        elif target not in selections:
            dependencies.add(target)

    for item_id in roots:
        item = data["items"][item_id]
        for reference in item.get("statement_references", []):
            add_reference(item_id, item_id + ":statement", reference, "candidate_reference")
        for proof in item_proofs(item_id):
            if proof["id"] not in selections[item_id]:
                continue
            for reference in proof.get("references", []):
                add_reference(item_id, proof["id"], reference, "candidate_reference")
            for target in proof.get("declared_dependencies", []):
                add_reference(item_id, proof["id"], {"target_id": target, "label": target}, "declared_dependency")

    candidates = roots + sorted(dependencies)
    chosen = candidates[:max_items]
    chosen_set = set(chosen)
    for item_id in candidates[max_items:]:
        omissions.append({"reason": "max_items", "id": item_id,
                          "requested": item_id in selections})
    for edge in edges:
        edge["included"] = edge["target_id"] in chosen_set
    remaining = max_chars
    used = 0

    def evidence(item_id, evidence_id, revision, part, text, source):
        nonlocal remaining, used
        length = min(len(text), remaining)
        remaining -= length
        used += length
        complete = length == len(text)
        if not complete:
            omissions.append({"reason": "max_chars", "id": item_id, "evidence_id": evidence_id,
                              "part": part, "omitted_start_char": length, "omitted_end_char": len(text),
                              "omitted_chars": len(text) - length})
        return {"id": evidence_id, "item_id": item_id, "revision": revision,
                "snapshot": selected.id, "part": part, "text": text[:length],
                "source": deepcopy(source), "complete": complete, "total_chars": len(text),
                "included_chars": length}

    output = []
    output_by_id = {}
    context_bindings: dict[tuple[str, str], dict] = {}
    for item_id in chosen:
        item = data["items"][item_id]
        value = {"id": item_id, "revision": item["revision"], "declaration_revision": item.get("declaration_revision"),
                 "kind": item["kind"], "label": item.get("label"), "title": item.get("title", ""),
                 "source": deepcopy(item.get("source")), "section": list(item.get("section", [])),
                 "selection": "requested" if item_id in selections else "direct_dependency",
                 "statement": evidence(item_id, item_id + ":statement", item["revision"], "statement", item["statement"], item.get("source")),
                 "proofs": [], "contexts": []}
        output.append(value)
        output_by_id[item_id] = value
        for context in item.get("contexts", []):
            key = (context["key"], context["revision"])
            if key not in context_bindings:
                context_bindings[key] = {"context": context, "applies_to": []}
            binding = context_bindings[key]
            if context["text"] != binding["context"]["text"]:
                raise ProjectError(f"Context {context['key']} has conflicting text at the same revision")
            binding["applies_to"].append(item_id)
            value["contexts"].append({"key": key[0], "revision": key[1]})

    contexts = []
    for key, binding in sorted(context_bindings.items()):
        context = binding["context"]
        value = evidence(None, "context:" + key[0], key[1], "context", context["text"], None)
        value.update(key=key[0], applies_to=binding["applies_to"], source_kind="explicit_context_binding")
        contexts.append(value)

    proof_total = 0
    for item_id in chosen:
        item = data["items"][item_id]
        proofs = item_proofs(item_id)
        if item_id not in selections:
            if proofs:
                omissions.append({"reason": "dependency_proofs_not_requested", "id": item_id,
                                  "proof_ids": [proof["id"] for proof in proofs]})
            continue
        omitted_alternatives = []
        for proof in proofs:
            if proof["id"] not in selections[item_id]:
                omitted_alternatives.append(proof["id"])
                continue
            proof_total += 1
            value = evidence(item_id, proof["id"], proof["revision"], "proof", proof["text"], proof.get("source", item.get("source")))
            value["references"] = deepcopy(proof.get("references", []))
            value["declared_dependencies"] = list(proof.get("declared_dependencies", []))
            output_by_id[item_id]["proofs"].append(value)
        if omitted_alternatives:
            omissions.append({"reason": "alternative_proofs_not_requested", "id": item_id, "proof_ids": omitted_alternatives})

    for item_id in sorted(dependencies & chosen_set):
        if data["items"][item_id].get("statement_references") or item_proofs(item_id):
            omissions.append({"reason": "dependency_not_expanded", "id": item_id,
                              "message": "The packet includes direct dependency statements and bound context, not their transitive support."})
    budget_omissions = [o for o in omissions if o["reason"] in {"max_items", "max_chars"}]
    incomplete = [o for o in omissions if o["reason"] not in
                  {"dependency_proofs_not_requested", "alternative_proofs_not_requested", "dependency_not_expanded"}]
    return {"snapshot": selected.id, "current_snapshot": selected.current, "requested": requested,
            "scope": {"dependency_depth": 1, "proofs": "requested items or explicitly selected proof IDs",
                      "contexts": "explicitly bound snapshot contexts", "character_budget": "text only; metadata and omissions are excluded"},
            "limits": {"max_items": max_items, "max_chars": max_chars},
            "counts": {"requested_items": len(roots), "candidate_items": len(candidates),
                       "included_items": len(output), "omitted_items": len(candidates) - len(output),
                       "included_proofs": proof_total, "included_contexts": len(contexts),
                       "included_chars": used},
            "items": output, "contexts": contexts, "dependencies": edges, "omissions": omissions,
            "complete": not omissions, "complete_within_scope": not incomplete,
            "truncated": bool(budget_omissions),
            "meaning": "Candidate references and declared dependencies are evidence for review, not verified mathematical applications."}
