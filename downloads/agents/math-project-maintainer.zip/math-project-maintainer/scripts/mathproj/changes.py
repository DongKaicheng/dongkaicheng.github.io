"""Reviewable source changes with exact baselines and crash recovery.

The language model supplies mathematical edits. This module makes the proposed
files, rationale, provenance and parse effects inspectable before application.
It never infers mathematical equivalence from textual similarity.
"""
from __future__ import annotations

from copy import deepcopy
import difflib
import hashlib
import os
from pathlib import Path
import tempfile

from .latex import parse_project
from .project import ingest, resolve_item
from .store import ProjectError, ProjectStore, atomic_json, contained, digest, read_json, utc_now
from .workflow import require_fresh


def _hash_bytes(value: bytes | None) -> str | None:
    return hashlib.sha256(value).hexdigest() if value is not None else None


def _atomic_bytes(path: Path, value: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.is_symlink():
        raise ProjectError(f"Source destination must not be a symlink: {path}")
    fd, name = tempfile.mkstemp(prefix=".mpm-edit-", dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as out:
            out.write(value)
            out.flush()
            os.fsync(out.fileno())
        os.replace(name, path)
        directory = os.open(path.parent, os.O_RDONLY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def _unlink_synced(path: Path) -> None:
    path.unlink()
    directory = os.open(path.parent, os.O_RDONLY)
    try:
        os.fsync(directory)
    finally:
        os.close(directory)


def _source_path(store: ProjectStore, value: str, manifest: dict) -> Path:
    if not isinstance(value, str) or not value or Path(value).is_absolute() or ".." in Path(value).parts:
        raise ProjectError("Source edits need project-relative paths without '..'")
    literal = store.root / value
    path = contained(store.root, value)
    if path.suffix != ".tex":
        raise ProjectError("Source proposals currently edit .tex files only")
    relative = path.relative_to(store.root).as_posix()
    if relative.startswith("mpm/") or path == store.manifest_path:
        raise ProjectError("Source proposals cannot edit project metadata")
    allowed = False
    for entry in manifest["entrypoints"]:
        entry_path = contained(store.root, entry)
        if not entry_path.suffix:
            entry_path = entry_path.with_suffix(".tex")
        if path == entry_path:
            allowed = True
    for folder in manifest["source_roots"]:
        base = contained(store.root, folder)
        if path == base or base in path.parents:
            allowed = True
    if not allowed:
        raise ProjectError(f"Source path is outside the declared roots and entrypoints: {value}")
    for parent in [literal, *literal.parents]:
        if parent == store.root:
            break
        if parent.is_symlink():
            raise ProjectError("Source edit paths must not traverse symlinks")
    if path.exists() and not path.is_file():
        raise ProjectError(f"Source edit is not a regular file: {value}")
    return path


def _pending_path(store: ProjectStore) -> Path:
    directory = store.meta / "changes"
    if directory.is_symlink():
        raise ProjectError("Change journal directory must not be a symlink")
    directory.mkdir(exist_ok=True)
    path = directory / "pending.json"
    if path.is_symlink():
        raise ProjectError("Change journal must not be a symlink")
    return path


def pending_change(store: ProjectStore) -> dict | None:
    path = store.meta / "changes" / "pending.json"
    if path.is_symlink() or path.parent.is_symlink():
        raise ProjectError("Source change journal paths must not be symlinks")
    if not path.exists():
        return None
    journal = read_json(_pending_path(store))
    if not isinstance(journal, dict) or journal.get("hash") != digest({k: v for k, v in journal.items() if k != "hash"}):
        raise ProjectError("Source change journal is corrupt; preserve it and restore authoritative records")
    if journal.get("schema_version") != 1 or journal.get("phase") not in {"prepared", "files_written"}:
        raise ProjectError("Unsupported source change journal schema or phase")
    if not isinstance(journal.get("proposal_id"), str) or not isinstance(journal.get("files"), list) or not journal["files"]:
        raise ProjectError("Malformed source change journal identity or files")
    return journal


def _check_baseline(store: ProjectStore, state: dict, proposal: dict) -> None:
    require_fresh(store, state)
    if state["current_snapshot"] != proposal["base_snapshot"]:
        raise ProjectError("Proposal baseline snapshot changed; prepare a new proposal against the current source")
    for edit in proposal["edits"]:
        path = _source_path(store, edit["path"], store.manifest())
        current = path.read_bytes() if path.exists() else None
        if _hash_bytes(current) != edit["before_sha256"]:
            raise ProjectError(f"Source changed since proposal preparation: {edit['path']}")


def _parse_effects(store: ProjectStore, snapshot: dict, edits: list[dict]) -> dict:
    manifest = snapshot["manifest"]
    with tempfile.TemporaryDirectory(prefix="math-project-proposal-") as temporary:
        staged = Path(temporary)
        for source in snapshot["files"]:
            destination = contained(staged, source["path"])
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_text(source["text"], encoding="utf-8")
        for edit in edits:
            destination = contained(staged, edit["path"])
            if edit["operation"] == "delete":
                if destination.exists():
                    destination.unlink()
            else:
                destination.parent.mkdir(parents=True, exist_ok=True)
                destination.write_text(edit["content"], encoding="utf-8")
        parsed = parse_project(staged, entrypoints=manifest["entrypoints"] or None,
                               source_roots=manifest["source_roots"])
    before = {v["source_key"]: v for v in snapshot["items"].values()}
    after = {v["key"]: v for v in parsed["items"]}
    effects = []
    for key in sorted(before.keys() | after.keys()):
        if key not in before:
            effects.append({"source_key": key, "effect": "added"})
        elif key not in after:
            effects.append({"source_key": key, "item_id": before[key]["id"], "effect": "removed_or_moved"})
        else:
            old, new = before[key], after[key]
            if old["statement"] != new["statement"] or old["kind"] != new["kind"]:
                effects.append({"source_key": key, "item_id": old["id"], "effect": "statement_text_changed"})
            old_proofs = [snapshot["proofs"][p]["text"] for p in old["proof_ids"] if p in snapshot["proofs"]]
            if old_proofs != [p["text"] for p in new.get("proofs", [])]:
                effects.append({"source_key": key, "item_id": old["id"], "effect": "proof_text_changed"})
    reachable = {f["path"] for f in parsed["files"]}
    diagnostics = deepcopy(parsed["diagnostics"])
    for edit in edits:
        if edit["operation"] != "delete" and edit["path"] not in reachable:
            diagnostics.append({"code": "unreachable_proposed_source", "severity": "error", "path": edit["path"], "line": 1,
                                "message": "The proposed file is not reachable from the selected source roots/entrypoints."})
    if not parsed["files"]:
        diagnostics.append({"code": "empty_proposed_project", "severity": "error", "path": "", "line": 0,
                            "message": "The proposal would leave no imported source files."})
    return {"effects": effects, "diagnostics": diagnostics, "items": len(parsed["items"]),
            "files": len(parsed["files"]), "structurally_valid": not any(d["severity"] == "error" for d in diagnostics),
            "meaning": "Textual and structural effects only; mathematical equivalence requires review."}


def create_proposal(store: ProjectStore, payload: dict) -> dict:
    if not isinstance(payload, dict):
        raise ProjectError("Proposal must be a JSON object")
    for field in ("title", "rationale", "author"):
        if not isinstance(payload.get(field), str) or not payload[field].strip():
            raise ProjectError(f"Proposal requires {field}")
    if not isinstance(payload.get("edits"), list) or not payload["edits"]:
        raise ProjectError("Proposal requires at least one source edit")
    def change(state):
        if pending_change(store):
            raise ProjectError("Recover the pending source change before preparing another proposal")
        require_fresh(store, state)
        if payload.get("base_snapshot") != state["current_snapshot"]:
            raise ProjectError("Proposal must name the exact current base_snapshot")
        manifest = store.manifest()
        seen, edits = set(), []
        for raw in payload["edits"]:
            if not isinstance(raw, dict):
                raise ProjectError("Each proposed edit must be an object")
            path = _source_path(store, raw.get("path"), manifest)
            rel = path.relative_to(store.root).as_posix()
            if rel in seen:
                raise ProjectError(f"Duplicate proposed source path: {rel}")
            seen.add(rel)
            old = path.read_bytes() if path.exists() else None
            before = _hash_bytes(old)
            if "before_sha256" not in raw or raw["before_sha256"] != before:
                raise ProjectError(f"Edit must supply the exact before_sha256 (null for new files): {rel}")
            operation = raw.get("operation", "write")
            if operation not in {"write", "delete"}:
                raise ProjectError("Edit operation must be write or delete")
            if operation == "delete" and old is None:
                raise ProjectError(f"Cannot delete a nonexistent source: {rel}")
            if operation == "write" and not isinstance(raw.get("content"), str):
                raise ProjectError("A write edit requires complete UTF-8 content")
            content = raw.get("content") if operation == "write" else None
            after = _hash_bytes(content.encode("utf-8")) if content is not None else None
            if before == after:
                raise ProjectError(f"Proposed edit makes no change: {rel}")
            old_text = old.decode("utf-8") if old is not None else ""
            diff = "".join(difflib.unified_diff(old_text.splitlines(keepends=True), (content or "").splitlines(keepends=True),
                                              fromfile="before/"+rel, tofile="after/"+rel))
            edits.append({"path": rel, "operation": operation, "before_sha256": before,
                          "after_sha256": after, "content": content, "diff": diff})
        target_ids = [resolve_item(state, x, active=False) for x in payload.get("targets", [])]
        analysis = _parse_effects(store, store.snapshot(state["current_snapshot"]), edits)
        at = utc_now()
        entry = {"title": payload["title"], "rationale": payload["rationale"], "author": payload["author"],
                 "base_snapshot": state["current_snapshot"], "targets": target_ids,
                 "intent": payload.get("intent", ""), "edits": edits, "analysis": analysis,
                 "status": "prepared", "created_at": at}
        proposal_id = "change-"+digest(entry)[:24]
        entry["id"] = proposal_id
        state["proposals"][proposal_id] = entry
        return {"proposal": entry, "next": "Inspect the diff and structural effects, then apply the proposal. Mathematical review remains required."}
    return store.transact("prepare_source_change", change)


def inspect_proposal(store: ProjectStore, proposal_id: str) -> dict:
    state = store.state()
    entry = state["proposals"].get(proposal_id)
    if not entry:
        raise ProjectError(f"Unknown source proposal: {proposal_id}")
    return deepcopy(entry)


def _journal_write(path: Path, value: dict) -> None:
    payload = {k: v for k, v in value.items() if k != "hash"}
    atomic_json(path, {**payload, "hash": digest(payload)})


def _restore_uncommitted(store: ProjectStore, journal: dict) -> dict:
    """Restore only known old/new bytes; never overwrite an unrelated edit."""
    manifest = store.manifest()
    paths = []
    for row in journal["files"]:
        path = _source_path(store, row["path"], manifest)
        actual = _hash_bytes(path.read_bytes() if path.exists() else None)
        if actual not in {row["before_sha256"], row["after_sha256"]}:
            raise ProjectError(f"Recovery found an unrelated edit at {row['path']}; preserve all versions and resolve it explicitly")
        paths.append((path, row))
    for path, row in paths:
        if row["before_text"] is None:
            if path.exists():
                _unlink_synced(path)
        else:
            _atomic_bytes(path, row["before_text"].encode("utf-8"))
    return {"restored": [row["path"] for _, row in paths]}


def _validate_journal(store: ProjectStore, journal: dict, proposal: dict) -> None:
    """The ledger proposal is authoritative; a valid envelope hash is insufficient."""
    expected = {e["path"]: e for e in proposal["edits"]}
    seen = set()
    required = {"path", "before_text", "before_sha256", "after_sha256"}
    for row in journal["files"]:
        if not isinstance(row, dict) or set(row) != required or not isinstance(row.get("path"), str):
            raise ProjectError("Malformed source change journal file record")
        path = row["path"]
        if path not in expected or path in seen:
            raise ProjectError("Source change journal files differ from the authoritative proposal")
        seen.add(path)
        edit = expected[path]
        if any(row[f] != edit[f] for f in ("before_sha256", "after_sha256")):
            raise ProjectError("Source change journal hashes differ from the authoritative proposal")
        before = row["before_text"]
        if before is not None and not isinstance(before, str):
            raise ProjectError("Source change journal backup must be UTF-8 text or null")
        actual_hash = _hash_bytes(before.encode("utf-8") if before is not None else None)
        if actual_hash != edit["before_sha256"]:
            raise ProjectError("Source change journal backup does not match the authoritative source hash")
        after = edit["content"] if edit["operation"] == "write" else None
        if _hash_bytes(after.encode("utf-8") if after is not None else None) != edit["after_sha256"]:
            raise ProjectError("Authoritative proposal content integrity failed")
        _source_path(store, path, store.manifest())
    if seen != set(expected):
        raise ProjectError("Source change journal omits files from the authoritative proposal")


def recover_changes(store: ProjectStore) -> dict:
    with store.locked():
        journal = pending_change(store)
        if journal is None:
            return {"pending": False, "recovered": False}
        state, _ = store.replay()
        proposal = state["proposals"].get(journal.get("proposal_id"))
        if not proposal:
            raise ProjectError("Pending source journal refers to an unknown proposal")
        _validate_journal(store, journal, proposal)
        if proposal["status"] == "applied":
            for row in journal["files"]:
                path = _source_path(store, row["path"], store.manifest())
                if _hash_bytes(path.read_bytes() if path.exists() else None) != row["after_sha256"]:
                    raise ProjectError("Committed source change differs from the pending journal; preserve versions for explicit recovery")
            result = {"committed": True, "restored": []}
        else:
            result = {"committed": False, **_restore_uncommitted(store, journal)}
        _unlink_synced(_pending_path(store))
        return {"pending": False, "recovered": True, "proposal_id": journal["proposal_id"], **result}


def apply_proposal(store: ProjectStore, proposal_id: str, *, import_after: bool = True) -> dict:
    def change(state):
        if pending_change(store):
            raise ProjectError("A source change was interrupted; run change recover before applying another")
        proposal = state["proposals"].get(proposal_id)
        if not proposal or proposal["status"] != "prepared":
            raise ProjectError("Only a prepared source proposal can be applied")
        _check_baseline(store, state, proposal)
        if not proposal["analysis"]["structurally_valid"]:
            raise ProjectError("Proposal has structural errors; prepare a corrected proposal")
        journal = {"schema_version": 1, "proposal_id": proposal_id, "phase": "prepared", "files": []}
        for edit in proposal["edits"]:
            path = _source_path(store, edit["path"], store.manifest())
            old = path.read_bytes() if path.exists() else None
            journal["files"].append({"path": edit["path"], "before_text": old.decode("utf-8") if old is not None else None,
                                     "before_sha256": edit["before_sha256"], "after_sha256": edit["after_sha256"]})
        journal_path = _pending_path(store)
        _journal_write(journal_path, journal)
        try:
            for edit in proposal["edits"]:
                path = _source_path(store, edit["path"], store.manifest())
                if edit["operation"] == "delete":
                    _unlink_synced(path)
                else:
                    _atomic_bytes(path, edit["content"].encode("utf-8"))
            journal["phase"] = "files_written"
            _journal_write(journal_path, journal)
        except BaseException:
            _restore_uncommitted(store, journal)
            _unlink_synced(journal_path)
            raise
        proposal.update(status="applied", applied_at=utc_now())
        return {"proposal_id": proposal_id, "status": "applied", "paths": [e["path"] for e in proposal["edits"]]}
    try:
        result = store.transact("apply_source_change", change, details={"proposal_id": proposal_id})
    except BaseException:
        # Distinguish a failure before ledger commit from a failed disposable
        # cache write after commit. The journal makes either case recoverable.
        if pending_change(store):
            recover_changes(store)
        raise
    recovery = recover_changes(store)
    result["journal_finalized"] = recovery.get("committed", False)
    if import_after:
        result["import"] = ingest(store)
    return result
