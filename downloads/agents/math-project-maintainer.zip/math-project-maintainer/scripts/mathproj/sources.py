"""Version-bound bibliographic evidence, recorded without fetching or certifying it.

A checked record is a named reviewer's assertion that the specified material was
inspected. The module validates metadata and bindings; it neither fetches a URI
nor decides the truth of an external theorem. Source text is inert data, including
when it contains TeX, HTML, shell syntax, or instructions addressed to a reader.

Source keys and citation keys are identifiers, never filesystem paths. Updates
use optimistic revision checks and retain the previous records in the event log.
Snapshots/releases must copy both source_records and citations. A missing citation
does not establish that a proof's bibliography is complete.
"""

from __future__ import annotations

from copy import deepcopy
from datetime import date, datetime
import hashlib
import ipaddress
import re
from urllib.parse import unquote, urlsplit

from .project import NAVIGATION, resolve_item
from .store import ProjectError, ProjectStore, digest, utc_now, valid_name


SOURCE_FIELDS = {"title", "uri", "version", "content_sha256", "status", "checked_by",
                 "accessed_at", "authors", "year", "publisher", "notes", "previous_revision"}
CITATION_FIELDS = {"citation_key", "source_revision", "declaration_revision", "proof_id",
                   "proof_revision", "status", "locator", "supporting_statement", "assumptions",
                   "no_assumptions", "substitution", "conclusion", "justification", "inspected_text",
                   "evidence_sha256", "checked_by", "accessed_at", "previous_revision", "reference_ids"}
LOCATORS = {"theorem", "page", "section", "chapter", "tag", "equation", "paragraph",
            "appendix", "url_fragment"}
UNKNOWN = {"", "unknown", "unverified", "not checked", "none", "n/a", "unspecified"}
MUTABLE_VERSION = UNKNOWN | {"latest", "current", "main", "master", "head"}
SHA256 = re.compile(r"[0-9a-f]{64}")


def _text(value, field, *, required=False, maximum=65536, preserve=False):
    if value is None and not required:
        return None
    if not isinstance(value, str) or len(value) > maximum:
        raise ProjectError(f"{field} must be text of at most {maximum} characters")
    if any(ord(c) < 32 and c not in "\t\n\r" for c in value) or "\x7f" in value:
        raise ProjectError(f"{field} contains unsupported control characters")
    if required and not value.strip():
        raise ProjectError(f"{field} is required")
    return value if preserve else value.strip()


def _known(value, field):
    value = _text(value, field, required=True)
    if value.casefold() in UNKNOWN:
        raise ProjectError(f"Checked evidence requires an identified {field}")
    return value


def _hash(value, field, *, required=False):
    if value in (None, "") and not required:
        return None
    if not isinstance(value, str) or not SHA256.fullmatch(value):
        raise ProjectError(f"{field} must be a lowercase SHA-256 digest")
    return value


def _accessed(value, *, required=False):
    if value is None and not required:
        return None
    value = _text(value, "accessed_at", required=True, maximum=80)
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            date.fromisoformat(value)
        else:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
            if "T" not in value or parsed.tzinfo is None:
                raise ValueError("A timestamp must include a timezone")
    except ValueError as exc:
        raise ProjectError("accessed_at must be an actual ISO date or timezone-aware timestamp supplied by the reviewer") from exc
    return value


def _uri(value):
    value = _text(value, "uri", required=True, maximum=4096)
    if (re.search(r"[\s<>\"{}|\\^`]", value) or re.search(r"[\x00-\x1f\x7f]", unquote(value))
            or re.search(r"%(?![0-9a-fA-F]{2})", value)):
        raise ProjectError("URI contains whitespace, control characters, or unsupported URI characters")
    try:
        parts = urlsplit(value)
        scheme = parts.scheme.casefold()
        if scheme in {"http", "https"}:
            host = parts.hostname
            if not host or parts.username is not None or parts.password is not None:
                raise ValueError("A web URI needs a host and must not contain credentials")
            if parts.port is not None and not 1 <= parts.port <= 65535:
                raise ValueError("Invalid port")
            if ":" in host:
                ipaddress.IPv6Address(host)
            else:
                ascii_host = host.encode("idna").decode("ascii").rstrip(".")
                if len(ascii_host) > 253 or any(not re.fullmatch(r"[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?", label)
                                               for label in ascii_host.split(".")):
                    raise ValueError("Malformed hostname")
        elif scheme == "doi":
            if not re.fullmatch(r"10\.\d{4,9}/\S+", parts.path) or parts.netloc or parts.query or parts.fragment:
                raise ValueError("Malformed DOI URI")
        elif scheme == "urn":
            if (not re.fullmatch(r"(?:isbn:[0-9Xx-]{10,25}|sha256:[0-9a-f]{64})", parts.path)
                    or parts.netloc or parts.query or parts.fragment):
                raise ValueError("Only ISBN and lowercase SHA-256 URNs are supported")
        else:
            raise ValueError("Use http, https, doi, urn:isbn, or urn:sha256")
    except (ValueError, UnicodeError) as exc:
        raise ProjectError(f"Malformed or unsupported source URI: {exc}") from exc
    return value


def _record(value, fields, what):
    if not isinstance(value, dict):
        raise ProjectError(f"{what} must be an object")
    unknown = set(value) - fields
    if unknown:
        raise ProjectError(f"Unsupported {what} fields: {', '.join(sorted(map(str, unknown)))}")
    return deepcopy(value)


def _revision(record):
    return digest({k: v for k, v in record.items() if k not in {"revision", "recorded_at"}})


def _intact(record):
    if not isinstance(record, dict) or not isinstance(record.get("revision"), str):
        return False
    try:
        return record["revision"] == _revision(record)
    except (TypeError, ValueError):
        return False


def _save_version(collection, key, payload, previous, what):
    current = collection.get(key)
    payload["revision"] = _revision(payload)
    if current is not None:
        if not _intact(current):
            raise ProjectError(f"Stored {what} integrity failed: {key}")
        if previous is not None and previous != current["revision"]:
            raise ProjectError(f"Stale previous_revision for {what} {key}")
        if payload["revision"] == current["revision"]:
            return deepcopy(current), False
        if previous != current["revision"]:
            raise ProjectError(f"{what.capitalize()} {key} already exists; supply its exact previous_revision to update it")
    elif previous is not None:
        raise ProjectError(f"Cannot update unknown {what} {key} with previous_revision")
    payload["recorded_at"] = utc_now()
    collection[key] = payload
    return deepcopy(payload), True


def register_source(store: ProjectStore, key: str, record: dict) -> dict:
    """Record bibliographic provenance, with no network request or admission.

    Required fields are title and uri. status defaults to candidate. Checked
    sources require an exact version or content_sha256, checked_by, and accessed_at.
    Updating a key requires its current previous_revision. Repeating an identical
    registration is idempotent. Unknown version/checker/date values may be null
    for a candidate, but a URI must still identify the candidate material.
    """
    if not isinstance(key, str):
        raise ProjectError("Source key must be text")
    valid_name(key, "source key")
    raw = _record(record, SOURCE_FIELDS, "source record")
    status = raw.get("status", "candidate")
    if not isinstance(status, str) or status not in {"candidate", "checked"}:
        raise ProjectError("Source status must be candidate or checked")
    version = _text(raw.get("version"), "version", maximum=2048)
    content_hash = _hash(raw.get("content_sha256"), "content_sha256")
    uri = _uri(raw.get("uri"))
    if uri.casefold().startswith("urn:sha256:"):
        uri_hash = uri[len("urn:sha256:"):]
        if content_hash is not None and content_hash != uri_hash:
            raise ProjectError("content_sha256 does not match the SHA-256 source URN")
        # This copies the hash explicitly supplied in the identifier. It does
        # not hash, open, or imply inspection of a local file.
        content_hash = uri_hash
    checked_by = _text(raw.get("checked_by"), "checked_by", maximum=256)
    accessed = _accessed(raw.get("accessed_at"), required=status == "checked")
    if status == "checked":
        if not content_hash and (version is None or version.casefold() in MUTABLE_VERSION):
            raise ProjectError("A checked source requires an exact version or content_sha256")
        checked_by = _known(checked_by, "checked_by")
    authors = raw.get("authors", [])
    if not isinstance(authors, list) or len(authors) > 100:
        raise ProjectError("authors must be a list of at most 100 names")
    payload = {"key": key, "title": _text(raw.get("title"), "title", required=True, maximum=4096),
               "uri": uri, "version": version, "content_sha256": content_hash,
               "status": status, "checked_by": checked_by, "accessed_at": accessed,
               "authors": [_text(a, "author", required=True, maximum=256) for a in authors],
               "year": _text(raw.get("year"), "year", maximum=80),
               "publisher": _text(raw.get("publisher"), "publisher", maximum=2048),
               "notes": _text(raw.get("notes"), "notes")}
    previous = _hash(raw.get("previous_revision"), "previous_revision")

    def change(state):
        saved, changed = _save_version(state["source_records"], key, payload, previous, "source")
        return {"source": saved, "changed": changed,
                "meaning": "Recorded bibliographic provenance and reviewer assertions; no source was fetched or theorem verified."}
    return store.transact("register_source", change, details={"source_key": key, "status": status})


def _citation_content(raw):
    status = raw.get("status", "candidate")
    if not isinstance(status, str) or status not in {"candidate", "checked"}:
        raise ProjectError("Citation status must be candidate or checked")
    locator = raw.get("locator", {})
    if not isinstance(locator, dict) or set(locator) - LOCATORS:
        raise ProjectError("locator must contain only named theorem/page/section/chapter/tag/equation/paragraph/appendix/url_fragment fields")
    locator = {k: _text(v, f"locator.{k}", required=True, maximum=1024) for k, v in locator.items()}
    assumptions = raw.get("assumptions", [])
    if not isinstance(assumptions, list) or len(assumptions) > 100:
        raise ProjectError("assumptions must be a list of at most 100 required/discharge records")
    for assumption in assumptions:
        if not isinstance(assumption, dict) or set(assumption) != {"required", "discharge"}:
            raise ProjectError("Each assumption must have exactly required and discharge text")
    assumptions = [{k: _text(a[k], f"assumption.{k}", required=True) for k in ("required", "discharge")}
                   for a in assumptions]
    no_assumptions = raw.get("no_assumptions", False)
    if not isinstance(no_assumptions, bool) or (no_assumptions and assumptions):
        raise ProjectError("no_assumptions must be a boolean and cannot accompany a nonempty assumptions list")
    inspected = _text(raw.get("inspected_text"), "inspected_text", preserve=True)
    evidence_hash = _hash(raw.get("evidence_sha256"), "evidence_sha256")
    if inspected is not None and inspected.strip():
        actual = hashlib.sha256(inspected.encode("utf-8")).hexdigest()
        if evidence_hash is not None and evidence_hash != actual:
            raise ProjectError("evidence_sha256 does not match the supplied inspected_text bytes")
        evidence_hash = actual
    values = {"status": status, "locator": locator, "assumptions": assumptions,
              "no_assumptions": no_assumptions, "inspected_text": inspected,
              "evidence_sha256": evidence_hash,
              "accessed_at": _accessed(raw.get("accessed_at"), required=status == "checked")}
    for field in ("supporting_statement", "substitution", "conclusion", "justification", "checked_by"):
        values[field] = _text(raw.get(field), field, maximum=256 if field == "checked_by" else 65536)
    if status == "checked":
        if not locator:
            raise ProjectError("A checked citation requires an exact theorem/page/section locator")
        locator = {k: _known(v, f"locator.{k}") for k, v in locator.items()}
        values["locator"] = locator
        for field in ("supporting_statement", "substitution", "conclusion", "justification", "checked_by"):
            values[field] = _known(values[field], field)
        if not assumptions and not no_assumptions:
            raise ProjectError("List the source assumptions and their discharge, or explicitly justify no_assumptions=true")
        if not evidence_hash:
            raise ProjectError("A checked citation requires inspected_text or an attested evidence_sha256")
    return values


def _reference_ids(value) -> list[str]:
    if (not isinstance(value, list) or len(value) > 1000 or
            any(not isinstance(entry, str) or not re.fullmatch(r"[0-9a-f]{24}", entry) for entry in value)):
        raise ProjectError("reference_ids must be a list of at most 1000 current 24-character bibliography slot IDs")
    if len(set(value)) != len(value):
        raise ProjectError("reference_ids must not contain duplicate bibliography slots")
    return sorted(value)


def _subject_bibliography(item: dict, proof: dict | None = None) -> list[dict]:
    """Inventory one exact subject; a proof does not inherit statement slots here."""
    owner = proof if proof is not None else item
    proof_id = proof.get("id") if proof is not None else None
    subject = proof_id or item["id"] + ":statement"
    raw_rows = owner.get("bibliographic_references", [])
    if not isinstance(raw_rows, list):
        raw_rows = [None]  # Preserve a blocking malformed-reader obligation.
    output, seen = [], set()
    for raw in raw_rows:
        row = raw if isinstance(raw, dict) else {}
        identifier, role, command = row.get("reference_id"), row.get("role"), row.get("command")
        notes = row.get("notes", [])
        valid = (isinstance(identifier, str) and re.fullmatch(r"[0-9a-f]{24}", identifier) is not None
                 and identifier not in seen and isinstance(row.get("key"), str) and bool(row["key"])
                 and isinstance(command, str) and bool(command)
                 and isinstance(notes, list) and all(isinstance(note, str) for note in notes)
                 and isinstance(row.get("in_header", False), bool)
                 and role in {"statement", "proof", "mention", "bibliography"})
        if role == "bibliography" and (not isinstance(command, str) or command.rstrip("*") != "nocite"):
            valid = False
        if isinstance(identifier, str):
            seen.add(identifier)
        required = not valid or (item.get("kind") not in NAVIGATION and role != "bibliography")
        output.append({"reference_id": identifier, "item_id": item["id"], "proof_id": proof_id,
                       "subject": subject, "key": row.get("key"), "command": command,
                       "notes": deepcopy(notes), "source": deepcopy(row.get("source")), "role": role,
                       "in_header": row.get("in_header", False),
                       "required": required, "integrity": bool(valid)})
    return output


def _reference_signature(row: dict) -> str:
    """Bind interpreted content and ownership, not incidental source positions."""
    return digest({key: row.get(key) for key in
                   ("reference_id", "subject", "key", "command", "notes", "role", "in_header")})


def cite_source(store: ProjectStore, item_ref: str, source_key: str, record: dict) -> dict:
    """Attach exact source evidence to a declaration or one selected proof.

    Every citation names citation_key, source_revision, and declaration_revision.
    A proof citation also supplies proof_id and proof_revision. Checked citations
    need a checked source plus the exact supporting statement, locator, assumptions
    and discharges, substitution, conclusion, justification, inspection evidence,
    named checker, and access date. Candidate citations are explicit obstacles to
    accepting the subject that uses them. Existing citations require their own
    previous_revision for updates. This never admits a mathematical foundation.

    To cover literal TeX citations, provide the exact reference_ids from that
    subject's prepared review packet. The program records their interpreted
    signatures internally. A bibliography key or source registration alone is
    not coverage, and one proof cannot cover another proof's occurrences.
    """
    if not isinstance(source_key, str):
        raise ProjectError("Source key must be text")
    valid_name(source_key, "source key")
    raw = _record(record, CITATION_FIELDS, "citation record")
    key = raw.get("citation_key")
    if not isinstance(key, str):
        raise ProjectError("citation_key is required")
    valid_name(key, "citation key")
    expected_source = _hash(raw.get("source_revision"), "source_revision", required=True)
    expected_declaration = _hash(raw.get("declaration_revision"), "declaration_revision", required=True)
    previous = _hash(raw.get("previous_revision"), "previous_revision")
    proof_id = raw.get("proof_id")
    if proof_id is not None and not isinstance(proof_id, str):
        raise ProjectError("proof_id must be an actual proof identifier or null")
    expected_proof = _hash(raw.get("proof_revision"), "proof_revision", required=proof_id is not None)
    if proof_id is None and expected_proof is not None:
        raise ProjectError("proof_revision requires proof_id")
    content = _citation_content(raw)
    reference_ids = _reference_ids(raw["reference_ids"]) if "reference_ids" in raw else None

    def change(state):
        from .workflow import require_fresh
        require_fresh(store, state)
        if "citations" not in state:
            raise ProjectError("This project store does not support citation records")
        iid = resolve_item(state, item_ref)
        item = state["items"][iid]
        source = state["source_records"].get(source_key)
        if not _intact(source):
            raise ProjectError(f"Unknown or invalid source: {source_key}")
        if source["revision"] != expected_source:
            raise ProjectError("Stale source_revision; inspect the intended source version before citing it")
        if item["declaration_revision"] != expected_declaration:
            raise ProjectError("Stale declaration_revision in citation")
        if proof_id is not None:
            proof = state["proofs"].get(proof_id)
            if not proof or not proof.get("active") or proof.get("conclusion") != iid:
                raise ProjectError("Citation proof_id must identify an active proof of this item")
            if proof.get("revision") != expected_proof:
                raise ProjectError("Stale proof_revision in citation")
        else:
            proof = None
        reference_bindings = None
        if reference_ids is not None:
            slots = {row["reference_id"]: row for row in _subject_bibliography(item, proof)
                     if row["integrity"]}
            unknown = sorted(set(reference_ids) - slots.keys())
            if unknown:
                raise ProjectError("Citation reference_ids must identify current bibliography slots of exactly this statement or proof: " + ", ".join(unknown))
            reference_bindings = {key: _reference_signature(slots[key]) for key in reference_ids}
        if content["status"] == "checked" and source["status"] != "checked":
            raise ProjectError("A checked citation requires checked, versioned source provenance")
        cid = "citation-" + digest([iid, proof_id, source_key, key])[:24]
        existing = state["citations"].get(cid)
        if isinstance(existing, dict) and not existing.get("active", True):
            raise ProjectError("A retired citation ID is terminal; choose a new citation_key for a renewed use")
        payload = {"id": cid, "citation_key": key, "item_id": iid, "proof_id": proof_id,
                   "declaration_revision": expected_declaration, "proof_revision": expected_proof,
                   "source_key": source_key, "source_revision": expected_source,
                   **content, "active": True}
        if reference_ids is not None:
            payload.update(reference_ids=reference_ids, reference_bindings=reference_bindings)
        saved, changed = _save_version(state["citations"], cid, payload, previous, "citation")
        return {"citation": saved, "changed": changed,
                "meaning": "Recorded exact external evidence and its application; the named reviewer's judgment is not a proof certificate or foundation admission."}
    return store.transact("cite_source", change, details={"item_ref": item_ref, "source_key": source_key, "citation_key": key})


def retire_citation(store: ProjectStore, citation_id: str, *, expected_revision: str,
                    reason: str, reviewer: str) -> dict:
    """Explicitly withdraw an obsolete use while retaining its event history."""
    expected_revision = _hash(expected_revision, "expected_revision", required=True)
    reason, reviewer = _known(reason, "reason"), _known(reviewer, "reviewer")

    def change(state):
        from .workflow import require_fresh
        require_fresh(store, state)
        current = state.get("citations", {}).get(citation_id)
        if not _intact(current) or current["revision"] != expected_revision:
            raise ProjectError("Unknown citation or stale expected_revision")
        if not current.get("active", True):
            raise ProjectError("Citation is already retired")
        payload = {k: deepcopy(v) for k, v in current.items() if k not in {"revision", "recorded_at"}}
        payload.update(active=False, retirement={"reason": reason, "reviewer": reviewer, "at": utc_now()})
        saved, _ = _save_version(state["citations"], citation_id, payload, expected_revision, "citation")
        return {"citation": saved, "meaning": "The use is retired; earlier source and citation versions remain in the authoritative event history."}
    return store.transact("retire_citation", change, details={"citation_id": citation_id})


def citation_index(state: dict) -> dict:
    """Index citation records, including withdrawal history, once per report."""
    result = {}
    for cid, citation in sorted(state.get("citations", {}).items()):
        if isinstance(citation, dict):
            result.setdefault(citation.get("item_id"), []).append(citation)
    return result


def _obstacles(state, citation):
    cid = citation.get("id")
    problems = []

    def add(kind, **extra):
        problems.append({"kind": kind, "citation_id": cid, **extra})

    if not _intact(citation):
        add("citation_integrity_failed")
    if citation.get("status") != "checked":
        add("citation_unchecked")
    source_key = citation.get("source_key")
    source = state.get("source_records", {}).get(source_key)
    if source is None:
        add("citation_source_missing", source_key=source_key)
    elif not _intact(source):
        add("source_integrity_failed", source_key=source_key)
    else:
        if source.get("status") != "checked":
            add("citation_source_unchecked", source_key=source_key)
        if citation.get("source_revision") != source["revision"]:
            add("citation_source_stale", source_key=source_key)
    item = state.get("items", {}).get(citation.get("item_id"))
    if not item or item.get("lifecycle") != "active":
        add("citation_item_inactive")
    elif citation.get("declaration_revision") != item.get("declaration_revision"):
        add("citation_declaration_stale")
    pid = citation.get("proof_id")
    proof = None
    if pid is not None:
        proof = state.get("proofs", {}).get(pid)
        if not proof or not proof.get("active") or proof.get("conclusion") != citation.get("item_id"):
            add("citation_proof_inactive", proof_id=pid)
        elif citation.get("proof_revision") != proof.get("revision"):
            add("citation_proof_stale", proof_id=pid)
    if "reference_ids" in citation:
        try:
            reference_ids = _reference_ids(citation["reference_ids"])
        except ProjectError:
            add("citation_reference_ids_invalid")
        else:
            slots = ({row["reference_id"]: row for row in _subject_bibliography(item, proof)
                      if row["integrity"]} if item and (pid is None or proof) else {})
            bindings = citation.get("reference_bindings")
            if not isinstance(bindings, dict) or set(bindings) != set(reference_ids):
                add("citation_reference_bindings_invalid")
            else:
                stale = [key for key in reference_ids if key not in slots or
                         bindings[key] != _reference_signature(slots[key])]
                if stale:
                    add("citation_reference_stale", reference_ids=stale)
    return problems


def citation_binding(state: dict, iid: str, proof_id: str | None = None, *, index: dict | None = None) -> dict:
    """Return exact source/citation revisions and obstacles for one review subject.

    Item-level citations affect all its proofs. Proof-specific citations affect
    only that proof. Stale citations remain visible as obligations until updated
    or explicitly retired. Retired revisions remain causal history so withdrawal
    cannot reactivate an acceptance made before the evidence was recorded. They
    are not active evidence and do not bind the source's current version. The
    optional index is produced by citation_index().

    Supported literal citation occurrences are inventoried independently of
    registered evidence. Required occurrences need explicit current coverage.
    Navigation citations and nocite listings remain visible without automatic
    proof obligations. Existing candidate-record obstacles are not exempted.
    """
    item = state.get("items", {}).get(iid)
    if not item or item.get("lifecycle") != "active":
        raise ProjectError(f"Unknown active citation subject: {iid}")
    proof = None
    if proof_id is not None:
        proof = state.get("proofs", {}).get(proof_id)
        if not proof or not proof.get("active") or proof.get("conclusion") != iid:
            raise ProjectError("Citation binding requires an active proof of the selected item")
    rows = (index if index is not None else citation_index(state)).get(iid, [])
    sources, citations, retired, obstacles = {}, {}, {}, []
    textual = _subject_bibliography(item)
    if proof is not None:
        textual += _subject_bibliography(item, proof)
    covered = {}
    for row in rows:
        if row.get("proof_id") is not None and row.get("proof_id") != proof_id:
            continue
        if not row.get("active", True):
            retired[row["id"]] = row.get("revision")
            if not _intact(row):
                obstacles.append({"kind": "citation_integrity_failed", "citation_id": row.get("id")})
            continue
        key = row.get("source_key")
        source = state.get("source_records", {}).get(key)
        sources[key] = source.get("revision") if isinstance(source, dict) else None
        citations[row["id"]] = row.get("revision")
        problems = _obstacles(state, row)
        obstacles.extend(problems)
        if not problems:
            for reference_id in row.get("reference_ids", []):
                covered.setdefault((row.get("proof_id"), reference_id), []).append(row["id"])
    for reference in textual:
        reference["covered_by"] = (sorted(covered.get((reference["proof_id"], reference["reference_id"]), []))
                                   if reference["integrity"] else [])
        if not reference["integrity"]:
            reference["status"] = "invalid"
            obstacles.append({"kind": "bibliography_reference_invalid", "item_id": iid,
                              "proof_id": reference["proof_id"], "reference_id": reference["reference_id"],
                              "key": reference["key"], "source": reference["source"]})
        elif not reference["required"]:
            reference["status"] = "not_required"
        elif reference["covered_by"]:
            reference["status"] = "covered"
        else:
            reference["status"] = "uncovered"
            obstacles.append({"kind": "bibliography_evidence_missing", "item_id": iid,
                              "proof_id": reference["proof_id"], "subject": reference["subject"],
                              "reference_id": reference["reference_id"], "key": reference["key"],
                              "command": reference["command"], "notes": reference["notes"],
                              "source": reference["source"]})
    result = {"sources": sources, "citations": citations, "retired_citations": retired, "obstacles": obstacles}
    if textual:
        result["textual_references"] = textual
    return result


def audit_sources(store: ProjectStore, *, include_unowned: bool = False) -> dict:
    """Inspect current provenance records, without inspecting the external material.

    The broad audit lists candidates and stale uses across every proof. Release
    eligibility should use citation_binding for the actual selected support plan;
    an unused candidate source is not a mathematical dependency.

    include_unowned=True additionally decodes the current source archive to
    inventory references outside indexed objects. Owned file-level mirrors are
    excluded from that list; indexed navigation references remain in the main
    textual inventory with required=False.
    """
    state = store.state()
    sources, citations, problems = [], [], []
    for key, source in sorted(state.get("source_records", {}).items()):
        valid = _intact(source)
        sources.append({"key": key, "revision": source.get("revision") if isinstance(source, dict) else None,
                        "status": source.get("status") if isinstance(source, dict) else None, "integrity": valid})
        if not valid:
            problems.append({"kind": "source_integrity_failed", "source_key": key})
    for cid, citation in sorted(state.get("citations", {}).items()):
        if not isinstance(citation, dict):
            problems.append({"kind": "citation_integrity_failed", "citation_id": cid})
            continue
        obstacles = _obstacles(state, citation) if citation.get("active", True) else (
            [] if _intact(citation) else [{"kind": "citation_integrity_failed", "citation_id": cid}])
        citations.append({"id": cid, "item_id": citation.get("item_id"), "proof_id": citation.get("proof_id"),
                          "revision": citation.get("revision"), "active": citation.get("active", True),
                          "status": citation.get("status"), "obstacles": obstacles})
        problems.extend(obstacles)
    index = citation_index(state)
    textual = []
    for iid, item in sorted(state.get("items", {}).items()):
        if item.get("lifecycle") != "active":
            continue
        subjects = [None] + [pid for pid in item.get("proof_ids", [])
                             if state.get("proofs", {}).get(pid, {}).get("active")]
        for pid in subjects:
            owner = state["proofs"][pid] if pid is not None else item
            if not owner.get("bibliographic_references"):
                continue
            binding = citation_binding(state, iid, pid, index=index)
            textual.extend(row for row in binding.get("textual_references", []) if row["proof_id"] == pid)
            problems.extend(row for row in binding["obstacles"]
                            if row["kind"] in {"bibliography_evidence_missing", "bibliography_reference_invalid"}
                            and row.get("proof_id") == pid)
    unowned = []
    if include_unowned and state.get("current_snapshot"):
        snapshot = store.snapshot(state["current_snapshot"])
        for source in snapshot.get("files", []):
            for row in source.get("bibliographic_references", []):
                if not row.get("item_key"):
                    unowned.append({**deepcopy(row), "required": False, "status": "unowned_inventory",
                                    "meaning": "Outside an indexed review subject; inspect its mathematical context separately."})
    return {"snapshot": state.get("current_snapshot"), "sources": sources, "citations": citations,
            "textual_references": textual, "unowned_bibliographic_references": unowned,
            "unowned_inventory_included": include_unowned,
            "obstacles": problems,
            "meaning": "This audits recorded provenance, current bindings, and supported literal bibliography slots. No external material was fetched; arbitrary macros and implicit uncited uses still need mathematical inspection."}
