"""Owner-side projection of frozen releases for independently hosted read APIs.

The online reader never imports this module or receives a ProjectStore. A
registered release is an internal archive, not a publication boundary: only
the explicitly selected fields below are copied into the public corpus.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import secrets

from .publish import _load_release, _rename_new
from .store import ProjectError, ProjectStore, contained, digest


FORMAT = "math-project-public-corpus"
SCHEMA_VERSION = 1
_ASSETS = ("runtime.mjs", "index.html", "build.mjs", "serve.mjs")
_ASSET_DIRECTORY = Path(__file__).resolve().parents[2] / "assets" / "readonly-api"
_LOCATORS = {"theorem", "page", "section", "chapter", "tag", "equation",
             "paragraph", "appendix", "url_fragment"}


def _source_location(source: dict) -> dict:
    """Publish a relative location, never a path accepted for file retrieval."""
    path = source.get("path")
    if (not isinstance(path, str) or not path or "\\" in path or "\x00" in path
            or PurePosixPath(path).is_absolute() or ".." in PurePosixPath(path).parts
            or re.match(r"^[A-Za-z]:", path)):
        raise ProjectError("Public source locations must use safe relative paths")
    start, end = source.get("start_line"), source.get("end_line")
    if (type(start) is not int or type(end) is not int or start < 1 or end < start):
        raise ProjectError("Public source locations require valid line bounds")
    return {"path": path, "start_line": start, "end_line": end}


def _public_references(references: list, scope: str, included: set) -> list:
    return [{"label": row.get("label", ""), "command": row.get("command", ""),
             "line": row.get("line"), "scope": scope,
             "target_id": row.get("target_id") if row.get("target_id") in included else None,
             "relation": "candidate_reference"}
            for row in references]


def _public_applications(state: dict, item_id: str, proof_id: str | None, included: set,
                         manual_index: dict) -> list:
    from .workflow import _application_current, _subject, _subject_refs
    result = []
    subjects = [(item_id + ":statement", "statement")]
    if proof_id is not None:
        subjects.append((proof_id, "proof"))
    for subject_id, scope in subjects:
        _, subject = _subject(state, subject_id)
        for reference in _subject_refs(state, subject, index={"manual": manual_index}):
            row = state["applications"].get(reference.get("application_key"), {})
            if row.get("target_id") not in included or not _application_current(state, subject, reference, row):
                continue
            result.append({"application_key": row["application_key"], "scope": scope,
                           "target_id": row["target_id"], "target_revision": row["target_revision"],
                           "relation": row["relation"], "substitution": row.get("substitution", ""),
                           "hypotheses": [{key: h.get(key, "") for key in ("required", "discharge")}
                                          for h in row.get("hypotheses", [])],
                           "no_hypotheses": row.get("no_hypotheses") is True,
                           "conclusion": row.get("conclusion", ""),
                           "target_clause": row.get("target_clause")})
    return result


def _public_citations(state: dict, item_id: str, proof_id: str | None, citation_index: dict) -> list:
    from .sources import citation_binding
    binding = citation_binding(state, item_id, proof_id, index=citation_index)
    if binding["obstacles"]:
        raise ProjectError(f"Frozen public citation evidence is inconsistent for {item_id}")
    result = []
    for citation_id in sorted(binding["citations"]):
        row = state["citations"][citation_id]
        source = state["source_records"][row["source_key"]]
        result.append({"citation_id": row["id"], "citation_revision": row["revision"],
                       "source_key": row["source_key"], "source_revision": row["source_revision"],
                       "title": source["title"], "uri": source["uri"], "version": source.get("version"),
                       "content_sha256": source.get("content_sha256"),
                       "locator": {key: value for key, value in row.get("locator", {}).items() if key in _LOCATORS},
                       "status": row["status"], "scope": "proof" if row.get("proof_id") else "statement",
                       "reference_ids": list(row.get("reference_ids", [])),
                       "assumptions": [{key: assumption[key] for key in ("required", "discharge")}
                                       for assumption in row["assumptions"]],
                       "no_assumptions": row["no_assumptions"],
                       "substitution": row["substitution"], "conclusion": row["conclusion"]})
    return result


def _project_release(data: dict, title: str | None, demo: bool) -> dict:
    from .sources import citation_index
    if title is not None and (not isinstance(title, str) or not title.strip() or len(title) > 512):
        raise ProjectError("Public title must be nonempty text of at most 512 characters")
    if not isinstance(demo, bool):
        raise ProjectError("Public demo flag must be a boolean")
    state, support = data["state"], data["support"]
    included = set(data["included"])
    if not included or not included <= set(state["items"]):
        raise ProjectError("Frozen public release has an invalid included scope")
    manifest = data["snapshot_data"]["manifest"]
    # A large corpus must not rescan every application/citation for each item.
    manual_index = {}
    for key, row in state["applications"].items():
        if row.get("manual"):
            manual_index.setdefault(row.get("proof_id"), []).append((key, row))
    citation_rows = citation_index(state)
    items = {}
    for item_id in sorted(included):
        item = state["items"][item_id]
        admitted = item_id in support["admissions"]
        selected = None if admitted else support["selected_proofs"].get(item_id)
        choice = support["eligibility"].get(selected, {})
        if not admitted and not choice.get("eligible"):
            raise ProjectError(f"Frozen public result has no eligible selected support: {item_id}")
        dependencies = [] if admitted else list(choice.get("dependencies", []))
        if not set(dependencies) <= included:
            raise ProjectError(f"Frozen public result has a dependency outside its release: {item_id}")
        proof = None
        if selected is not None and selected != item_id + ":declaration":
            proof = state["proofs"].get(selected)
            if not proof or proof.get("conclusion") != item_id or not proof.get("active"):
                raise ProjectError(f"Frozen public result has an invalid selected proof: {item_id}")
        references = _public_references(item.get("statement_references", []), "statement", included)
        if proof:
            references += _public_references(proof.get("references", []), "proof", included)
        # Bound contexts are embedded in the declaration, not copied from the
        # project's global context registry (which includes unpublished scopes).
        contexts = [{key: row[key] for key in ("key", "revision", "text")}
                    for row in item.get("contexts", [])]
        items[item_id] = {
            "id": item_id, "kind": item["kind"], "title": item.get("title", ""),
            "labels": sorted(set(item.get("label_aliases", []) + ([item["label"]] if item.get("label") else []))),
            "section": list(item.get("section", [])), "revision": item["revision"],
            "declaration_revision": item["declaration_revision"],
            "status": "admitted" if admitted else "reviewed",
            "admission": {"kind": support["admissions"][item_id]["kind"]} if admitted else None,
            "statement": {"text": item["statement"], "hash": item["statement_hash"],
                          "source": _source_location(item["source"])},
            "proof": ({"id": proof["id"], "revision": proof["revision"], "text": proof["text"],
                       "source": _source_location(proof["source"])} if proof else None),
            "contexts": contexts, "dependencies": sorted(set(dependencies)),
            "applications": _public_applications(state, item_id, proof["id"] if proof else None, included, manual_index),
            "references": references,
            "citations": _public_citations(state, item_id, proof["id"] if proof else None, citation_rows),
        }
    payload = {"schema_version": SCHEMA_VERSION, "format": FORMAT,
               "project": {"title": title.strip() if title is not None else manifest["name"],
                           "namespace": manifest["namespace"], "demo": demo},
               "release": {key: data[key] for key in ("id", "name", "snapshot", "created_at", "kind", "meaning")},
               "requested": list(data["requested"]),
               "order": [iid for iid in support["order"] if iid in included], "items": items}
    return {"corpus_id": digest(payload), **payload}


def _read_release(store: ProjectStore, release_id: str) -> dict:
    with store.locked():
        return _load_release(store, store.replay()[0], release_id)


def project_public_corpus(store: ProjectStore, release_id: str, title: str | None = None,
                          demo: bool = False) -> dict:
    """Return a public-field projection without creating a release or files.

    Reads the existing registered, immutable reviewed release. The owner's
    normal ledger lock is used; this function is not an online query handler.
    """
    return _project_release(_read_release(store, release_id), title, demo)


def _destination(store: ProjectStore, value: str | Path, snapshot: dict) -> Path:
    if not isinstance(value, (str, Path)):
        raise ProjectError("Public export destination must be a path")
    raw = Path(value)
    if ".." in raw.parts:
        raise ProjectError("Public export destination must not contain '..'")
    output = raw if raw.is_absolute() else store.root / raw
    if output == store.root or output in store.root.parents:
        raise ProjectError("Public export cannot replace the project or its parent")
    protected = [store.meta, store.manifest_path]
    for manifest in (snapshot["manifest"], store.manifest()):
        protected.extend(contained(store.root, path) for path in manifest["source_roots"])
        protected.extend(contained(store.root, path) for path in manifest["entrypoints"])
    protected.extend(contained(store.root, row["path"]) for row in snapshot.get("files", []))
    for path in protected:
        if output == path or output in path.parents or path in output.parents:
            raise ProjectError("Public export overlaps protected project sources or metadata")
    cursor = Path(output.anchor)
    for part in output.parts[1:]:
        cursor /= part
        if cursor.is_symlink():
            raise ProjectError("Public export paths must not contain symlinks")
    if output.exists():
        raise ProjectError("Public export destination already exists; choose a new directory")
    return output


def _install_files(output: Path, files: dict[str, bytes]) -> dict:
    """Install a new directory using no-follow descriptors and no-replace rename."""
    descriptors, stage_fd, stage_name, written, installed = [], None, None, [], False
    try:
        parent = os.open(output.anchor, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
        descriptors.append(parent)
        for component in output.parts[1:-1]:
            try:
                os.mkdir(component, mode=0o755, dir_fd=parent)
            except FileExistsError:
                pass
            parent = os.open(component, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
            descriptors.append(parent)
        stage_name = ".mpm-public-" + secrets.token_hex(12)
        os.mkdir(stage_name, mode=0o700, dir_fd=parent)
        stage_fd = os.open(stage_name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW, dir_fd=parent)
        hashes = {}
        for name, content in sorted(files.items()):
            if Path(name).name != name or name in {".", ".."}:
                raise ProjectError("Invalid generated public export filename")
            fd = os.open(name, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o644, dir_fd=stage_fd)
            written.append(name)
            with os.fdopen(fd, "wb") as stream:
                stream.write(content)
                stream.flush()
                os.fsync(stream.fileno())
            hashes[name] = hashlib.sha256(content).hexdigest()
        os.fchmod(stage_fd, 0o755)
        os.fsync(stage_fd)
        _rename_new(stage_name, output.name, parent)
        installed = True
        os.fsync(parent)
        return hashes
    except OSError as exc:
        raise ProjectError(f"Cannot write safe public export: {exc}") from exc
    finally:
        if stage_fd is not None:
            if not installed:
                for name in reversed(written):
                    try:
                        os.unlink(name, dir_fd=stage_fd)
                    except OSError:
                        pass
            os.close(stage_fd)
        if stage_name is not None and not installed and descriptors:
            try:
                os.rmdir(stage_name, dir_fd=descriptors[-1])
            except OSError:
                pass
        for fd in reversed(descriptors):
            os.close(fd)


def export_public_api(store: ProjectStore, destination: str | Path, release_id: str,
                      title: str | None = None, demo: bool = False) -> dict:
    """Export a reviewed public corpus and standalone reader assets to a new directory.

    Absolute destinations outside the project are supported. Existing paths,
    project metadata, source trees and symlink components are never replaced.
    No source repository, ledger, original release archive or credentials are
    copied. Building/serving the exported assets is a separate operation.
    """
    release = _read_release(store, release_id)
    corpus = _project_release(release, title, demo)
    output = _destination(store, destination, release["snapshot_data"])
    files = {"public-corpus.json": json.dumps(corpus, ensure_ascii=False, sort_keys=True,
                                              indent=2, allow_nan=False).encode("utf-8") + b"\n"}
    if _ASSET_DIRECTORY.is_symlink():
        raise ProjectError("Public reader asset directory must not be a symlink")
    for name in _ASSETS:
        path = _ASSET_DIRECTORY / name
        if path.is_symlink():
            raise ProjectError("Public reader assets must not be symlinks")
        if not path.is_file():
            raise ProjectError(f"Missing required public reader asset: {name}")
        try:
            files[name] = path.read_bytes()
        except OSError as exc:
            raise ProjectError(f"Cannot read public reader asset {name}: {exc}") from exc
    hashes = _install_files(output, files)
    return {"output": str(output), "corpus": str(output / "public-corpus.json"),
            "corpus_id": corpus["corpus_id"], "release_id": release["id"], "snapshot": release["snapshot"],
            "items": len(corpus["items"]), "files": hashes, "demo": demo,
            "meaning": "Standalone read-only publication; no project maintenance data or authority is included."}
