"""Version-bound mathematical review records and support eligibility.

These checks validate the provenance and completeness of review records. They
do not decide whether prose mathematics is true. A recorded mathematical
judgment remains attributable to its reviewer and exact inputs.
"""
from __future__ import annotations

from copy import deepcopy
from collections import defaultdict
import hashlib
from pathlib import Path
import re

from .project import NAVIGATION, reader_fingerprint, resolve_item
from .store import ProjectError, ProjectStore, contained, digest, utc_now, valid_name


CHECKS = ("hypotheses", "inference", "scope", "constructions", "citations")
RELATIONS = {"uses", "mention", "internal"}


def freshness(store: ProjectStore, state: dict | None = None) -> dict:
    """Compare source discovery and bytes, contexts, and policy with the import."""
    state = state if state is not None else store.state()
    sid = state.get("current_snapshot")
    if not sid:
        return {"fresh": False, "reasons": [{"kind": "no_snapshot"}], "snapshot": None}
    # The import event binds this compact source basis to exact archive bytes.
    # It is authoritative ledger data, unlike the disposable state.json cache.
    # Legacy projects are read through the full canonical snapshot validator.
    basis = state.get("source_basis")
    if isinstance(basis, dict) and basis.get("snapshot") == sid:
        if store.snapshot_bytes_hash(sid) != basis.get("snapshot_file_sha256"):
            raise ProjectError("Current source snapshot archive byte integrity failed; inspect and restore it before continuing")
        snapshot = basis
        manifest_hash = basis["manifest_hash"]
        contexts_hash = basis["contexts_hash"]
    else:
        snapshot = store.snapshot(sid)
        manifest_hash = digest(snapshot["manifest"])
        contexts_hash = digest(snapshot.get("contexts", {}))
    manifest = store.manifest()
    reasons = []
    from .changes import pending_change
    if pending_change(store):
        reasons.append({"kind": "source_change_recovery_pending"})
    if digest(manifest) != manifest_hash:
        reasons.append({"kind": "manifest_changed"})
    if digest(state["contexts"]) != contexts_hash:
        reasons.append({"kind": "contexts_changed"})
    before = {f["path"]: f["sha256"] for f in snapshot["files"]}
    # A clean corpus needs byte checks and the same filesystem resolution
    # decisions, not another structural parse. Checking only old file hashes
    # would miss new source-root files and an include shadowing its old target.
    from .latex import parse_project, source_layout
    layout = snapshot.get("source_layout")
    current_reader = reader_fingerprint()
    fast_available = isinstance(layout, dict) and isinstance(snapshot.get("reader_fingerprint"), str)
    must_parse = not fast_available or digest(manifest) != manifest_hash
    after = {}
    if fast_available:
        if snapshot["reader_fingerprint"] != current_reader:
            reasons.append({"kind": "reader_changed"})
            must_parse = True
        try:
            current_layout = source_layout(store.root, entrypoints=manifest["entrypoints"] or None,
                                           source_roots=manifest["source_roots"],
                                           lookups=layout.get("lookups", []))
            if current_layout != layout:
                reasons.append({"kind": "source_layout_changed"})
                must_parse = True
            for path in before:
                try:
                    candidate = contained(store.root, path)
                    after[path] = hashlib.sha256(candidate.read_bytes()).hexdigest()
                except (OSError, ProjectError):
                    must_parse = True
            if after != before:
                must_parse = True
        except (OSError, ValueError, RuntimeError) as exc:
            reasons.append({"kind": "source_layout_unreadable", "message": str(exc)})
            must_parse = True
    if must_parse:
        parsed = parse_project(store.root, entrypoints=manifest["entrypoints"] or None,
                               source_roots=manifest["source_roots"])
        after = {f["path"]: f["sha256"] for f in parsed["files"]}
        diagnostics = parsed["diagnostics"]
    else:
        diagnostics = snapshot.get("diagnostics", [])
    for path in sorted(before.keys() | after.keys()):
        if before.get(path) != after.get(path):
            kind = "source_added" if path not in before else "source_missing" if path not in after else "source_changed"
            reasons.append({"kind": kind, "path": path})
    for diag in diagnostics:
        if diag.get("severity") == "error":
            reasons.append({"kind": "parse_error", "diagnostic": diag})
    return {"fresh": not reasons, "reasons": reasons, "snapshot": sid}


def require_fresh(store: ProjectStore, state: dict) -> None:
    result = freshness(store, state)
    if not result["fresh"]:
        causes = ", ".join(x["kind"]+(":"+x["path"] if "path" in x else "") for x in result["reasons"][:8])
        raise ProjectError("Import current sources and contexts before recording this decision: "+causes)


def _subject(state: dict, proof_id: str) -> tuple[dict, dict]:
    if proof_id.endswith(":statement"):
        iid = proof_id[:-len(":statement")]
        if iid not in state["items"] or state["items"][iid].get("lifecycle") != "active":
            raise ProjectError(f"Unknown active statement: {proof_id}")
        item = state["items"][iid]
        refs = item.get("statement_references", [])
        revision = digest([item["declaration_revision"],
                           [{"label": r.get("label"), "target_id": r.get("target_id"),
                             "target_clause": r.get("target_clause")} for r in refs]])
        return item, {"id": proof_id, "conclusion": iid, "text": item["statement"],
                      "revision": revision, "references": refs, "active": True, "kind": "statement"}
    proof = state["proofs"].get(proof_id)
    if not proof or not proof.get("active"):
        raise ProjectError(f"Unknown active proof: {proof_id}")
    item = state["items"].get(proof["conclusion"])
    if not item or item.get("lifecycle") != "active":
        raise ProjectError(f"Proof conclusion is not active: {proof_id}")
    return item, proof


def _indexes(state: dict) -> dict:
    from .sources import citation_index
    result = {"manual": defaultdict(list), "reviews": defaultdict(list), "issues": defaultdict(list)}
    result["citations"] = citation_index(state)
    for key, app in state["applications"].items():
        if app.get("manual"):
            result["manual"][app.get("proof_id")].append((key, app))
    for review in state["reviews"].values():
        result["reviews"][digest(review.get("binding"))].append(review)
    for issue in state["issues"].values():
        result["issues"][issue.get("item_id")].append(issue)
    return result


def _subject_refs(state: dict, proof: dict, index: dict | None = None) -> list[dict]:
    refs = list(proof.get("references", []))
    known = {r.get("application_key") for r in refs}
    candidates = index["manual"].get(proof["id"], []) if index is not None else state["applications"].items()
    for key, app in sorted(candidates):
        if app.get("manual") and app.get("proof_id") == proof["id"] and key not in known:
            if app.get("proof_revision") == proof["revision"]:
                refs.append({"application_key": key, "label": app.get("target_id"),
                             "target_id": app.get("target_id"), "target_clause": app.get("target_clause"),
                             "command": "manual", "role": "reviewed_dependency"})
    return refs


def _application_current(state: dict, proof: dict, ref: dict, app: dict) -> bool:
    target = state["items"].get(ref.get("target_id"), {})
    return bool(app and app.get("proof_id") == proof["id"] and
                app.get("proof_revision") == proof["revision"] and
                app.get("target_id") == ref.get("target_id") and
                target.get("lifecycle") == "active" and
                app.get("target_revision") == target.get("declaration_revision"))


def application_templates(store: ProjectStore, proof_id: str) -> dict:
    state = store.state()
    item, proof = _subject(state, proof_id)
    records = []
    for ref in _subject_refs(state, proof):
        target = state["items"].get(ref.get("target_id"))
        records.append({"application_key": ref["application_key"], "proof_id": proof_id,
                        "proof_revision": proof["revision"], "target_id": ref.get("target_id"),
                        "target_revision": target["declaration_revision"] if target else None,
                        "target_clause": ref.get("target_clause"), "reference_label": ref.get("label"),
                        "relation": "uses", "substitution": "", "hypotheses": [],
                        "conclusion": "", "justification": "", "reviewer": "",
                        "manual": ref.get("command") == "manual"})
    return {"snapshot": state["current_snapshot"], "item": item, "proof": proof,
            "records": records, "freshness": freshness(store, state),
            "instruction": "For each use, list every required hypothesis and its actual discharge. Classify mere mentions and internal clause references explicitly."}


def record_applications(store: ProjectStore, records: list[dict]) -> dict:
    if not isinstance(records, list) or not records:
        raise ProjectError("Supply a nonempty list of application records")
    def change(state):
        require_fresh(store, state)
        saved = []
        for raw in records:
            if not isinstance(raw, dict):
                raise ProjectError("Each application must be an object")
            pid = raw.get("proof_id", "")
            item, proof = _subject(state, pid)
            if raw.get("proof_revision") != proof["revision"]:
                raise ProjectError(f"Stale proof revision in application for {pid}")
            iid = resolve_item(state, raw.get("target_id", ""))
            target = state["items"][iid]
            if raw.get("target_revision") != target["declaration_revision"]:
                raise ProjectError(f"Stale target declaration in application of {iid}")
            manual = raw.get("manual") is True
            key = raw.get("application_key")
            if manual:
                expected_key = digest([pid, "manual", iid, raw.get("target_clause")])[:24]
                if key and key != expected_key:
                    raise ProjectError("Manual application key does not match its proof, target and clause")
                key = expected_key
            else:
                refs = [r for r in proof.get("references", []) if r.get("application_key") == key]
                if len(refs) != 1 or refs[0].get("target_id") != iid:
                    raise ProjectError("Application does not correspond to a current parsed reference")
                if raw.get("target_clause") != refs[0].get("target_clause"):
                    raise ProjectError("Application target clause differs from the parsed reference")
            relation = raw.get("relation")
            if relation not in RELATIONS:
                raise ProjectError("Application relation must be uses, mention, or internal")
            if relation == "internal" and iid != item["id"]:
                raise ProjectError("Internal references must point to the same statement")
            if relation == "uses" and iid == item["id"]:
                raise ProjectError("A result cannot use itself as a previously established theorem; record an actual internal clause argument or a different proof")
            for field in ("justification", "reviewer"):
                if not isinstance(raw.get(field), str) or not raw[field].strip():
                    raise ProjectError(f"Application requires {field}")
            hypotheses = raw.get("hypotheses", [])
            if not isinstance(hypotheses, list):
                raise ProjectError("Application hypotheses must be a list")
            if relation == "uses":
                for field in ("substitution", "conclusion"):
                    if not isinstance(raw.get(field), str) or not raw[field].strip():
                        raise ProjectError(f"A theorem use requires a concrete {field}")
                for h in hypotheses:
                    if not isinstance(h, dict) or any(not isinstance(h.get(f), str) or not h[f].strip()
                                                      for f in ("required", "discharge")):
                        raise ProjectError("Each hypothesis needs required and discharge text")
                if not hypotheses and raw.get("no_hypotheses") is not True:
                    raise ProjectError("List the required hypotheses, or explicitly record no_hypotheses=true with a justification")
            entry = {"application_key": key, "proof_id": pid, "proof_revision": proof["revision"],
                     "target_id": iid, "target_revision": target["declaration_revision"],
                     "target_item_revision": target["revision"], "target_clause": raw.get("target_clause"),
                     "relation": relation, "substitution": raw.get("substitution", ""),
                     "hypotheses": deepcopy(hypotheses), "no_hypotheses": raw.get("no_hypotheses") is True,
                     "conclusion": raw.get("conclusion", ""), "justification": raw["justification"],
                     "reviewer": raw["reviewer"], "manual": manual, "recorded_at": utc_now()}
            entry["revision"] = digest(entry)
            state["applications"][key] = entry
            saved.append(entry)
        return {"applications": saved}
    return store.transact("record_applications", change, details={"count": len(records)})


def _binding(state: dict, iid: str, proof_id: str | None, index: dict | None = None) -> tuple[dict, list[dict], list[dict]]:
    item = state["items"][iid]
    _, statement = _subject(state, iid+":statement")
    subjects = [statement]
    if proof_id:
        actual_item, proof = _subject(state, proof_id)
        if actual_item["id"] != iid or proof_id.endswith(":statement"):
            raise ProjectError("Selected proof must prove the reviewed item")
        subjects.append(proof)
    apps, dependencies, obstacles = {}, {}, []
    for subject in subjects:
        for ref in _subject_refs(state, subject, index):
            key = ref["application_key"]
            app = state["applications"].get(key, {})
            target = state["items"].get(ref.get("target_id"), {})
            current = _application_current(state, subject, ref, app)
            apps[key] = app.get("revision") if current else None
            if not ref.get("target_id"):
                obstacles.append({"kind": "unresolved_reference", "subject": subject["id"], "label": ref.get("label"), "application_key": key})
            elif not current:
                obstacles.append({"kind": "application_missing_or_stale", "subject": subject["id"], "target": ref["target_id"], "application_key": key})
            if not current or app.get("relation") == "uses":
                if ref.get("target_id") and ref["target_id"] != iid:
                    dependencies[ref["target_id"]] = target.get("declaration_revision") if target.get("lifecycle") == "active" else None
            if current and app.get("relation") == "uses" and target.get("kind") in NAVIGATION:
                obstacles.append({"kind": "navigation_used_as_theorem", "target": target.get("id")})
    relevant_issues = (index["issues"].get(iid, []) if index is not None else
                       [issue for issue in state["issues"].values() if issue.get("item_id") == iid])
    issue_context = [{k: issue.get(k) for k in ("id", "severity", "scope", "proof_id", "status", "reason", "resolutions")}
                     for issue in sorted(relevant_issues, key=lambda x: x["id"])
                     if issue.get("severity") in {"blocker", "error"} and
                     (not issue.get("proof_id") or not proof_id or issue["proof_id"] == proof_id)]
    from .sources import citation_binding
    bibliography = citation_binding(state, iid, proof_id, index=index["citations"] if index is not None else None)
    obstacles.extend(bibliography["obstacles"])
    binding = {"item_id": iid, "declaration_revision": item["declaration_revision"],
               "context_hash": item["context_hash"], "statement_revision": statement["revision"],
               "proof_id": proof_id, "proof_revision": subjects[-1]["revision"] if proof_id else None,
               "applications": apps, "dependencies": dependencies, "issue_context": digest(issue_context),
               "sources": bibliography["sources"], "citations": bibliography["citations"],
               "retired_citations": bibliography["retired_citations"]}
    if bibliography.get("textual_references"):
        from .sources import _reference_signature
        binding["bibliographic_references"] = [
            {"reference_id": row["reference_id"], "signature": _reference_signature(row)}
            for row in bibliography["textual_references"]]
    return binding, obstacles, [state["items"][d] for d in sorted(dependencies) if d in state["items"]]


def prepare_review(store: ProjectStore, reference: str, proof_id: str | None = None) -> dict:
    state = store.state()
    iid = resolve_item(state, reference)
    item = state["items"][iid]
    if proof_id is None and len(item["proof_ids"]) == 1:
        proof_id = item["proof_ids"][0]
    if proof_id is None and len(item["proof_ids"]) > 1:
        raise ProjectError("This item has alternative proofs; select one proof ID for this review")
    binding, obstacles, dependencies = _binding(state, iid, proof_id)
    from .sources import citation_binding
    bibliography = citation_binding(state, iid, proof_id)
    template = {"binding": binding, "reviewer": {"id": "", "kind": "agent", "independent": True,
                                                "author_of_change": False},
                "verdict": "changes_required", "summary": "",
                "checks": [{"name": name, "status": "unchecked", "reason": ""} for name in CHECKS],
                "findings": []}
    return {"snapshot": state["current_snapshot"], "item": item,
            "proof": state["proofs"].get(proof_id), "dependencies": dependencies,
            "applications": [state["applications"].get(k) for k in binding["applications"]],
            "citations": [state["citations"].get(k) for k in binding["citations"]],
            "retired_citations": [state["citations"].get(k) for k in binding["retired_citations"]],
            "sources": [state["source_records"].get(k) for k in binding["sources"]],
            "bibliographic_references": bibliography.get("textual_references", []),
            "obstacles": obstacles, "open_issues": _open_issues(state, iid, proof_id),
            "freshness": freshness(store, state), "template": template,
            "meaning": "An accepted review records a named mathematical judgment on exact inputs; it is not a proof-assistant certificate."}


def _open_issues(state: dict, iid: str, proof_id: str | None = None, index: dict | None = None) -> list[dict]:
    candidates = index["issues"].get(iid, []) if index is not None else state["issues"].values()
    return [v for v in sorted(candidates, key=lambda v: v["id"])
            if v.get("status") == "open" and v.get("severity") in {"blocker", "error"}
            and v.get("item_id") == iid and (not v.get("proof_id") or not proof_id or v["proof_id"] == proof_id)]


def record_review(store: ProjectStore, report: dict) -> dict:
    if not isinstance(report, dict):
        raise ProjectError("Review report must be an object")
    def change(state):
        require_fresh(store, state)
        binding = report.get("binding", {})
        iid = resolve_item(state, binding.get("item_id", ""))
        pid = binding.get("proof_id")
        current, obstacles, _ = _binding(state, iid, pid)
        if binding != current:
            raise ProjectError("Review inputs are stale or incomplete; prepare a new review packet")
        reviewer = report.get("reviewer", {})
        if (not isinstance(reviewer, dict) or not isinstance(reviewer.get("id"), str)
                or not reviewer["id"].strip() or reviewer.get("kind") not in {"human", "agent"}
                or not isinstance(reviewer.get("independent"), bool)
                or not isinstance(reviewer.get("author_of_change"), bool)):
            raise ProjectError("Review must identify a human/agent reviewer and explicit independence/authorship")
        if reviewer["independent"] and reviewer["author_of_change"]:
            raise ProjectError("A reviewer cannot be independent of a change they authored")
        verdict = report.get("verdict")
        if verdict not in {"accept", "changes_required", "reject"}:
            raise ProjectError("Review verdict must be accept, changes_required, or reject")
        if not isinstance(report.get("summary"), str) or not report["summary"].strip():
            raise ProjectError("Review requires a substantive summary")
        checks = report.get("checks", [])
        if not isinstance(checks, list) or any(not isinstance(c, dict) for c in checks):
            raise ProjectError("Review checks must be a list of objects")
        if sorted(c.get("name", "") for c in checks) != sorted(CHECKS):
            raise ProjectError("Review must cover each named check exactly once: "+", ".join(CHECKS))
        for c in checks:
            if c.get("status") not in {"pass", "issue", "not_applicable"} or not isinstance(c.get("reason"), str) or not c["reason"].strip():
                raise ProjectError("Every check requires a pass/issue/not_applicable status and its actual reasoning")
        findings = report.get("findings", [])
        if not isinstance(findings, list):
            raise ProjectError("Review findings must be a list")
        for f in findings:
            if not isinstance(f, dict) or f.get("severity") not in {"blocker", "error", "warning", "note"}:
                raise ProjectError("Every finding needs a valid severity")
            reserved = {"id", "item_id", "proof_id", "review_id", "binding", "status", "created_at", "resolutions"}
            if reserved.intersection(f):
                raise ProjectError("Finding cannot override authoritative issue identity or provenance")
            if f.get("scope") not in {"statement", "proof"}:
                raise ProjectError("Every finding must specify scope=statement or scope=proof")
            if f["scope"] == "proof" and not pid:
                raise ProjectError("A proof-specific finding requires a selected proof")
            for field in ("title", "reason", "required_action"):
                if not isinstance(f.get(field), str) or not f[field].strip():
                    raise ProjectError(f"Every finding requires {field}")
        if verdict == "accept":
            if obstacles:
                raise ProjectError("Cannot accept a review with unresolved or stale applications: "+str(obstacles[:3]))
            if any(c["status"] == "issue" for c in checks) or any(f["severity"] in {"blocker", "error"} for f in findings):
                raise ProjectError("An accepting review cannot contain unresolved mathematical errors")
            if any(c["status"] != "pass" for c in checks if c["name"] in {"hypotheses", "inference", "scope"}):
                raise ProjectError("Acceptance requires positive reasoning for hypotheses, inference, and scope")
            if _open_issues(state, iid, pid):
                raise ProjectError("Resolve concrete open issues before recording acceptance")
        elif not findings:
            raise ProjectError("A non-accepting review must identify at least one concrete finding")
        at = utc_now()
        rid = "review-"+digest([binding, reviewer, at])[:24]
        entry = {"id": rid, "binding": deepcopy(binding), "reviewer": deepcopy(reviewer),
                 "verdict": verdict, "summary": report["summary"], "checks": deepcopy(checks),
                 "findings": deepcopy(findings), "snapshot": state["current_snapshot"], "recorded_at": at}
        state["reviews"][rid] = entry
        issue_ids = []
        for index, finding in enumerate(findings):
            issue_id = "issue-"+digest([rid, index])[:24]
            state["issues"][issue_id] = {**deepcopy(finding), "id": issue_id, "item_id": iid,
                                         "proof_id": pid if finding["scope"] == "proof" else None,
                                         "review_id": rid, "binding": deepcopy(binding),
                                         "status": "open", "created_at": at,
                                         "resolutions": []}
            issue_ids.append(issue_id)
        return {"review": entry, "issues": issue_ids, "meaning": "Recorded reviewer judgment; mathematical truth is not mechanically certified."}
    return store.transact("record_review", change)


def resolve_issue(store: ProjectStore, issue_id: str, *, reason: str, reviewer: str,
                  disposition: str = "fixed") -> dict:
    if disposition not in {"fixed", "invalid", "superseded"} or not reason.strip() or not reviewer.strip():
        raise ProjectError("Issue resolution needs a disposition, concrete reason, and reviewer")
    def change(state):
        require_fresh(store, state)
        issue = state["issues"].get(issue_id)
        if not issue:
            raise ProjectError(f"Unknown issue: {issue_id}")
        if issue["status"] != "open":
            raise ProjectError("Issue is already resolved")
        item = state["items"].get(issue["item_id"])
        resolution = {"disposition": disposition, "reason": reason, "reviewer": reviewer,
                      "snapshot": state["current_snapshot"], "item_revision": item.get("revision") if item else None,
                      "recorded_at": utc_now()}
        issue["resolutions"].append(resolution)
        issue["status"] = "resolved"
        return {"issue": issue, "next": "A fresh accepting review is still required for support eligibility."}
    return store.transact("resolve_issue", change, details={"issue_id": issue_id})


def support_report(store: ProjectStore, targets: list[str] | None = None, *,
                   check_freshness: bool = True, state: dict | None = None) -> dict:
    from .graph import solve_support
    state = state if state is not None else store.state()
    policy = store.manifest().get("policy", {})
    index = _indexes(state)
    active = {i: v for i, v in state["items"].items() if v.get("lifecycle") == "active" and v.get("kind") not in NAVIGATION}
    roots, admission_details = [], {}
    for iid, admission in sorted(state["foundations"].items()):
        from .sources import citation_binding
        bibliography = citation_binding(state, iid, index=index["citations"]) if iid in active else None
        citation_valid = bibliography is not None and not bibliography["obstacles"]
        if admission.get("kind") == "external_theorem":
            citation_valid = (citation_valid and bool(bibliography["citations"]) and
                              admission.get("source_binding") == {k: bibliography[k] for k in ("sources", "citations", "retired_citations")})
        if (iid in active and admission.get("active") and
                admission.get("declaration_revision") == active[iid]["declaration_revision"] and
                (admission["kind"] != "external_theorem" or policy.get("allow_external_foundations", True))
                and citation_valid and not _open_issues(state, iid, index=index)):
            roots.append(iid)
            admission_details[iid] = admission
    proofs, eligibility = [], {}
    for iid, item in active.items():
        proof_ids = item["proof_ids"] or [None]
        for pid in proof_ids:
            binding, obstacles, deps = _binding(state, iid, pid, index)
            open_issues = _open_issues(state, iid, pid, index)
            matching = [r for r in index["reviews"].get(digest(binding), []) if r.get("binding") == binding and
                        r.get("verdict") == "accept"]
            independent = [r for r in matching if r["reviewer"].get("independent") and not r["reviewer"].get("author_of_change")]
            accepted = independent if policy.get("require_independent_review", True) else matching
            reasons = list(obstacles)
            if not accepted:
                reasons.append({"kind": "current_independent_review_missing" if policy.get("require_independent_review", True) else "current_review_missing"})
            if open_issues:
                reasons.append({"kind": "open_mathematical_issues", "issue_ids": [x["id"] for x in open_issues]})
            proof_key = pid or iid+":declaration"
            if pid is None and item["kind"] not in {"definition", "convention", "notation", "situation"}:
                reasons.append({"kind": "proof_missing"})
            dependencies = sorted(binding["dependencies"])
            proofs.append({"id": proof_key, "conclusion": iid, "dependencies": dependencies, "eligible": not reasons})
            eligibility[proof_key] = {"eligible": not reasons, "reasons": reasons,
                                      "review_ids": sorted(r["id"] for r in accepted), "dependencies": dependencies}
    solved = solve_support(active, proofs, roots)
    requested = sorted({resolve_item(state, x) for x in targets}) if targets else sorted(active)
    supported = set(solved["grounded"])
    result = {"snapshot": state["current_snapshot"], **solved, "eligibility": eligibility,
              "admissions": admission_details, "requested": requested,
              "requested_supported": [x for x in requested if x in supported],
              "requested_blocked": [x for x in requested if x not in supported],
              "meaning": "Support is conditional on the recorded reviews and explicitly admitted foundations; this is not formal kernel verification."}
    if check_freshness:
        result["freshness"] = freshness(store, state)
    return result
