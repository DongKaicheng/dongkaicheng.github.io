"""Read-only runtime capability checks; no source or tool installation."""
from __future__ import annotations

import ctypes
import importlib.util
from pathlib import Path
import platform
import shutil
import sqlite3
import subprocess
import sys

from . import __version__


def runtime_report() -> dict:
    """Report actual capabilities independently of whether a project exists."""
    checks = []
    python_ok = sys.version_info >= (3, 10)
    checks.append({"name": "python", "available": python_ok,
                   "version": platform.python_version(), "executable": sys.executable,
                   "purpose": "Run the maintenance engine; Python 3.10 or newer is required."})
    locks = importlib.util.find_spec("fcntl") is not None
    checks.append({"name": "local_writer_lock", "available": locks,
                   "purpose": "Serialize project writers using POSIX advisory locks."})
    try:
        with sqlite3.connect(":memory:") as connection:
            connection.execute("CREATE VIRTUAL TABLE capability_probe USING fts5(text)")
            connection.execute("INSERT INTO capability_probe VALUES (?)", ("mathematical source",))
            fts = connection.execute("SELECT count(*) FROM capability_probe WHERE capability_probe MATCH ?",
                                     ("mathematical",)).fetchone()[0] == 1
        fts_detail = None
    except sqlite3.Error as exc:
        fts, fts_detail = False, str(exc)
    checks.append({"name": "sqlite_fts5", "available": fts, "version": sqlite3.sqlite_version,
                   "detail": fts_detail, "purpose": "Build the disposable lexical search index."})
    try:
        atomic_export = sys.platform.startswith("linux") and getattr(ctypes.CDLL(None), "renameat2", None) is not None
    except (OSError, AttributeError):
        atomic_export = False
    checks.append({"name": "atomic_local_export", "available": atomic_export,
                   "purpose": "Install a new local HTML directory without overwriting a concurrent destination.",
                   "detail": "Linux renameat2 symbol detection; the filesystem operation is validated when exporting."})
    kpsewhich = shutil.which("kpsewhich")
    tex = []
    for engine in ("xelatex", "pdflatex", "lualatex"):
        executable = shutil.which(engine)
        format_path, format_error = None, None
        if executable and kpsewhich:
            try:
                result = subprocess.run([kpsewhich, engine + ".fmt"], capture_output=True,
                                        text=True, timeout=5, check=False)
                candidate = result.stdout.strip().splitlines()
                if result.returncode == 0 and candidate and Path(candidate[0]).is_file():
                    format_path = candidate[0]
                else:
                    format_error = "The engine is present but its format is not discoverable in the current TeX environment."
            except (OSError, UnicodeError, subprocess.TimeoutExpired) as exc:
                format_error = str(exc)
        elif executable:
            format_error = "kpsewhich is unavailable; format readiness was not checked."
        tex.append({"engine": engine, "executable": executable, "format": format_path,
                    "format_ready": bool(executable and format_path), "detail": format_error})
    return {"engine_version": __version__, "platform": platform.system(),
            "checks": checks, "latex": tex, "git_executable": shutil.which("git"),
            "core_ready": python_ok and locks,
            "search_ready": fts, "export_capability_detected": atomic_export,
            "latex_format_detected": any(row["format_ready"] for row in tex),
            "meaning": "These checks detect executable and library capabilities. Document compilation and mathematical review are separate operations."}
