"""Read a documented, non-executing subset of mathematical LaTeX.

The reader preserves the original mathematical text and records uncertainty.
It does not expand macros, evaluate arbitrary conditionals, execute TeX, or
decide that a reference is a valid mathematical application.  Locations are
one-based line numbers in the original UTF-8 file.
"""

from __future__ import annotations

from bisect import bisect_left, bisect_right
from dataclasses import dataclass, field
from hashlib import sha256
from pathlib import Path
import re
from typing import Iterable


_KINDS = {
    "theorem": "theorem", "thm": "theorem", "lemma": "lemma", "lem": "lemma",
    "proposition": "proposition", "prop": "proposition", "corollary": "corollary",
    "cor": "corollary", "definition": "definition", "defn": "definition",
    "example": "example", "examples": "example", "exercise": "exercise",
    "remark": "remark", "remarks": "remark", "situation": "situation",
    "convention": "convention", "conventions": "convention", "notation": "notation",
    "notations": "notation", "assumption": "assumption", "hypothesis": "assumption",
    "conjecture": "conjecture", "claim": "claim", "assertion": "claim",
}
_EQUATIONS = {
    "equation", "equation*", "align", "align*", "alignat", "alignat*",
    "gather", "gather*", "multline", "multline*", "eqnarray", "eqnarray*",
    "displaymath",
}
_LIST_ENVS = {"enumerate", "itemize", "description"}
_LITERAL_ENVS = {
    "verbatim", "verbatim*", "Verbatim", "BVerbatim", "LVerbatim", "lstlisting",
    "minted", "comment", "filecontents", "filecontents*",
}
_HEADINGS = {"part": 0, "chapter": 1, "section": 2, "subsection": 3,
             "subsubsection": 4, "paragraph": 5, "subparagraph": 6}
_REFS = {"ref", "eqref", "pageref", "autoref", "nameref", "cref", "Cref",
         "cpageref", "Cpageref", "vref", "Vref", "Vref*"}
_RANGE_REFS = {"crefrange", "Crefrange", "cpagerefrange", "Cpagerefrange",
               "vrefrange", "Vrefrange"}
_CITES = {"cite", "citep", "citet", "citealt", "citealp", "parencite",
          "textcite", "footcite", "autocite", "smartcite", "supercite",
          "citeauthor", "citeyear", "citeyearpar", "citenum", "citeurl",
          "citetalias", "citepalias", "nocite"}
_MULTI_CITES = {"cites", "parencites", "textcites", "footcites", "autocites",
                "smartcites", "supercites"}
_IGNORED_DIRS = {".git", ".hg", ".svn", "mpm", "build", "dist", "_build",
                 "node_modules", "venv", ".venv", "__pycache__"}
_ID_RE = re.compile(r"\bmpm:id\s*=\s*([A-Za-z0-9][A-Za-z0-9_.:-]*)")
_STRUCTURAL_RE = re.compile(r"\\(?:begin|end|section|subsection|chapter|input|include|label|ref|eqref|[cC]ref|[cC]refrange|autoref|hyperref)\b")
_CONTROL_RE = re.compile(r"\\([A-Za-z@]+|.)", re.DOTALL)
_INPUT_RE = re.compile(r"[^\s{}\\]+")


@dataclass
class _Command:
    name: str
    start: int
    end: int


@dataclass
class _Group:
    value: str
    start: int
    end: int


@dataclass
class _Label:
    value: str
    start: int
    end: int
    blocks: tuple[int, ...]


@dataclass
class _Reference:
    label: str
    command: str
    start: int
    blocks: tuple[int, ...]


@dataclass
class _Citation:
    key: str
    command: str
    notes: list[str]
    start: int
    end: int
    blocks: tuple[int, ...]


@dataclass
class _Block:
    name: str
    start: int
    content_start: int
    title: str
    title_start: int | None
    parent: int | None
    end_start: int = -1
    end: int = -1
    closed: bool = False


@dataclass
class _ListItem:
    start: int
    content_start: int
    title: str
    end: int = -1


@dataclass
class _Heading:
    level: int
    title: str
    start: int
    end: int
    starred: bool


@dataclass
class _Source:
    path: str
    text: str
    digest: str
    clean: str
    comments: list[tuple[int, int, str]]
    line_starts: list[int]
    blocks: list[_Block] = field(default_factory=list)
    labels: list[_Label] = field(default_factory=list)
    references: list[_Reference] = field(default_factory=list)
    citations: list[_Citation] = field(default_factory=list)
    headings: list[_Heading] = field(default_factory=list)
    labels_in_block: dict[int, list[_Label]] = field(default_factory=dict)
    references_in_block: dict[int, list[_Reference]] = field(default_factory=dict)
    proofs_in_block: dict[int, list[_Block]] = field(default_factory=dict)
    heading_starts: list[int] = field(default_factory=list)
    heading_contexts: list[list[str]] = field(default_factory=list)
    id_comments: list[tuple[int, int, str]] = field(default_factory=list)
    id_positions: list[int] = field(default_factory=list)
    list_items: dict[int, list[_ListItem]] = field(default_factory=dict)
    class_selectors: list[int] = field(default_factory=list)
    has_document_content: bool = False
    titles: list[tuple[int, int, str]] = field(default_factory=list)
    phantom_sections: list[tuple[int, int, tuple[int, ...]]] = field(default_factory=list)

    def line(self, position: int) -> int:
        return bisect_right(self.line_starts, max(0, position))


def _commands(text: str) -> Iterable[_Command]:
    pos = 0
    while pos < len(text):
        if text[pos] != "\\":
            pos += 1
            continue
        start = pos
        pos += 1
        if pos >= len(text):
            yield _Command("", start, pos)
            break
        if text[pos].isalpha() or text[pos] == "@":
            pos += 1
            while pos < len(text) and (text[pos].isalpha() or text[pos] == "@"):
                pos += 1
        else:
            pos += 1
        yield _Command(text[start + 1:pos], start, pos)


def _space(text: str, pos: int) -> int:
    while pos < len(text) and text[pos].isspace():
        pos += 1
    return pos


def _group(text: str, pos: int, opener: str = "{") -> _Group | None:
    pos = _space(text, pos)
    if pos >= len(text) or text[pos] != opener:
        return None
    closer = "}" if opener == "{" else "]"
    start, depth, braces = pos, 1, 0
    pos += 1
    while pos < len(text):
        char = text[pos]
        if char == "\\":
            # Escaped punctuation is not a delimiter.  A control word does not
            # consume its arguments, which may contain balanced groups.
            pos += 2
            continue
        if opener == "[":
            if char == "{":
                braces += 1
            elif char == "}" and braces:
                braces -= 1
            elif not braces and char == opener:
                depth += 1
            elif not braces and char == closer:
                depth -= 1
        else:
            if char == opener:
                depth += 1
            elif char == closer:
                depth -= 1
        if not depth:
            return _Group(text[start + 1:pos], start, pos + 1)
        pos += 1
    return None


def _blank(chars: list[str], start: int, end: int) -> None:
    for pos in range(start, min(end, len(chars))):
        if chars[pos] not in "\r\n":
            chars[pos] = " "


def _mask_literals(text: str, path: str, report) -> tuple[str, list[tuple[int, int, str]]]:
    chars = list(text)
    comments: list[tuple[int, int, str]] = []
    pos = 0
    while pos < len(text):
        if text[pos] == "%":
            end = text.find("\n", pos)
            if end < 0:
                end = len(text)
            comments.append((pos, end, text[pos + 1:end]))
            _blank(chars, pos, end)
            pos = end
            continue
        if text[pos] != "\\":
            pos += 1
            continue
        match = _CONTROL_RE.match(text, pos)
        if not match:
            break
        name, end = match.group(1), match.end()
        if name in {"verb", "Verb"}:
            if end < len(text) and text[end] == "*":
                end += 1
            if end >= len(text) or text[end] in "\r\n":
                report("malformed_verbatim", "error", "Inline verbatim has no delimiter.", path, pos)
                pos = end
                continue
            delimiter = text[end]
            stop = text.find(delimiter, end + 1)
            newline = text.find("\n", end + 1)
            if stop < 0 or (newline >= 0 and newline < stop):
                stop = newline if newline >= 0 else len(text)
                report("unterminated_verbatim", "error", "Inline verbatim is not terminated on its line.", path, pos)
            else:
                stop += 1
            _blank(chars, pos, stop)
            pos = stop
            continue
        if name == "begin":
            arg = _group(text, end)
            if arg and arg.value.strip() in _LITERAL_ENVS:
                env = arg.value.strip()
                closing = re.compile(r"\\end\s*\{\s*" + re.escape(env) + r"\s*\}")
                stop_match = closing.search(text, arg.end)
                stop = stop_match.end() if stop_match else len(text)
                if not stop_match:
                    report("unterminated_literal_environment", "error", f"Literal environment {env!r} is not closed.", path, pos)
                _blank(chars, pos, stop)
                pos = stop
                continue
        if name in {"url", "nolinkurl", "path", "detokenize"}:
            arg = _group(text, end)
            if arg:
                _blank(chars, pos, arg.end)
                pos = arg.end
                continue
        if name == "href":
            arg = _group(text, end)
            if arg:
                _blank(chars, arg.start, arg.end)
                pos = arg.end
                continue
        # In particular, \% and \\ consume the escaped character before it
        # can be mistaken for a comment or a second command.
        pos = end
    return "".join(chars), comments


def _mask_definitions(source: _Source, report) -> str:
    text = source.clean
    chars = list(text)
    consumed = -1
    command_defs = {"newcommand", "renewcommand", "providecommand", "DeclareRobustCommand"}
    env_defs = {"newenvironment", "renewenvironment", "provideenvironment"}
    document_command_defs = {"NewDocumentCommand", "RenewDocumentCommand", "ProvideDocumentCommand", "DeclareDocumentCommand"}
    document_env_defs = {"NewDocumentEnvironment", "RenewDocumentEnvironment", "ProvideDocumentEnvironment", "DeclareDocumentEnvironment"}
    for command in _commands(text):
        if command.start < consumed:
            continue
        name, pos = command.name, command.end
        if name not in command_defs | env_defs | document_command_defs | document_env_defs | {"def", "gdef", "edef", "xdef", "DeclareMathOperator"}:
            continue
        if pos < len(text) and text[pos] == "*":
            pos += 1
        pos = _space(text, pos)
        first = _group(text, pos)
        if first:
            pos = first.end
        elif name not in env_defs | document_env_defs:
            cm = _CONTROL_RE.match(text, pos)
            if not cm:
                report("malformed_macro_definition", "error", f"Cannot read \\{name} declaration.", source.path, command.start)
                continue
            pos = cm.end()
        else:
            report("malformed_macro_definition", "error", f"Cannot read \\{name} declaration.", source.path, command.start)
            continue
        bodies: list[_Group] = []
        if name in {"def", "gdef", "edef", "xdef"}:
            # The parameter text before the replacement body is not executed.
            while pos < len(text) and text[pos] != "{":
                if text[pos] == "\\":
                    pos += 1
                pos += 1
            body = _group(text, pos)
            if body:
                bodies.append(body)
                pos = body.end
        elif name in document_command_defs | document_env_defs:
            signature = _group(text, pos)
            if signature:
                pos = signature.end
                for _ in range(2 if name in document_env_defs else 1):
                    body = _group(text, pos)
                    if not body:
                        break
                    bodies.append(body)
                    pos = body.end
        else:
            for _ in range(2):
                optional = _group(text, pos, "[")
                if optional:
                    pos = optional.end
            for _ in range(2 if name in env_defs else 1):
                body = _group(text, pos)
                if not body:
                    break
                bodies.append(body)
                pos = body.end
        expected = 2 if name in env_defs | document_env_defs else 1
        if len(bodies) != expected:
            report("malformed_macro_definition", "error", f"Incomplete \\{name} declaration; its extent is uncertain.", source.path, command.start)
            # Avoid continuing to identify results inside an incomplete body.
            _blank(chars, command.start, len(chars))
            break
        if any(_STRUCTURAL_RE.search(body.value) for body in bodies):
            report("structural_macro_not_expanded", "error", f"\\{name} contains document structure; expand it explicitly before relying on this import.", source.path, command.start)
        _blank(chars, command.start, pos)
        consumed = pos
    return "".join(chars)


def _mask_after_endinput(text: str) -> str:
    """Honor the literal file terminator after comments/macros were masked."""
    for command in _commands(text):
        if command.name == "endinput":
            # TeX has already buffered the rest of the current line.
            end = text.find("\n", command.end)
            if end < 0:
                return text
            return text[:end] + re.sub(r"[^\r\n]", " ", text[end:])
    return text


def _class_selector_end(text: str, command: _Command) -> int | None:
    """Recognize only a literal two-class selector, without consulting files.

    Each branch must consist of one literal documentclass declaration.
    Its class contents remain unread and unevaluated, just as for an ordinary
    documentclass command.  Unknown commands, math, nested selectors, and
    extra material fail this syntactic recognition.
    """
    if command.name != "IfFileExists":
        return None
    filename = _group(text, command.end)
    if not filename or not re.fullmatch(r"[A-Za-z0-9_./-]+\.cls", filename.value.strip()):
        return None
    branches = []
    pos = filename.end
    for _ in range(2):
        branch = _group(text, pos)
        if branch is None:
            return None
        branches.append(branch.value)
        pos = branch.end
    for branch in branches:
        start = _space(branch, 0)
        declaration = _CONTROL_RE.match(branch, start)
        if not declaration or declaration.group(1) != "documentclass":
            return None
        tail = declaration.end()
        options = _group(branch, tail, "[")
        if options:
            if not re.fullmatch(r"[A-Za-z0-9_,=.+/:\s-]*", options.value):
                return None
            tail = options.end
        name = _group(branch, tail)
        if not name or not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.-]*", name.value.strip()):
            return None
        if _space(branch, name.end) != len(branch):
            return None
    return pos


def _newtheorems(source: _Source, envs: dict[str, str], report) -> str:
    text, chars = source.clean, list(source.clean)
    consumed = -1
    for command in _commands(text):
        if command.start < consumed or command.name != "newtheorem":
            continue
        pos = command.end
        if pos < len(text) and text[pos] == "*":
            pos += 1
        env_arg = _group(text, pos)
        if not env_arg:
            report("malformed_newtheorem", "error", "A newtheorem environment name is missing.", source.path, command.start)
            continue
        env = env_arg.value.strip()
        pos = env_arg.end
        counter = _group(text, pos, "[")
        if counter:
            pos = counter.end
        display = _group(text, pos)
        if not display or not re.fullmatch(r"[A-Za-z][A-Za-z0-9@*_-]*", env):
            report("malformed_newtheorem", "error", "A newtheorem declaration has unsupported arguments.", source.path, command.start)
            continue
        pos = display.end
        counter = _group(text, pos, "[")
        if counter:
            pos = counter.end
        visible = re.sub(r"[^A-Za-z]", "", display.value).lower()
        kind = _KINDS.get(visible, _KINDS.get(env.rstrip("*"), "theorem"))
        if env in envs and envs[env] != kind:
            report("conflicting_environment_definition", "error", f"Environment {env!r} has conflicting classifications.", source.path, command.start)
        else:
            envs[env] = kind
        _blank(chars, command.start, pos)
        consumed = pos
    return "".join(chars)


def _literal_filename(value: str) -> bool:
    return bool(value.strip()) and not re.search(r"[\\#{}$\x00\r\n]", value)


def _is_contained(path: Path, root: Path) -> bool:
    try:
        path.relative_to(root)
        return True
    except ValueError:
        return False


def _path_probe(path: Path, root: Path) -> dict:
    """Describe a path without opening it or permitting an escaping target."""
    try:
        resolved = path.resolve()
        if not _is_contained(resolved, root):
            return {"resolved": None, "status": "outside_root"}
        relative = resolved.relative_to(root).as_posix()
        kind = "file" if resolved.is_file() else "directory" if resolved.is_dir() else "missing"
        return {"resolved": relative, "status": kind}
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        return {"resolved": None, "status": "unresolvable", "error": type(exc).__name__}


def _file_lookup(root: Path, value, from_path=None) -> dict:
    """Use exactly the reader's root-first, extensionless-first resolution."""
    record = {"value": value, "from_path": from_path, "selected": None, "status": "invalid"}
    if not isinstance(value, str) or not _literal_filename(value):
        return record
    if from_path is not None and (not isinstance(from_path, str) or not _literal_filename(from_path)):
        return record
    name = Path(value.strip())
    bases = [root] if name.is_absolute() or from_path is None else [root, (root / from_path).parent]
    statuses, errors = [], []
    for base in bases:
        initial = name if name.is_absolute() else base / name
        try:
            alternatives = [initial] if initial.suffix else [initial, initial.with_suffix(".tex")]
        except ValueError:
            alternatives = [initial]
        for candidate in alternatives:
            probe = _path_probe(candidate, root)
            statuses.append(probe["status"])
            if probe["status"] == "file" and record["selected"] is None:
                record["selected"] = probe["resolved"]
            if probe["status"] == "unresolvable":
                try:
                    spelling = candidate.relative_to(root).as_posix()
                except ValueError:
                    spelling = candidate.as_posix()
                errors.append({"path": spelling, "error": probe["error"]})
    if record["selected"] is not None:
        record["status"] = "resolved"
    elif statuses and all(status == "outside_root" for status in statuses):
        record["status"] = "outside_root"
    elif errors:
        record["status"] = "unresolvable"
    else:
        record["status"] = "missing"
    if errors:
        record["errors"] = errors
    return record


def _discover_paths(root: Path, source_roots: list[str] | None) -> tuple[list[dict], list[dict]]:
    """Capture the discovery decisions that can alter a source-root import."""
    values = source_roots if source_roots is not None else (["content"] if (root / "content").is_dir() else ["."])
    roots, discovered = [], {}
    for value in values:
        if not isinstance(value, str) or not _literal_filename(value):
            roots.append({"value": value, "resolved": None, "status": "invalid"})
            continue
        probe = _path_probe(root / value, root)
        descriptor = {"value": value, **probe}
        roots.append(descriptor)
        if probe["status"] not in {"file", "directory"}:
            continue
        path = root / probe["resolved"]
        if probe["status"] == "file":
            candidates = [path]
        else:
            try:
                candidates = [candidate for candidate in path.rglob("*.tex")
                              if not any(p in _IGNORED_DIRS or p.startswith(".")
                                         for p in candidate.relative_to(path).parts[:-1])]
            except (OSError, RuntimeError, ValueError) as exc:
                descriptor["status"] = "discovery_error"
                descriptor["error"] = type(exc).__name__
                continue
        for candidate in candidates:
            spelling = candidate.relative_to(root).as_posix()
            discovered[spelling] = {"path": spelling, **_path_probe(candidate, root)}
    return roots, [discovered[key] for key in sorted(discovered)]


def source_layout(root: Path, *, entrypoints: list[str] | None = None,
                  source_roots: list[str] | None = None, lookups: list[dict] | None = None) -> dict:
    """Recheck source membership and literal lookup choices without parsing TeX.

    Supply the previous parse's ``source_layout['lookups']``. Only ``value``
    and ``from_path`` from those rows are used; saved resolution results are
    never trusted. Entrypoint lookups are also derived from the current
    configuration. In entrypoint mode unrelated files are deliberately not
    discovered. Callers must separately compare the raw hashes of loaded
    sources, because this function does not read mathematical content.
    """
    result = {"schema_version": 1, "mode": "entrypoints" if entrypoints is not None else "source_roots",
              "root_status": "directory", "roots": [], "discovered": [], "lookups": []}
    try:
        root = Path(root).expanduser().resolve()
        if not root.is_dir():
            result["root_status"] = "missing"
            return result
    except (OSError, RuntimeError, TypeError, ValueError) as exc:
        result["root_status"] = "unresolvable"
        result["error"] = type(exc).__name__
        return result
    if entrypoints is None:
        result["roots"], result["discovered"] = _discover_paths(root, source_roots)
    specs = [{"value": value, "from_path": None} for value in (entrypoints or [])]
    specs.extend(lookups or [])
    unique = {}
    for spec in specs:
        if not isinstance(spec, dict):
            result.setdefault("errors", []).append("invalid_lookup_record")
            continue
        value, from_path = spec.get("value"), spec.get("from_path")
        # Well-formed parser output contains strings. Keep malformed saved
        # metadata deterministic and visibly invalid instead of executing it.
        if not isinstance(value, str) or (from_path is not None and not isinstance(from_path, str)):
            result.setdefault("errors", []).append("invalid_lookup_record")
            continue
        unique[(value, from_path)] = _file_lookup(root, value, from_path)
    result["lookups"] = [unique[key] for key in sorted(unique, key=lambda pair: (pair[1] or "", pair[0]))]
    return result


def _scan_source(source: _Source, envs: dict[str, str], report) -> None:
    text = source.clean
    stack: list[int] = []
    consumed_label = -1
    citation_key_spans: list[tuple[int, int]] = []
    brace_position = brace_depth = 0
    for command in _commands(text):
        gap = text[brace_position:command.start]
        brace_depth += gap.count("{") - gap.count("}")
        brace_position = command.end
        name, pos = command.name, command.end
        if name in {"begin", "end"}:
            arg = _group(text, pos)
            if not arg or not _literal_filename(arg.value):
                report("malformed_environment", "error", f"Cannot read literal environment for \\{name}.", source.path, command.start)
                continue
            env = arg.value.strip()
            if name == "begin":
                start = arg.end
                title, title_start = "", None
                if env in envs or env.rstrip("*") in envs or env.rstrip("*") == "proof":
                    optional = _group(text, start, "[")
                    if optional:
                        title, title_start, start = optional.value, optional.start + 1, optional.end
                source.blocks.append(_Block(env, command.start, start, title, title_start, stack[-1] if stack else None))
                stack.append(len(source.blocks) - 1)
            else:
                candidates = [i for i in stack if source.blocks[i].name == env]
                if not candidates:
                    report("unmatched_environment_end", "error", f"No matching beginning for {env!r}.", source.path, command.start)
                    continue
                if source.blocks[stack[-1]].name != env:
                    report("mismatched_environment_end", "error", f"Closing {env!r} while another environment remains open.", source.path, command.start)
                while stack:
                    index = stack.pop()
                    source.blocks[index].end_start = command.start
                    source.blocks[index].end = arg.end
                    source.blocks[index].closed = source.blocks[index].name == env
                    if source.blocks[index].name == env:
                        break
        elif name == "item" and stack and source.blocks[stack[-1]].name in _LIST_ENVS:
            optional = _group(text, pos, "[")
            source.list_items.setdefault(stack[-1], []).append(_ListItem(
                command.start, optional.end if optional else pos, optional.value if optional else ""))
        elif name == "label":
            if command.start < consumed_label:
                continue
            arg = _group(text, pos)
            if not arg or not arg.value.strip() or re.search(r"[{}\\#$\r\n]", arg.value):
                report("malformed_label", "error", "Label must have a nonempty literal argument.", source.path, command.start)
                continue
            label = _Label(arg.value.strip(), command.start, arg.end, tuple(stack))
            source.labels.append(label)
            for index in stack:
                source.labels_in_block.setdefault(index, []).append(label)
            consumed_label = arg.end
        elif name in _REFS | _RANGE_REFS | {"hyperref"}:
            if pos < len(text) and text[pos] == "*":
                pos += 1
            if name == "hyperref":
                arg = _group(text, pos, "[")
                if not arg:
                    # The four-argument hyperref form is a different interface.
                    report("unsupported_hyperref", "warning", "Only the optional-label form of hyperref is indexed.", source.path, command.start)
                    continue
                args = [arg]
            else:
                args = []
                for _ in range(2 if name in _RANGE_REFS else 1):
                    arg = _group(text, pos)
                    if not arg:
                        report("malformed_reference", "error", f"Cannot read \\{name} label argument.", source.path, command.start)
                        break
                    args.append(arg)
                    pos = arg.end
            for arg in args:
                values = arg.value.split(",") if name in {"cref", "Cref", "cpageref", "Cpageref"} else [arg.value]
                for value in values:
                    label = value.strip()
                    if label and not re.search(r"[{}\\#$\r\n]", label):
                        reference = _Reference(label, name, command.start, tuple(stack))
                        source.references.append(reference)
                        for index in stack:
                            source.references_in_block.setdefault(index, []).append(reference)
                    else:
                        report("dynamic_reference", "warning", "A reference label could not be read literally.", source.path, command.start)
        elif name.casefold() in _CITES:
            # Citation-key arguments are identifiers, not nested citations to
            # execute. Optional notes remain readable source text and may
            # contain an independently visible citation of their own.
            citation_key_spans[:] = [(start, end) for start, end in citation_key_spans if end > command.start]
            if any(start <= command.start < end for start, end in citation_key_spans):
                continue
            star_pos = _space(text, pos)
            starred = star_pos < len(text) and text[star_pos] == "*"
            if starred:
                pos = star_pos + 1
            notes = []
            malformed = False
            for _ in range(2):
                offset = _space(text, pos)
                if offset >= len(text) or text[offset] != "[":
                    break
                note = _group(text, offset, "[")
                if note is None:
                    report("malformed_citation", "error", f"Citation \\{name} has an unclosed optional argument.", source.path, command.start)
                    malformed = True
                    break
                notes.append(source.text[note.start + 1:note.end - 1])
                pos = note.end
            if malformed:
                continue
            if name.casefold() == "nocite" and (starred or notes):
                report("unsupported_citation_arguments", "error", "The supported bibliography-listing form is \\nocite{keys}, without a star or optional notes.", source.path, command.start)
                continue
            offset = _space(text, pos)
            if offset < len(text) and text[offset] == "[":
                report("unsupported_citation_arguments", "error", f"Citation \\{name} has more than two optional arguments; use a supported explicit citation form.", source.path, command.start)
                continue
            arg = _group(text, pos)
            if arg is None:
                report("malformed_citation", "error", f"Cannot read the literal bibliography-key argument of \\{name}.", source.path, command.start)
                continue
            citation_key_spans.append((arg.start, arg.end))
            for value in arg.value.split(","):
                key = value.strip()
                if not key:
                    report("malformed_citation", "error", f"Citation \\{name} contains an empty bibliography key.", source.path, command.start)
                elif (re.search(r"[{}\\#$%&~^\s]", key)
                      or ("*" in key and not (name.casefold() == "nocite" and key == "*"))):
                    report("dynamic_citation", "error", f"A bibliography key in \\{name} is not a supported literal identifier.", source.path, command.start)
                else:
                    source.citations.append(_Citation(key, name + ("*" if starred else ""),
                                                     list(notes), command.start, arg.end, tuple(stack)))
        elif name.casefold() in _MULTI_CITES:
            report("unsupported_multicite", "error", f"Multi-citation command \\{name} needs an explicit adapter; use separate supported citation commands.", source.path, command.start)
        elif name == "title" and brace_depth == 0 and not any(source.blocks[i].name != "document" for i in stack):
            arg = _group(text, pos)
            if arg:
                source.titles.append((command.start, arg.end, arg.value))
        elif name == "phantomsection" and brace_depth == 0:
            source.phantom_sections.append((command.start, command.end, tuple(stack)))
        elif name in _HEADINGS:
            starred = pos < len(text) and text[pos] == "*"
            if starred:
                pos += 1
            optional = _group(text, pos, "[")
            if optional:
                pos = optional.end
            arg = _group(text, pos)
            if not arg:
                report("malformed_heading", "error", f"Cannot read \\{name} title.", source.path, command.start)
            elif any(source.blocks[i].name != "document" for i in stack):
                report("nested_heading", "warning", "A heading inside an environment is not used to infer global structure.", source.path, command.start)
            else:
                source.headings.append(_Heading(_HEADINGS[name], arg.value, command.start, arg.end, starred))
        elif name == "includeonly":
            report("includeonly_not_evaluated", "error", "includeonly changes document membership; provide explicit entrypoints instead.", source.path, command.start)
        elif name in {"input", "include"} and any(source.blocks[i].name != "document" for i in stack):
            report("include_inside_environment", "error", "An include inherits environment scope; split-file mathematical items require an explicit adapter.", source.path, command.start)
        elif (name.casefold().startswith("if") and name != "iff") or name in {"InputIfFileExists", "@ifundefined"}:
            report("conditional_tex_not_evaluated", "error", "Conditional TeX is not evaluated; branches may contain inactive structure.", source.path, command.start)
        elif name in {"catcode", "csname", "expandafter", "scantokens", "directlua"}:
            report("dynamic_tex_not_evaluated", "warning", f"\\{name} may affect document structure and is not executed.", source.path, command.start)
    for index in stack:
        block = source.blocks[index]
        block.end_start = block.end = len(text)
        report("unclosed_environment", "error", f"Environment {block.name!r} is not closed.", source.path, block.start)
    for index, entries in source.list_items.items():
        for number, entry in enumerate(entries):
            entry.end = entries[number + 1].start if number + 1 < len(entries) else source.blocks[index].end_start
    for block in source.blocks:
        if block.name.rstrip("*") != "proof":
            continue
        parent = block.parent
        while parent is not None:
            source.proofs_in_block.setdefault(parent, []).append(block)
            parent = source.blocks[parent].parent
    current: dict[int, str] = {}
    for heading in source.headings:
        current = {level: title for level, title in current.items() if level < heading.level}
        current[heading.level] = heading.title
        source.heading_starts.append(heading.start)
        source.heading_contexts.append([current[level] for level in sorted(current)])
    source.id_comments = [(a, b, text) for a, b, text in source.comments if _ID_RE.search(text)]
    source.id_positions = [a for a, _, _ in source.id_comments]


def _without_spans(text: str, start: int, end: int, spans: Iterable[tuple[int, int]]) -> str:
    ranges = sorted((max(start, a), min(end, b)) for a, b in spans if a < end and b > start)
    output, pos = [], start
    for a, b in ranges:
        if b <= pos:
            continue
        output.append(text[pos:max(pos, a)])
        output.append("\n" * text[max(pos, a):b].count("\n"))
        pos = b
    output.append(text[pos:end])
    return "".join(output).strip()


def parse_project(root: Path, entrypoints: list[str] | None = None,
                  source_roots: list[str] | None = None) -> dict:
    """Return source-addressable items, files, and explicit import diagnostics.

    With entrypoints, follow only their literal ``input`` / ``include`` links.
    Otherwise discover ``.tex`` files under source_roots (default ``content``
    if present, otherwise the project root).  Includes resolve as normal
    root-relative TeX inputs, then as an including-file-relative fallback.
    Symlinks and ``..`` may not escape the resolved project root.
    """
    diagnostics: list[dict] = []
    sources: dict[str, _Source] = {}
    order: list[str] = []

    def report(code, severity, message, path, position=0, *, line=None):
        if line is None:
            if path in sources:
                line = sources[path].line(position)
            else:
                line = 1
        diagnostics.append({"code": code, "severity": severity, "message": message,
                            "path": path, "line": line})

    try:
        root = Path(root).expanduser().resolve()
    except (OSError, RuntimeError, TypeError, ValueError):
        report("invalid_root", "error", "Project root cannot be resolved as a filesystem directory.", ".")
        return {"items": [], "files": [], "diagnostics": diagnostics,
                "source_layout": source_layout(root, entrypoints=entrypoints, source_roots=source_roots)}
    if not root.is_dir():
        report("invalid_root", "error", "Project root is not an existing directory.", ".")
        return {"items": [], "files": [], "diagnostics": diagnostics,
                "source_layout": source_layout(root, entrypoints=entrypoints, source_roots=source_roots)}

    layout = {"schema_version": 1, "mode": "entrypoints" if entrypoints is not None else "source_roots",
              "root_status": "directory", "roots": [], "discovered": [], "lookups": []}
    lookup_records = {}

    def resolve_path(path: Path, origin=".", position=0) -> Path | None:
        try:
            return path.resolve()
        except (OSError, RuntimeError, ValueError) as exc:
            report("unresolvable_path", "error", f"Cannot resolve a source path: {type(exc).__name__}.", origin, position)
            return None

    def resolve_file(value: str, from_path: str | None = None) -> Path | None:
        record = _file_lookup(root, value, from_path)
        prior = lookup_records.get((value, from_path))
        if prior is not None and prior != record:
            report("source_layout_changed_during_parse", "error", "A repeated literal lookup resolved differently during parsing; import again from stable sources.", from_path or ".")
        lookup_records[(value, from_path)] = record
        for error in record.get("errors", []):
            report("unresolvable_path", "error", f"Cannot resolve a source path: {error['error']}.", from_path or ".")
        return root / record["selected"] if record["selected"] is not None else None

    def load(path: Path, active: tuple[str, ...] = (), origin: str | None = None,
             position=0, *, class_selector_allowed=True) -> bool:
        resolved = resolve_path(path, origin or ".", position)
        if resolved is None:
            return True
        if not _is_contained(resolved, root):
            report("path_outside_root", "error", "A source path resolves outside the project root.", origin or ".", position)
            return True
        rel = resolved.relative_to(root).as_posix()
        if rel in active:
            report("include_cycle", "error", "Include cycle: " + " -> ".join((*active, rel)), origin or rel, position)
            return True
        if len(active) >= 128:
            report("include_depth_limit", "error", "Include nesting exceeds the supported depth of 128.", origin or rel, position)
            return True
        if rel in sources:
            if origin is not None:
                report("repeated_include", "warning", f"Source {rel!r} is included more than once; it is indexed once.", origin, position)
            if not class_selector_allowed and sources[rel].class_selectors:
                report("class_selector_after_document_content", "error", "A class-selector source is included after document content; its conditional is not safely a preamble declaration.", origin or rel, position)
            return sources[rel].has_document_content
        try:
            raw = resolved.read_bytes()
            # Keep a UTF-8 BOM as U+FEFF so archived text can reconstruct the
            # exact bytes whose digest is recorded.  The scanner treats it as
            # ordinary non-command text outside mathematical environments.
            text = raw.decode("utf-8")
        except (OSError, UnicodeError) as exc:
            report("unreadable_source", "error", f"Cannot read UTF-8 source: {type(exc).__name__}.", origin or rel, position)
            return True
        if "\x00" in text:
            report("binary_source", "error", "Source contains NUL bytes.", rel)
            return True
        source = _Source(rel, text, sha256(raw).hexdigest(), "", [], [0] + [m.end() for m in re.finditer("\n", text)])
        sources[rel] = source
        order.append(rel)
        source.clean, source.comments = _mask_literals(text, rel, report)
        source.clean = _mask_definitions(source, report)
        source.clean = _mask_after_endinput(source.clean)
        chars = list(source.clean)
        preamble = class_selector_allowed
        consumed = -1
        for command in _commands(source.clean):
            if command.start < consumed:
                continue
            if preamble and (selector_end := _class_selector_end(source.clean, command)) is not None:
                _blank(chars, command.start, selector_end)
                source.class_selectors.append(command.start)
                consumed = selector_end
                report("presentation_class_selector", "info", "Both literal branches contain only a documentclass declaration; class contents are not read or evaluated, and no branch is executed.", rel, command.start)
                continue
            if command.name == "begin" or command.name in _HEADINGS or command.name in {"[", "("}:
                preamble = False
                source.has_document_content = True
            if command.name not in {"input", "include"}:
                continue
            arg = _group(source.clean, command.end)
            if arg:
                value = arg.value
            elif command.name == "input":
                start = _space(source.clean, command.end)
                match = _INPUT_RE.match(source.clean, start)
                value = match.group(0) if match else ""
            else:
                value = ""
            if not _literal_filename(value):
                report("dynamic_include", "error", "Only literal input/include filenames are supported.", rel, command.start)
                continue
            # Capture every literal lookup at the time it is used. Recomputing
            # only after parsing could hide a resolution race from the caller.
            child = resolve_file(value, rel)
            # Distinguish an explicitly escaping path from a missing input.
            requested = Path(value.strip())
            attempt = requested if requested.is_absolute() else root / requested
            root_attempt = resolve_path(attempt, rel, command.start)
            relative_attempt = resolve_path(resolved.parent / requested, rel, command.start)
            if root_attempt is None or relative_attempt is None:
                continue
            if not _is_contained(root_attempt, root) and not _is_contained(relative_attempt, root):
                report("path_outside_root", "error", "An include resolves outside the project root.", rel, command.start)
                continue
            if child is None:
                report("missing_include", "error", f"Literal include {value.strip()!r} could not be found within the root.", rel, command.start)
                continue
            if load(child, (*active, rel), rel, command.start, class_selector_allowed=preamble):
                preamble = False
                source.has_document_content = True
        source.clean = "".join(chars)
        return source.has_document_content

    if entrypoints is not None:
        for entry in entrypoints:
            if not isinstance(entry, str):
                layout.setdefault("errors", []).append("invalid_lookup_record")
                report("invalid_entrypoint", "error", "Entrypoints must be literal path strings.", ".")
                continue
            if not _literal_filename(entry):
                resolve_file(entry)
                report("invalid_entrypoint", "error", "Entrypoints must be literal path strings.", ".")
                continue
            path = resolve_file(entry)
            if path is None:
                attempt = resolve_path(root / entry)
                if attempt is None:
                    continue
                code = "path_outside_root" if not _is_contained(attempt, root) else "missing_entrypoint"
                report(code, "error", f"Entrypoint {entry!r} could not be read within the root.", ".")
                continue
            load(path)
    else:
        layout["roots"], layout["discovered"] = _discover_paths(root, source_roots)
        for descriptor in layout["roots"]:
            directory, status = descriptor["value"], descriptor["status"]
            if status == "invalid":
                report("invalid_source_root", "error", "Source roots must be literal path strings.", ".")
            elif status == "outside_root":
                report("path_outside_root", "error", "A source root resolves outside the project root.", directory)
            elif status in {"unresolvable", "discovery_error"}:
                report("unresolvable_path", "error", f"Cannot discover a source root: {descriptor.get('error', 'filesystem error')}.", directory)
            elif status == "missing":
                report("missing_source_root", "error", f"Source root {directory!r} does not exist.", directory)
        for descriptor in layout["discovered"]:
            load(root / descriptor["path"])
    if not sources:
        report("no_sources", "warning", "No readable LaTeX source files were found.", ".")

    envs = dict(_KINDS)
    for path in order:
        source = sources[path]
        source.clean = _newtheorems(source, envs, report)
    for path in order:
        _scan_source(sources[path], envs, report)

    items: list[dict] = []
    item_blocks: dict[tuple[str, int], dict] = {}
    item_headings: dict[tuple[str, int], dict] = {}
    fragments: dict[str, list[tuple[int, int, dict]]] = {}
    label_owners: dict[tuple[str, str], list[dict]] = {}
    pending_proofs: list[tuple[_Source, int]] = []
    consumed_labels: set[tuple[str, int]] = set()

    def source_loc(source, start, end):
        return {"path": source.path, "start_line": source.line(start), "end_line": source.line(max(start, end - 1))}

    def exact_span(source, start, end):
        # Character offsets are zero-based Unicode positions, end exclusive;
        # line numbers retain the public one-based source-location convention.
        return {**source_loc(source, start, end), "start_char": start, "end_char": end}

    def sections_at(source, position):
        index = bisect_left(source.heading_starts, position) - 1
        return list(source.heading_contexts[index]) if index >= 0 else []

    def add_owner(source, label, item):
        owners = label_owners.setdefault((source.path, label.value), [])
        if item not in owners:
            owners.append(item)
        if label.value not in item["label_aliases"]:
            item["label_aliases"].append(label.value)
        consumed_labels.add((source.path, label.start))

    def metadata(source, start, end):
        values = []
        left, right = bisect_left(source.id_positions, start), bisect_left(source.id_positions, end)
        for a, b, text in source.id_comments[left:right]:
            values.extend(match.group(1) for match in _ID_RE.finditer(text))
        values = sorted(set(values))
        if len(values) > 1:
            report("conflicting_explicit_ids", "error", "A mathematical item declares multiple permanent IDs.", source.path, start)
            return None
        return values[0] if values else None

    for path in order:
        source = sources[path]
        for i, block in enumerate(source.blocks):
            base = block.name.rstrip("*")
            kind = envs.get(block.name, envs.get(base))
            if base == "proof":
                pending_proofs.append((source, i))
                continue
            if kind is None and block.name not in _EQUATIONS:
                continue
            ancestors = []
            parent = block.parent
            while parent is not None:
                ancestors.append(parent)
                parent = source.blocks[parent].parent
            enclosed = any(source.blocks[a].name.rstrip("*") == "proof" or source.blocks[a].name in envs or source.blocks[a].name.rstrip("*") in envs for a in ancestors)
            if enclosed:
                if kind:
                    report("nested_result_requires_context", "error", "A nested result is kept within its enclosing text; its local hypotheses require explicit treatment.", path, block.start)
                continue
            labels = source.labels_in_block.get(i, [])
            direct = [label for label in labels if label.blocks and label.blocks[-1] == i]
            if kind is None:
                kind = "equation"
                if not labels:
                    continue
                direct = labels
            primary = direct[0] if direct else None
            if primary is None:
                report("missing_label", "warning", f"A {kind} has no direct label; its provisional identity may change when edited.", path, block.start)
            label = primary.value if primary else None
            key = path + "::" + (label or f"@unlabelled-{source.line(block.start)}-{block.start}-{kind}")
            children_proofs = source.proofs_in_block.get(i, [])
            removal = [(label.start, label.end) for label in labels]
            id_left = bisect_left(source.id_positions, block.content_start)
            id_right = bisect_left(source.id_positions, block.end_start)
            removal += [(a, b) for a, b, _ in source.id_comments[id_left:id_right]]
            removal += [(b.start, b.end) for b in children_proofs]
            item = {"key": key, "label": label, "label_aliases": [], "kind": kind,
                    "title": block.title, "statement": _without_spans(source.text, block.content_start, block.end_start, removal),
                    "proofs": [], "references": [], "source": source_loc(source, block.start, block.end),
                    "explicit_id": metadata(source, block.content_start, block.end_start),
                    "section": sections_at(source, block.start)}
            items.append(item)
            item_blocks[(path, i)] = item
            for nested_label in labels:
                add_owner(source, nested_label, item)
        boundaries = sorted(source.heading_starts + [b.start for b in source.blocks
                            if b.name in envs or b.name.rstrip("*") in envs or b.name in _EQUATIONS or b.name.rstrip("*") == "proof"])
        label_positions = [label.start for label in source.labels]
        for i, heading in enumerate(source.headings):
            boundary = bisect_right(boundaries, heading.start)
            end = boundaries[boundary] if boundary < len(boundaries) else len(source.text)
            left, right = bisect_left(label_positions, heading.end), bisect_left(label_positions, end)
            labels = [label for label in source.labels[left:right] if (path, label.start) not in consumed_labels
                      and not any(source.blocks[b].name != "document" for b in label.blocks)]
            if not labels:
                continue
            primary = labels[0]
            item = {"key": path + "::" + primary.value, "label": primary.value, "label_aliases": [],
                    "kind": "section", "title": heading.title, "statement": heading.title,
                    "proofs": [], "references": [], "source": source_loc(source, heading.start, primary.end),
                    "explicit_id": metadata(source, heading.end, end),
                    "section": sections_at(source, heading.start), "section_level": heading.level}
            items.append(item)
            item_headings[(path, i)] = item
            for nested_label in labels:
                add_owner(source, nested_label, item)
        # A document-front phantom anchor is navigation, not a mathematical
        # declaration. The exact immediate-label pattern avoids swallowing
        # arbitrary prose, later anchors, grouped arguments, or local scopes.
        front_boundaries = source.heading_starts + [block.start for block in source.blocks
                            if block.name in envs or block.name.rstrip("*") in envs
                            or block.name in _EQUATIONS or block.name in _LIST_ENVS
                            or block.name.rstrip("*") == "proof"]
        front_boundaries += [block.end_start for block in source.blocks
                             if block.name == "document" and block.closed]
        front_end = min(front_boundaries) if front_boundaries else len(source.text)
        labels_at = {label.start: label for label in source.labels}
        for start, end, blocks in source.phantom_sections:
            if start >= front_end or any(source.blocks[index].name != "document" for index in blocks):
                continue
            label = labels_at.get(_space(source.clean, end))
            if label is None or (path, label.start) in consumed_labels:
                continue
            title = next((text for _, stop, text in reversed(source.titles) if stop <= start), Path(path).stem)
            item = {"key": path + "::" + label.value, "label": label.value, "label_aliases": [],
                    "kind": "document", "title": title, "statement": title,
                    "proofs": [], "references": [], "source": exact_span(source, start, label.end),
                    "explicit_id": metadata(source, start, label.end), "section": []}
            items.append(item)
            add_owner(source, label, item)
        # Bare list entries can carry useful stable links without declaring a
        # theorem or definition.  Capture a deliberately narrow, explicit
        # fragment type, leaving scope-bearing/complex cases diagnostic.
        critical_starts = sorted(b.start for i, b in enumerate(source.blocks)
                                 if (path, i) in item_blocks or b.name.rstrip("*") == "proof")
        for list_index, entries in source.list_items.items():
            block = source.blocks[list_index]
            if not block.closed:
                continue
            ancestor = block.parent
            outermost = True
            while ancestor is not None:
                if source.blocks[ancestor].name != "document":
                    outermost = False
                    break
                ancestor = source.blocks[ancestor].parent
            if not outermost:
                continue
            list_labels = source.labels_in_block.get(list_index, [])
            label_positions = [label.start for label in list_labels]
            for number, entry in enumerate(entries, 1):
                left = bisect_left(label_positions, entry.content_start)
                right = bisect_left(label_positions, entry.end)
                labels = [label for label in list_labels[left:right] if (path, label.start) not in consumed_labels]
                direct = [label for label in labels if label.blocks and label.blocks[-1] == list_index]
                if not direct:
                    continue
                critical = bisect_left(critical_starts, entry.start)
                if critical < len(critical_starts) and critical_starts[critical] < entry.end:
                    report("complex_list_item_not_captured", "warning", "A labeled list entry contains an independently indexed result, equation, or proof; its surrounding fragment requires an explicit scope adapter.", path, entry.start)
                    continue
                primary = direct[0]
                removal = [(label.start, label.end) for label in labels]
                id_left = bisect_left(source.id_positions, entry.content_start)
                id_right = bisect_left(source.id_positions, entry.end)
                removal += [(a, b) for a, b, _ in source.id_comments[id_left:id_right]]
                heading_index = bisect_left(source.heading_starts, block.start) - 1
                preceding_start = source.headings[heading_index].start if heading_index >= 0 else 0
                item = {"key": path + "::" + primary.value, "label": primary.value, "label_aliases": [],
                        "kind": "fragment", "title": entry.title,
                        "statement": _without_spans(source.text, entry.content_start, entry.end, removal),
                        "proofs": [], "references": [], "source": exact_span(source, entry.start, entry.end),
                        "explicit_id": metadata(source, entry.content_start, entry.end),
                        "section": sections_at(source, entry.start),
                        "fragment_context": {"environment": block.name, "item_index": number,
                                             "list_source": exact_span(source, block.start, block.end),
                                             "preceding_source": exact_span(source, preceding_start, block.start)}}
                items.append(item)
                fragments.setdefault(path, []).append((entry.start, entry.end, item))
                for nested_label in labels:
                    add_owner(source, nested_label, item)

    fragment_starts = {}
    for path, entries in fragments.items():
        entries.sort(key=lambda row: row[0])
        fragment_starts[path] = [start for start, _, _ in entries]

    # Resolve aliases without treating a label's spelling as mathematical proof.
    by_label: dict[str, list[dict]] = {}
    by_prefixed: dict[str, list[dict]] = {}
    for (path, label), owners in label_owners.items():
        by_label.setdefault(label, []).extend(owners)
        prefixes = {Path(path).stem, str(Path(path).with_suffix("")).replace("/", "-")}
        for prefix in prefixes:
            by_prefixed.setdefault(prefix + "-" + label, []).extend(owners)
    for path in order:
        seen: dict[str, _Label] = {}
        for label in sources[path].labels:
            if label.value in seen:
                report("duplicate_label", "error", f"Label {label.value!r} occurs more than once in this file.", path, label.start)
            seen[label.value] = label

    def unique_candidates(values):
        output = {}
        for item in values:
            output[item["key"]] = item
        return list(output.values())

    def resolve_label(source, label, position, emit=True):
        local = unique_candidates(label_owners.get((source.path, label), []))
        candidates = local or unique_candidates(by_label.get(label, []))
        if not candidates:
            candidates = unique_candidates(by_prefixed.get(label, []))
        if len(candidates) == 1:
            return candidates[0]
        if emit:
            if len(candidates) > 1:
                report("ambiguous_reference", "error", f"Reference {label!r} has multiple possible targets.", source.path, position)
            else:
                report("unresolved_reference", "warning", f"Reference {label!r} does not resolve to an indexed item.", source.path, position)
        return None

    preceding_items: dict[str, list[tuple[int, dict]]] = {}
    preceding_ends: dict[str, list[int]] = {}
    for path in order:
        entries = sorted(((b.end, item_blocks[(path, i)]) for i, b in enumerate(sources[path].blocks)
                          if (path, i) in item_blocks and item_blocks[(path, i)]["kind"] not in {"equation", "section"}),
                         key=lambda pair: pair[0])
        preceding_items[path] = entries
        preceding_ends[path] = [end for end, _ in entries]
    proof_owners: dict[tuple[str, int], dict] = {}
    for source, index in pending_proofs:
        block = source.blocks[index]
        candidates = []
        nested = False
        parent = block.parent
        while parent is not None:
            if (source.path, parent) in item_blocks:
                candidates = [item_blocks[(source.path, parent)]]
                break
            if source.blocks[parent].name.rstrip("*") == "proof":
                report("nested_proof", "error", "A nested proof requires explicit local-result handling.", source.path, block.start)
                nested = True
                break
            parent = source.blocks[parent].parent
        if nested:
            continue
        header_refs = [ref for ref in source.references_in_block.get(index, []) if ref.start < block.content_start]
        if header_refs:
            named = unique_candidates([target for ref in header_refs if (target := resolve_label(source, ref.label, ref.start)) is not None])
            if len(named) == 1:
                if named[0]["kind"] in {"fragment", "document"}:
                    code = "fragment_is_not_proof_target" if named[0]["kind"] == "fragment" else "navigation_is_not_proof_target"
                    report(code, "error", "A captured fragment or document anchor has no declared theorem/definition type; attach a proof only after an explicit structural revision.", source.path, block.start)
                    continue
                if candidates and candidates[0]["key"] != named[0]["key"]:
                    report("conflicting_proof_target", "error", "A proof header names a different item from its enclosing item.", source.path, block.start)
                    continue
                candidates = named
            else:
                report("ambiguous_proof_target", "error", "The proof header does not identify a single indexed item.", source.path, block.start)
                continue
        if not candidates:
            previous = bisect_right(preceding_ends[source.path], block.start) - 1
            if previous >= 0:
                end, candidate = preceding_items[source.path][previous]
                heading = bisect_left(source.heading_starts, end)
                starts = fragment_starts.get(source.path, [])
                fragment = bisect_left(starts, end)
                no_fragment = fragment == len(starts) or starts[fragment] >= block.start
                if no_fragment and (heading == len(source.heading_starts) or source.heading_starts[heading] >= block.start):
                    candidates = [candidate]
        if not candidates:
            report("orphan_proof", "error", "Proof could not be attached to a preceding or explicitly named item.", source.path, block.start)
            continue
        owner = candidates[0]
        labels = source.labels_in_block.get(index, [])
        for label in labels:
            add_owner(source, label, owner)
        removal = [(label.start, label.end) for label in labels]
        id_left = bisect_left(source.id_positions, block.content_start)
        id_right = bisect_left(source.id_positions, block.end_start)
        removal += [(a, b) for a, b, _ in source.id_comments[id_left:id_right]]
        proof = {"text": _without_spans(source.text, block.content_start, block.end_start, removal),
                 "source": source_loc(source, block.start, block.end), "references": [], "title": block.title}
        owner["proofs"].append(proof)
        # Link the temporary block only inside this process, never in JSON.
        proof_owners[(source.path, index)] = {"owner": owner, "proof": proof,
                                              "proof_index": len(owner["proofs"]) - 1}

    # Proof labels are now known.  Refresh reverse maps before reading uses.
    by_label.clear()
    by_prefixed.clear()
    for (path, label), owners in label_owners.items():
        by_label.setdefault(label, []).extend(owners)
        for prefix in {Path(path).stem, str(Path(path).with_suffix("")).replace("/", "-")}:
            by_prefixed.setdefault(prefix + "-" + label, []).extend(owners)

    bibliographic_inventory: dict[str, list[dict]] = {}
    for path in order:
        source = sources[path]
        labeled_headings = [(h.start, item_headings[(path, i)]) for i, h in enumerate(source.headings) if (path, i) in item_headings]
        labeled_heading_starts = [start for start, _ in labeled_headings]
        for ref in source.references:
            role, destination = "mention", None
            for block_index in reversed(ref.blocks):
                if (path, block_index) in proof_owners:
                    block = source.blocks[block_index]
                    if ref.start < block.content_start:
                        # The target in "Proof of Lemma X" is not a dependency.
                        destination = None
                        role = "proof_header"
                        break
                    role = "proof"
                    destination = proof_owners[(path, block_index)]["proof"]["references"]
                    break
                if (path, block_index) in item_blocks:
                    role = "statement"
                    destination = item_blocks[(path, block_index)]["references"]
                    break
            if role == "proof_header":
                continue
            if destination is None:
                position = bisect_right(fragment_starts.get(path, []), ref.start) - 1
                if position >= 0:
                    _, end, fragment = fragments[path][position]
                    if ref.start < end:
                        destination = fragment["references"]
                        role = "mention"
            if destination is None:
                heading = bisect_right(labeled_heading_starts, ref.start) - 1
                if heading >= 0:
                    destination = labeled_headings[heading][1]["references"]
            target = resolve_label(source, ref.label, ref.start)
            record = {"label": ref.label, "target_key": target["key"] if target else None,
                      "command": ref.command, "line": source.line(ref.start), "role": role}
            if target and ref.label != target["label"]:
                # Prefix spelling alone is not a clause; retain the real alias.
                aliases = [alias for alias in target["label_aliases"] if alias == ref.label or ref.label.endswith("-" + alias)]
                clause = max(aliases, key=len) if aliases else None
                if clause and clause != target["label"]:
                    record["target_clause"] = clause
            if destination is not None:
                destination.append(record)
        for citation in source.citations:
            role, destination, owner, proof_index = "mention", None, None, None
            proof_header, unbound_proof = False, False
            for block_index in reversed(citation.blocks):
                if (path, block_index) in proof_owners:
                    selected = proof_owners[(path, block_index)]
                    owner, proof_index = selected["owner"], selected["proof_index"]
                    destination = selected["proof"].setdefault("bibliographic_references", [])
                    role = "proof"
                    proof_header = citation.start < source.blocks[block_index].content_start
                    break
                if source.blocks[block_index].name.rstrip("*") == "proof":
                    # A structural error already explains why this proof was
                    # not indexed. Keep its bibliography visible without
                    # silently assigning it to a neighboring statement.
                    role, unbound_proof = "proof", True
                    break
                if (path, block_index) in item_blocks:
                    owner = item_blocks[(path, block_index)]
                    destination = owner.setdefault("bibliographic_references", [])
                    role = "statement"
                    break
            if destination is None and not unbound_proof:
                position = bisect_right(fragment_starts.get(path, []), citation.start) - 1
                if position >= 0:
                    _, end, fragment = fragments[path][position]
                    if citation.start < end:
                        owner = fragment
                        destination = owner.setdefault("bibliographic_references", [])
                        role = "mention"
            if destination is None and not unbound_proof:
                heading = bisect_right(labeled_heading_starts, citation.start) - 1
                if heading >= 0:
                    owner = labeled_headings[heading][1]
                    destination = owner.setdefault("bibliographic_references", [])
            if citation.command.rstrip("*").casefold() == "nocite":
                role = "bibliography"
            record = {"key": citation.key, "command": citation.command,
                      "notes": citation.notes, "source": exact_span(source, citation.start, citation.end),
                      "role": role}
            if proof_header:
                record["in_header"] = True
            if destination is not None:
                destination.append(record)
            indexed = {**record, "item_key": owner["key"] if owner else None}
            if proof_index is not None:
                indexed["proof_index"] = proof_index
            bibliographic_inventory.setdefault(path, []).append(indexed)
        for label in source.labels:
            if (path, label.start) not in consumed_labels:
                report("unmanaged_label", "warning", f"Label {label.value!r} is outside supported addressable structures.", path, label.start)
    path_order = {path: i for i, path in enumerate(order)}
    items.sort(key=lambda item: (path_order[item["source"]["path"]], item["source"]["start_line"], item["key"]))
    unique_diagnostics = {(d["code"], d["severity"], d["message"], d["path"], d["line"]): d for d in diagnostics}
    layout["lookups"] = [lookup_records[key] for key in sorted(lookup_records, key=lambda pair: (pair[1] or "", pair[0]))]
    return {"items": items,
            "files": [{"path": sources[path].path, "sha256": sources[path].digest, "text": sources[path].text,
                       **({"bibliographic_references": bibliographic_inventory[path]} if path in bibliographic_inventory else {})}
                      for path in order],
            "source_layout": layout,
            "diagnostics": sorted(unique_diagnostics.values(), key=lambda d: (d["path"], d["line"], d["code"], d["message"]))}

