---
name: math-writing-editor
description: Revise mathematical research drafts into readable formal papers while preserving their mathematical content. Use for mathematical exposition, proof writing, introductions, rigorous research programmes, definition and theorem organization, or removal of formulaic AI prose in LaTeX, PDF drafts, and mathematical text. Especially suitable for arithmetic geometry and non-Archimedean geometry. Also support lecture notes when explicitly requested. Do not substitute this workflow for discovering or verifying a new proof.
---

# Mathematical writing editor

Improve what a mathematician can understand from the manuscript: the exact claim, the purpose of each construction, the decisive argument, and the dependencies between results. Treat fluent English as one part of this task. Run in the existing Codex environment; do not build an application, provision an API, or introduce a multi-agent framework merely to edit a paper.

## Choose the editorial task

Read the actual draft and the user's latest instructions. Use research-paper English unless the user specifies another language or genre. Assume a researcher in the relevant area who knows standard background but has not read this particular argument. For an excerpt, read adjacent definitions and cited internal statements when available. Before adding a proof sketch, motivation, or background, locate where the surrounding manuscript already provides it. Improve the distribution of explanation rather than duplicating it in every subsection.

Choose the dominant task: `proof`, `definition`, `introduction`, `structure`, `programme`, or `lecture`. Preserve good passages when no concrete reader difficulty warrants a change. Do not require the user to fill out an intake questionnaire. Request only information that blocks the requested edit; continue work on the remaining text.

Read [editorial decisions](references/editorial-decisions.md) and the statement-logic procedure in [content preservation](references/content-preservation.md) before polishing mathematical statements. For an Introduction, also read [introduction editing](references/introduction.md). For a research plan, conjecture paper, or a website's formal mathematical article, read [research programmes and article boundaries](references/research-programmes.md). For LaTeX/PDF navigation, read [cross-references and color](references/latex-navigation.md). For evaluation or iterative improvement, read [evaluation](references/evaluation.md); use [regression cases](references/regression-cases.json) to check real feedback and counterexamples to over-editing.

Select at most three relevant examples:

```bash
python3 <skill-dir>/scripts/editor_lab.py examples --task proof --limit 2
```

Replace `<skill-dir>` with this skill's actual directory. Treat the examples as assistant-authored demonstrations of editing decisions, not as human-approved reference writing. Transfer the decision, never the mathematical facts or sentence patterns. Do not force every passage into an example's shape.

## Establish what the reader needs

Before rewriting, identify a short editorial brief grounded in the source:

- The mathematical question and exact result of this passage.
- The step at which a reader is likely to lose the argument: an unexplained choice, distant definition, ambiguous quantifier, missing dependency, or unnecessary repetition.
- The useful intervention: leave unchanged, delete, move, merge, or rewrite; add an explanation only when those choices do not resolve the difficulty. Check adjacent text for an existing explanation before adding one.
- The mathematical features that must survive: hypotheses, conclusion, object types, constants and their dependencies, convergence, support, normalization, and proof status.

Keep the brief compact. For a small passage, do this without burdening the deliverable with a diagnostic report. For a whole paper, maintain a small editorial work file with source locations, proposed moves, and unresolved issues; do not put this file's commentary in the article.

## Rewrite at the appropriate scale

Before language editing, audit definitions and statements: distinguish given objects from those being constructed; state existence, uniqueness, well-definedness, and independence when the source argument establishes them. Check types, quantifiers, domains, tests, convergence, and constant dependencies. Do not use a proposed operation as an established object before proving it exists. If the source lacks the required argument, flag the gap separately rather than manufacture a stronger statement.

1. **Repair organization first.** Put required definitions before their substantive use. State the purpose of a substantial construction before introducing its machinery. Move a lemma only after checking its dependencies. Give headings conventional mathematical content: a property, construction, estimate, or completed step, not an internal code or a coined slogan. Place an established consequence under the result from which it follows, with its deduction and any extra assumptions; retain cross-references to other necessary premises. Add sections and Steps only when the argument needs them.
2. **Explain the actual mechanism.** Identify the reduction, construction, estimate, or obstruction that makes the argument work. Supply a short derivation when it follows from the supplied material and removes a real difficulty. Cite the exact lemma and say what it supplies. Keep all steps needed to check the argument.
3. **Allocate explanation.** Expand difficult transitions and choices; compress routine algebra and repetition for the intended reader. Organize a substantial main proof or its strategy into numbered Steps when this makes its mathematical stages visible. Give each Step a specific goal, the mechanism achieving it, and its output; connect that output to the next stage. Do not force short proofs into Steps or repeat a roadmap immediately before executing it. See the proof-strategy procedure in [introduction editing](references/introduction.md).
4. **Delete unneeded prose before rephrasing.** Focus on what is proved, how, and why it matters. Delete defensive scope commentary when its removal loses no understanding of the theorem, mechanism, or mathematical relationship; do not enumerate unproved extensions merely to display caution. Put an essential restriction in the statement, definition, or proof step where it operates. Preserve mathematically necessary negations, counterexamples, and distinctions. In a research programme or progress account, retain the precise outstanding inference and its consequence: an actual gap requested by the user is substantive mathematics, not defensive boilerplate. Review every Remark for independent mathematical value; merge, move, or delete repetition. Explain significance and transitions through actual constructions and deductions. Do not use forbidden-word lists, length targets, or AI-detector scores.
5. **Preserve source content.** Rephrase and reorganize equivalent mathematics freely, but check changed statements and explanatory additions against the source. Do not silently strengthen a theorem, replace its test class, invent a missing argument, or assign a new citation. If an apparent gap is found, edit the surrounding material and flag the exact gap separately.

For long manuscripts, establish the result/dependency map and intended section sequence, then edit one coherent argument at a time with its necessary context. Assess each appendix: keep the main argument and the constructions essential to understanding it in the body; retain an appendix only for a concrete supplementary role. Integrate related material into existing sections where appropriate, without deleting needed proofs or merely relabelling every appendix as a final section. Apply the main-text/appendix procedure in [editorial decisions](references/editorial-decisions.md). Revise the Introduction against the resulting body. Finish with a whole-document pass for terminology, notation, forward references, and duplicated motivation. Avoid isolated page-by-page rewriting.

Before replacing a proof by a citation, distinguish an exact known theorem, an immediate corollary, a nontrivial combination, and a new argument. Cite the first precisely, give the short deduction for the second, explain the interfaces for the third, and preserve the necessary proof for the fourth. Verify matching hypotheses in the primary source; unavailable references do not justify deleting an argument. See the procedure in editorial decisions.

## Review in four separate passes

After drafting, reread the source and revision in a separate review pass; do not treat the drafting rationale as evidence of success.

- **Mathematical fidelity:** compare all changed assertions, including prose, for hypotheses, logical structure, signs, normalization, support, convergence, tests, and dependencies. State unsupported repairs separately.
- **Redundancy and defensive prose:** read the whole edited scope, including unchanged surrounding text. Try deletion before synonym replacement; inspect each Remark, heading, repeated explanation, and mechanical transition. Preserve useful mathematical negations and the no-change option.
- **Mathematical readability:** can the reader state the main result, explain a construction's purpose, identify the decisive inference, connect the results, and describe their mathematical value? Restore needed explanations lost through compression.
- **Technical verification:** compile and inspect the PDF, references, colors, and destinations when applicable. Record unavailable checks explicitly. Compilation does not establish either of the first three judgments.

Fix consequential failures without an unbounded critique loop. Work within the current session unless the user requests or authorizes another reviewer. Distinguish a separate local review pass from an independent reviewer; model agreement is not a proof certificate.

For a complete Introduction to a results paper, explain the problem and the meaning of the main result, state the complete formal principal theorem after its necessary definitions, locate it against verified prior results, and explain the actual proof strategy. In a programme article, give the exact central conjecture or target instead, preserving its open status and separating proposed approaches from proved reductions. Separate definitions needed to understand the principal assertion from proof machinery. Do not move an entire preliminaries section into the Introduction by default. A reference or informal summary does not replace the formal statement. Respect a narrower requested scope.

In the Introduction, direct the reader to the subsection containing a theorem's proof, using its semantic label and a named hyperlink, rather than a page number. For a long proof assembled across the paper, link the subsection completing the proof and let the strategy explain its dependencies. Add a descriptive proof subsection when the existing organization lacks a suitable destination; do not invent a reference or hard-code its number.

For lecture notes, use the explicitly requested learner level. Add useful intuition, examples, and intermediate explanations, separating them from proofs. Do not introduce exercises or a textbook voice into a research paper by default.

## Use existing document tools

Prefer supplied LaTeX alongside the PDF when available. Accept a PDF-only task: extract its text, inspect pages containing ambiguous mathematics, and reconstruct only what is needed. Track uncertain transcription separately. Do not pretend OCR text certifies a displayed formula. Use existing PDF/LaTeX tools instead of building a parser or compiler for this skill.

Preserve labels, bibliography keys, macros, author metadata, and the requested journal template by default. An explicit request for unsigned papers overrides the byline default only for the requested documents: remove their displayed author lines and author metadata in each delivered format, while preserving citations, source attribution, and unrelated manuscripts. Use restrained dark links with complete clickable names. Where the document supports it reliably, distinguish theorem/definition, section, equation, citation, and external links; use the stable opt-in commands in [cross-references and color](references/latex-navigation.md). Preserve compatible configurations and journal requirements. Check rendered colors and destinations as well as compilation.

When a table of contents is present or requested, place it after the title/abstract and before the Introduction. Do not append it to the Introduction. Keep it legible and allow natural page breaks; do not force a long contents list into an unbreakable box. Do not add a contents list to a short paper automatically. Explicit user layout instructions take precedence over defaults; flag an actual conflict with a mandatory submission template rather than silently ignoring either requirement.

## Deliver the edited mathematics

Give the revised passage or manuscript first. Follow it, when useful, with a short account of the consequential changes and specific unresolved source issues. Separate editorial notes and evaluation data from publishable prose. Do not replace requested rewriting with advice or an audit. Do not claim mathematical verification or superiority to the user's existing workflow without evidence.

When the user accepts or rejects an edit, retain the specific preference and its mathematical context in the project record. Promote examples into this skill only when explicitly updating the editor; label author-approved examples accurately. Do not silently learn stylistic rules from unreviewed model output.
