# Math Writing Editor

Improve mathematical exposition, proof structure and LaTeX presentation while preserving the mathematical content.

## Use the bundle

Download and extract the ZIP. Keep the `math-writing-editor` folder intact so its instructions can find the bundled references, scripts and examples. In an assistant that supports skill import, import this folder or upload the ZIP and ask it to install `math-writing-editor`. You can also give a file-aware assistant the folder and ask it to read `SKILL.md` before working on your project.

Example request: “Use math-writing-editor for the project files I have supplied.”

The core workflow is in `SKILL.md`; the optional example selector uses Python 3. Start with `python3 scripts/editor_lab.py --help`. LaTeX compilation and PDF inspection use the tools available in your assistant environment.

## Contents and release

This public source bundle is dated 2026-11-18. It contains the skill instructions and their supporting resources. It can be downloaded and used in your own mathematical workflow. Configure the workflow for your own project and review mathematical outputs using the supplied sources.

Personal hosting bindings and generated caches are excluded. Research manuscripts, hosted accounts and credentials are not part of the bundle.
