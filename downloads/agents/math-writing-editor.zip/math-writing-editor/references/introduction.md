# Editing a mathematical Introduction and proof strategy

Build from the actual body. The reader should understand what is proved, how it relates to existing mathematics, and why the argument works. Include the full formal principal theorem early after the definitions needed to parse it. No fixed paragraph count or mandatory list of subsection headings is needed.

## 1. Read and separate the prerequisites

Read the authoritative theorem statements, their definitions, the proof, and the relevant cited results. An abstract or result register cannot replace the available source. Respect excerpt-only requests.

Keep a compact working map outside the paper:

| Item | Source and editorial decision |
|---|---|
| Main theorem | Exact hypotheses, quantifiers, conclusion, status, label |
| Statement prerequisites | Definitions and conventions needed to parse the theorem |
| Proof prerequisites | Auxiliary classes, models, constructions, or normalizations needed only later |
| Meaning | What the theorem allows one to construct, deduce, or compare |
| Related results | Checked source, locator/version, hypotheses, conclusion, relation |
| Proof stages | Actual obstacle, construction/estimate, output, next use, body label |

Introduce statement prerequisites before the theorem. Move proof-only machinery to its first substantive use or to preliminaries. Do not import a whole technical section merely to put the theorem earlier. If a technical definition is logically essential to the theorem, keep its operative conditions and explain its role; an informal gloss cannot replace it.

## 2. Explain and state the main result

Open with the concrete mathematical objects and question. State what passage is difficult: for example, a construction available for continuous data is sought for a less regular class. Claim an unresolved literature gap only with adequate checked evidence.

Give the reader a short account of what the theorem says, then include its complete numbered formal statement inside the Introduction. Explain its significance nearby without repeating every clause. The order of explanation around the theorem may vary. For several main theorems, make their dependence clear and give each the definitions it actually needs.

Preserve base field and absolute value, dimension, category, domains, regularity, quantifier order, support, constants and dependencies, convergence/test classes, normalizations, and exceptions. Link unchanged labels; use an existing restatement mechanism if the body also states the theorem. Do not replace the general result by a convenient special case.

Locate deferred proofs by subsection, not page number: for example, “The proof is given in \Cref{sec:proof-main}.” Ensure the label belongs to an actual descriptive subsection containing the proof or its concluding assembly. Keep the proof strategy responsible for explaining earlier ingredients. Update this locator after structural moves.

Distinguish an assertion from its interpretation. Explain the decisive scope condition when it matters, such as convergence against all original test forms or approximants on one fixed neighborhood. Include a consequence only when the paper proves it or the deduction is explicitly justified. Avoid promising applications absent from the body.

Apply the statement-logic audit before polishing: distinguish the given objects from those whose existence is being asserted. Explain a restriction only when its mathematical role needs explanation. Delete duplicate scope warnings once the formal statement is clear; do not add an inventory of unproved extensions or unresolved questions as a display of caution. Present a supported contribution directly.

### Connect the results

Read successive principal statements as a continuous argument. Where their connection is not apparent, add a short bridge explaining what is now available and what remains to be established. Useful relations include approximation enabling a construction, existence followed by independence or stability, a local statement leading to gluing, or a theorem yielding an application. Do not imply that a later theorem follows formally from an earlier one when additional estimates are required.

Use the bridge to advance the reader's understanding, not to repeat both statements. “We now state our next important theorem” supplies no connection. Do not mechanically insert transitions between every definition, lemma, and theorem; a well-placed sentence may connect a whole group. Vary the structure according to the mathematics, not by swapping synonyms. Keep the existing requirement to delete duplicate explanation.

### Explain mathematical significance

For each main result, identify a source-supported answer to at least one of these questions: what object can now be constructed; what previously separate descriptions are identified; what obstruction is overcome; what computation or deduction becomes possible; or which established theory becomes available for these objects? Distinguish the role of a result inside the proof from the value of the result to a reader who might use it.

Integrate the strongest answer into the opening or the discussion near the theorem. Describe what the hypotheses and conclusions enable. For example, if supplied results construct products independently of auxiliary choices and prove continuity, explain how this permits approximation arguments on the stated class. Do not turn that into a claim of a full theory, a new application, a comparison principle, or a solution of a wider conjecture absent from the paper. Explain a reusable method only to the extent established by the argument.

Words such as “important”, “powerful”, or “fundamental” do not demonstrate value. Novelty relative to the literature requires the source checks below; mathematical significance can be explained precisely without claiming priority. Keep prospective applications explicitly prospective and include them only if requested or grounded in the manuscript.

## 3. Place it against existing research

Choose the closest results and the sources actually used in the proof. A bibliography catalogue does not explain the contribution. For each substantial comparison, establish:

- What the cited work proves, for which objects and under which hypotheses.
- What is retained, extended, replaced, or used here.
- The particular extra argument required for the difference claimed.

Read the relevant primary statement and, for methodological comparisons, its relevant proof. Record the version and precise locator in the working map; attach the citation to the supported claim in the article. Existing citation keys are not evidence that a newly written comparison is correct. Do not infer inclusion of theories from similar vocabulary or theorem titles.

Use “extends”, “recovers”, “removes the hypothesis”, “first”, or “previously unknown” only at the scope the evidence supports. If access fails, preserve a source-supported modest attribution and flag the unverified comparison in editorial notes. Do not insert a plausible citation or a literature-gap claim to make the Introduction sound complete. Historical context and proof inputs need not be separate subsections.

## 4. Write the strategy in mathematical Steps

For a substantial main argument with genuinely distinct stages, use numbered **Step 1**, **Step 2**, etc., when they reveal its structure. Give short mathematical titles and choose their number from the argument. Preserve an already clear proof or strategy without imposing headings. Apply the same principle inside the full proof; an introductory sketch does not replace the full argument.

Before the Steps, identify the target and the main obstruction or reduction in one compact paragraph. Within each Step, convey these components in natural prose, not four repetitive labelled boxes:

1. **Input and task:** what is already available and what is still needed.
2. **Mechanism:** the construction, estimate, identity, or cited result that supplies it.
3. **Output:** the exact conclusion and where it is used next.

Give the pivotal formula if it explains a choice or passage to a limit. Cite the precise internal result supplying a nonroutine assertion. The Step titles should identify mathematics, such as “From contact to decreasing regularization”, rather than “Preparation” or “Technical arguments”. A list of lemma numbers is insufficient.

Expose dependencies that would otherwise look circular: which first-order tools precede the higher products, which induction hypothesis justifies a limit, or why a common domain must be chosen before the approximants. Preserve the proof's actual order when it matters. Do not invent a bridge to smooth the narrative.

Keep one substantial strategy in the Introduction. Near the main theorem, a short orientation or cross-reference suffices if a later subsection gives the strategy. Do not immediately repeat each Step in a second roadmap, nor announce and re-explain a lemma whose proof already gives the explanation. A final section guide should add navigation the Steps did not supply.

## 5. Review the result

Compare the formal theorem clause by clause against its source. For each Step, check the input, conclusion, and cited body passage. Audit new prose assertions as carefully as displayed formulas. Check prior-work comparisons against the actual cited statements. Verify that proof locators point to the correct subsections and that the strategy matches the final body/appendix organization; core proof stages should not be hidden in appendices without an editorial reason.

Read only the Introduction and answer: what is the main result, why is it mathematically useful, what did the closest prior work provide, how do the successive main results connect, and what makes the proof work? If an answer requires later pages, add or move the missing explanation. If the same answer occurs repeatedly, merge or delete the repetition. Check that a contents list, when included, precedes the Introduction. A longer Introduction can be justified by genuine mathematical needs; length, transition count, or Step count alone is not quality.
