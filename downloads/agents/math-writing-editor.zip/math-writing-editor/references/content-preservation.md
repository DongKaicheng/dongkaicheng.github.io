# Preserving mathematical content during editing

Use this as a comparison procedure, not as a claim of formal verification. A writing task normally accepts the supplied mathematical argument as its source; it still requires checking that the edit does not change it.

## Statement logic before prose

For each definition, lemma, proposition, or theorem being edited, identify:

1. **Given data:** every object's type, domain, definition, and available hypotheses.
2. **Objects to be constructed:** whether existence or well-definedness is the point of the result. Introduce a candidate or formula as such; do not assume the object in the premises.
3. **Exact assertion:** separate existence, uniqueness with its characterization, and independence of representatives, approximations, charts, or other choices. Include these only to the extent established by the supplied argument.
4. **Logical order:** keep hypotheses out of the conclusion and conclusions out of the hypotheses; verify quantifier order, test class, convergence, and permitted constant dependencies.
5. **Proof support:** locate the inference establishing each assertion. Distinguish an implicit but already proved fact from a genuinely missing argument.

For example, when the construction of a product with continuous coefficients is the lemma's content, state “There exists a unique current, denoted by \(fT\), such that …”, followed by the exact pairing formula. State existence of its limiting pairing and independence of the admissible approximation if the proof establishes them. Check continuity on the specified test space as well: scalar limits alone do not establish a current. Preserve the particular manifold, current degree, test class, and approximation assumptions of the source; this is a logical pattern, not a theorem about every positive current.

If the proof already supplies these facts, making them explicit is an exposition repair. If existence, continuity, uniqueness, or independence is unsupported, retain the source's status and flag the exact issue outside the publishable text. Do not quietly add a hypothesis or claim uniqueness to make the statement look complete.

## Source-backed comparison

For each changed statement, identify its source location and compare:

1. **Objects and hypotheses:** base field and absolute value, category, dimension, regularity, domains, compactness, finiteness, and positivity conditions.
2. **Logical strength:** quantifiers and their order, existence versus canonical choice, local versus global, conditional versus unconditional, and dependence of constants.
3. **Conclusion:** equality/inequality, signs, factors, support, type of convergence, class of tests, and whether the assertion concerns functions, forms, currents, metrics, or measures.
4. **Use in the proof:** each invoked result supplies precisely the object/property claimed; moved material does not create a circular dependency.
5. **Attribution and status:** citations stay attached to their actual claims; a new explanatory observation is not attributed to a source without checking it.

For short edits, perform this comparison directly. For large edits, keep only the consequential changes in a compact ledger: source location, original claim, revised location, nature of change, unresolved issue. Do not make the user inspect a massive invariants file to read the paper.

## Audit explanatory prose

The audit includes new sentences outside theorem and display environments. Resolve phrases such as “the second term”, “this limit”, “uniformly”, and “therefore” to a specific mathematical object and justification. Check whether an integral has a sign, its negative has that sign, or only their sum does. For example, in the synthetic identity $E=A-\int g\,d\mu$ with $g\geq0$ and $\mu\geq0$, write “the integral being subtracted is nonnegative”; “the second term is nonnegative” can incorrectly describe $-\int g\,d\mu$.

For every substantive new explanation, locate its source inference or give the short derivation. If it needs a new theorem, classify it as an unresolved mathematical issue. Counts of unchanged formal statements, preserved labels, or matching displayed equations are useful checks but cannot certify all prose assertions.

Apply the same comparison to deletions. A redundant warning about an unproved extension may go; a nonvanishing assumption, a negative sign, a counterexample, or a distinction needed to use the next lemma may not. Retain restrictions in their mathematical location without duplicating them as defensive commentary.

## Permit useful exposition

Do not freeze every formula or theorem word for word. Equivalent restatement, notation consolidation, and splitting a long statement can improve readability. Check the equivalence. If a definition moves into the Introduction, preserve its operative conditions. If a proof is reorganized, preserve the reasoning needed for its nonroutine implications.

An elementary calculation may be expanded when it follows from the stated assumptions. A missing theorem, unjustified pullback, unavailable restriction, or new approximation result must not be invented as a connective sentence. Mark the exact point separately and continue the authorized writing elsewhere.

Do not turn every supplied theorem into a conjecture merely because this editing pass has not independently verified it. Preserve source status while saying accurately what the edit checked.

## PDF input

Distinguish a transcription uncertainty from a mathematical concern. Inspect the page if the extracted text drops exponents, wedge signs, normalization factors, or the order of quantifiers. Keep unresolved transcription visible in editorial notes rather than silently guessing. If LaTeX is available, use its definitions and macros as the source of notation and check them against the rendered PDF.

## Release note

Report mathematical-content comparison, reference checks, compilation, and layout inspection as distinct activities, only when done. Do not describe an edited paper as publication-ready solely because it compiles or a model reviewer approves its prose.
